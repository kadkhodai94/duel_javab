import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await RuntimeState.instance.load();
  runApp(const DuelJavabApp());
}

class DuelJavabApp extends StatelessWidget {
  const DuelJavabApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'دوئل جواب',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: null,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: AppColors.bgTop,
        colorScheme: ColorScheme.fromSeed(seedColor: AppColors.cyan, brightness: Brightness.dark),
      ),
      builder: (context, child) {
        return Directionality(textDirection: TextDirection.rtl, child: child ?? const SizedBox.shrink());
      },
      home: RuntimeState.instance.hasProfile.value ? const ShellScreen() : const ProfileSetupScreen(),
    );
  }
}

class AppColors {
  static const bgTop = Color(0xFF05091D);
  static const bgMid = Color(0xFF08143A);
  static const bgBottom = Color(0xFF170633);
  static const cyan = Color(0xFF20B6FF);
  static const blue = Color(0xFF006DFF);
  static const pink = Color(0xFFFF3FA4);
  static const purple = Color(0xFF8B5CFF);
  static const gold = Color(0xFFFFC857);
  static const green = Color(0xFF15D17C);
  static const red = Color(0xFFFF435D);
  static const orange = Color(0xFFFF8A3D);
  static const panel = Color(0xCC0B1230);
}

class PlayerProfile {
  final String id;
  final String name;
  final String rank;
  final int trophy;
  final int coins;
  final int xp;
  final int wins;
  final int losses;
  final int streak;
  final Color color;
  final IconData avatarIcon;
  final String city;
  final String title;
  final double accuracy;
  final int avgResponseMs;
  final int noAnswerRate;
  final bool generatedOpponent;

  const PlayerProfile({
    required this.id,
    required this.name,
    required this.rank,
    required this.trophy,
    required this.coins,
    required this.xp,
    required this.wins,
    required this.losses,
    required this.streak,
    required this.color,
    required this.avatarIcon,
    this.city = 'تهران',
    this.title = 'بازیکن رقابتی',
    this.accuracy = .62,
    this.avgResponseMs = 2600,
    this.noAnswerRate = 8,
    this.generatedOpponent = false,
  });

  PlayerProfile copyWith({
    String? id,
    String? name,
    String? rank,
    int? trophy,
    int? coins,
    int? xp,
    int? wins,
    int? losses,
    int? streak,
    Color? color,
    IconData? avatarIcon,
    String? city,
    String? title,
    double? accuracy,
    int? avgResponseMs,
    int? noAnswerRate,
    bool? generatedOpponent,
  }) {
    return PlayerProfile(
      id: id ?? this.id,
      name: name ?? this.name,
      rank: rank ?? this.rank,
      trophy: trophy ?? this.trophy,
      coins: coins ?? this.coins,
      xp: xp ?? this.xp,
      wins: wins ?? this.wins,
      losses: losses ?? this.losses,
      streak: streak ?? this.streak,
      color: color ?? this.color,
      avatarIcon: avatarIcon ?? this.avatarIcon,
      city: city ?? this.city,
      title: title ?? this.title,
      accuracy: accuracy ?? this.accuracy,
      avgResponseMs: avgResponseMs ?? this.avgResponseMs,
      noAnswerRate: noAnswerRate ?? this.noAnswerRate,
      generatedOpponent: generatedOpponent ?? this.generatedOpponent,
    );
  }
}

class DuelQuestion {
  final String id;
  final String text;
  final bool answer;
  final String type;
  final String category;
  final int difficulty;

  const DuelQuestion({
    required this.id,
    required this.text,
    required this.answer,
    required this.type,
    required this.category,
    required this.difficulty,
  });
}

enum DuelMode { ranked, private, practice, daily }

extension DuelModeLabel on DuelMode {
  String get title {
    switch (this) {
      case DuelMode.ranked:
        return 'رقابت سریع';
      case DuelMode.private:
        return 'اتاق خصوصی';
      case DuelMode.practice:
        return 'تمرین سریع';
      case DuelMode.daily:
        return 'چالش روزانه';
    }
  }

  String get subtitle {
    switch (this) {
      case DuelMode.ranked:
        return 'مسابقه سریع با حریف هم‌سطح';
      case DuelMode.private:
        return 'مسابقه دوستانه با کد اتاق';
      case DuelMode.practice:
        return 'تمرین سبک بدون تغییر جام';
      case DuelMode.daily:
        return 'رقابت روزانه با سوال‌های منتخب';
    }
  }
}

class GameStats {
  final int playerScore;
  final int opponentScore;
  final int correctAnswers;
  final int wrongAnswers;
  final int maxCombo;
  final int fastestMs;
  final int coins;
  final int xp;
  final int trophyChange;
  final DuelMode mode;
  final PlayerProfile player;
  final PlayerProfile opponent;

  const GameStats({
    required this.playerScore,
    required this.opponentScore,
    required this.correctAnswers,
    required this.wrongAnswers,
    required this.maxCombo,
    required this.fastestMs,
    required this.coins,
    required this.xp,
    required this.trophyChange,
    required this.mode,
    required this.player,
    required this.opponent,
  });

  bool get isWinner => playerScore >= opponentScore;
}

class Mission {
  final IconData icon;
  final String title;
  final String description;
  final int progress;
  final int target;
  final int reward;
  final Color color;

  const Mission({
    required this.icon,
    required this.title,
    required this.description,
    required this.progress,
    required this.target,
    required this.reward,
    required this.color,
  });
}

class StoreItem {
  final IconData icon;
  final String title;
  final String description;
  final int price;
  final Color color;
  final String keyName;
  final int amount;

  const StoreItem({required this.icon, required this.title, required this.description, required this.price, required this.color, required this.keyName, this.amount = 1});
}

class RuntimeState {
  RuntimeState._();
  static final RuntimeState instance = RuntimeState._();

  final ValueNotifier<PlayerProfile> player = ValueNotifier<PlayerProfile>(SampleData.player);
  final ValueNotifier<List<GameStats>> history = ValueNotifier<List<GameStats>>(<GameStats>[]);
  final ValueNotifier<bool> hasProfile = ValueNotifier<bool>(false);
  final ValueNotifier<bool> soundEnabled = ValueNotifier<bool>(true);
  final ValueNotifier<bool> vibrationEnabled = ValueNotifier<bool>(true);
  final ValueNotifier<Map<String, int>> inventory = ValueNotifier<Map<String, int>>({
    'extra_time': 0,
    'shield': 0,
    'double_score': 0,
    'neon_frame': 0,
  });

  SharedPreferences? _prefs;

  Future<void> load() async {
    _prefs = await SharedPreferences.getInstance();
    hasProfile.value = _prefs?.getBool('profile_ready') ?? false;
    soundEnabled.value = _prefs?.getBool('sound_enabled') ?? true;
    vibrationEnabled.value = _prefs?.getBool('vibration_enabled') ?? true;

    final base = SampleData.player;
    player.value = base.copyWith(
      name: _prefs?.getString('player_name') ?? base.name,
      city: _prefs?.getString('player_city') ?? base.city,
      title: _prefs?.getString('player_title') ?? base.title,
      rank: _prefs?.getString('player_rank') ?? base.rank,
      trophy: _prefs?.getInt('player_trophy') ?? base.trophy,
      coins: _prefs?.getInt('player_coins') ?? base.coins,
      xp: _prefs?.getInt('player_xp') ?? base.xp,
      wins: _prefs?.getInt('player_wins') ?? base.wins,
      losses: _prefs?.getInt('player_losses') ?? base.losses,
      streak: _prefs?.getInt('player_streak') ?? base.streak,
      avatarIcon: _avatarFromIndex(_prefs?.getInt('player_avatar') ?? 0),
      color: _colorFromIndex(_prefs?.getInt('player_color') ?? 0),
    );

    inventory.value = {
      'extra_time': _prefs?.getInt('inv_extra_time') ?? 0,
      'shield': _prefs?.getInt('inv_shield') ?? 0,
      'double_score': _prefs?.getInt('inv_double_score') ?? 0,
      'neon_frame': _prefs?.getInt('inv_neon_frame') ?? 0,
    };
  }

  Future<void> _savePlayer() async {
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    _prefs = prefs;
    final p = player.value;
    await prefs.setString('player_name', p.name);
    await prefs.setString('player_city', p.city);
    await prefs.setString('player_title', p.title);
    await prefs.setString('player_rank', p.rank);
    await prefs.setInt('player_trophy', p.trophy);
    await prefs.setInt('player_coins', p.coins);
    await prefs.setInt('player_xp', p.xp);
    await prefs.setInt('player_wins', p.wins);
    await prefs.setInt('player_losses', p.losses);
    await prefs.setInt('player_streak', p.streak);
  }

  Future<void> _saveInventory() async {
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    _prefs = prefs;
    final inv = inventory.value;
    await prefs.setInt('inv_extra_time', inv['extra_time'] ?? 0);
    await prefs.setInt('inv_shield', inv['shield'] ?? 0);
    await prefs.setInt('inv_double_score', inv['double_score'] ?? 0);
    await prefs.setInt('inv_neon_frame', inv['neon_frame'] ?? 0);
  }

  Future<void> updateProfile({required String name, required String city, required String title, required int avatarIndex, required int colorIndex}) async {
    final cleanName = name.trim().isEmpty ? 'بازیکن دوئل' : name.trim();
    final cleanCity = city.trim().isEmpty ? 'ایران' : city.trim();
    final cleanTitle = title.trim().isEmpty ? 'بازیکن رقابتی' : title.trim();
    player.value = player.value.copyWith(
      name: cleanName,
      city: cleanCity,
      title: cleanTitle,
      avatarIcon: _avatarFromIndex(avatarIndex),
      color: _colorFromIndex(colorIndex),
    );
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    _prefs = prefs;
    await prefs.setBool('profile_ready', true);
    await prefs.setInt('player_avatar', avatarIndex);
    await prefs.setInt('player_color', colorIndex);
    hasProfile.value = true;
    await _savePlayer();
  }

  Future<void> setSound(bool enabled) async {
    soundEnabled.value = enabled;
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    _prefs = prefs;
    await prefs.setBool('sound_enabled', enabled);
  }

  Future<void> setVibration(bool enabled) async {
    vibrationEnabled.value = enabled;
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    _prefs = prefs;
    await prefs.setBool('vibration_enabled', enabled);
  }

  void haptic([String type = 'tap']) {
    if (!vibrationEnabled.value) return;
    if (type == 'win') {
      HapticFeedback.mediumImpact();
    } else if (type == 'wrong') {
      HapticFeedback.heavyImpact();
    } else {
      HapticFeedback.selectionClick();
    }
  }

  Future<bool> buyStoreItem(StoreItem item) async {
    final current = player.value;
    if (current.coins < item.price) return false;
    player.value = current.copyWith(coins: current.coins - item.price);
    final inv = Map<String, int>.from(inventory.value);
    final key = item.keyName;
    inv[key] = (inv[key] ?? 0) + item.amount;
    inventory.value = inv;
    await _savePlayer();
    await _saveInventory();
    return true;
  }

  void applyMatch(GameStats stats) {
    history.value = [stats, ...history.value].take(20).toList();
    if (stats.mode == DuelMode.practice) return;
    final current = player.value;
    player.value = current.copyWith(
      coins: current.coins + stats.coins,
      xp: current.xp + stats.xp,
      trophy: max(0, current.trophy + stats.trophyChange),
      wins: current.wins + (stats.isWinner ? 1 : 0),
      losses: current.losses + (stats.isWinner ? 0 : 1),
      streak: stats.isWinner ? current.streak + 1 : 0,
      rank: _rankForTrophy(max(0, current.trophy + stats.trophyChange)),
    );
    _savePlayer();
  }

  String _rankForTrophy(int trophy) {
    if (trophy >= 6200) return 'افسانه‌ای';
    if (trophy >= 5000) return 'استاد';
    if (trophy >= 3500) return 'الماس ۱';
    if (trophy >= 2200) return 'الماس ۲';
    if (trophy >= 1500) return 'طلایی';
    if (trophy >= 800) return 'نقره‌ای';
    return 'برنزی';
  }

  static IconData _avatarFromIndex(int index) {
    const icons = [Icons.person_rounded, Icons.person_2_rounded, Icons.person_3_rounded, Icons.person_4_rounded, Icons.face_rounded, Icons.sports_esports_rounded];
    return icons[index.clamp(0, icons.length - 1).toInt()];
  }

  static Color _colorFromIndex(int index) {
    const colors = [AppColors.cyan, AppColors.pink, AppColors.purple, AppColors.green, AppColors.gold, AppColors.orange];
    return colors[index.clamp(0, colors.length - 1).toInt()];
  }
}

class SampleData {
  static const player = PlayerProfile(
    id: 'me',
    name: 'علی رستمی',
    rank: 'الماس ۲',
    trophy: 2450,
    coins: 12450,
    xp: 7600,
    wins: 128,
    losses: 42,
    streak: 8,
    color: AppColors.cyan,
    avatarIcon: Icons.person_rounded,
  );

  static const opponents = <PlayerProfile>[
    PlayerProfile(
      id: 'op_1',
      name: 'امیر محمدی',
      rank: 'برنزی ۲',
      trophy: 45,
      coins: 260,
      xp: 180,
      wins: 1,
      losses: 8,
      streak: 0,
      color: AppColors.pink,
      avatarIcon: Icons.person_4_rounded,
      city: 'کرج',
      title: 'تازه‌وارد سریع',
      accuracy: .45,
      avgResponseMs: 3400,
      noAnswerRate: 12,
      generatedOpponent: true,
    ),
    PlayerProfile(
      id: 'op_2',
      name: 'مهدی کریمی',
      rank: 'برنزی ۳',
      trophy: 32,
      coins: 190,
      xp: 140,
      wins: 2,
      losses: 11,
      streak: 0,
      color: AppColors.purple,
      avatarIcon: Icons.face_rounded,
      city: 'رشت',
      title: 'بازیکن آرام',
      accuracy: .42,
      avgResponseMs: 3800,
      noAnswerRate: 15,
      generatedOpponent: true,
    ),
    PlayerProfile(
      id: 'op_3',
      name: 'سامان احمدی',
      rank: 'برنزی ۳',
      trophy: 21,
      coins: 120,
      xp: 90,
      wins: 1,
      losses: 12,
      streak: 0,
      color: AppColors.orange,
      avatarIcon: Icons.person_3_rounded,
      city: 'شیراز',
      title: 'حریف تازه‌کار',
      accuracy: .39,
      avgResponseMs: 4100,
      noAnswerRate: 18,
      generatedOpponent: true,
    ),
    PlayerProfile(
      id: 'op_4',
      name: 'رضا سلیمانی',
      rank: 'برنزی ۴',
      trophy: 18,
      coins: 95,
      xp: 70,
      wins: 1,
      losses: 15,
      streak: 0,
      color: AppColors.green,
      avatarIcon: Icons.person_rounded,
      city: 'تبریز',
      title: 'حریف تازه‌وارد',
      accuracy: .36,
      avgResponseMs: 4300,
      noAnswerRate: 20,
      generatedOpponent: true,
    ),
  ];

  static const questions = <DuelQuestion>[
    DuelQuestion(id: 'q1', text: 'آیا خورشید یک ستاره است؟', answer: true, type: 'بله / نه', category: 'علمی', difficulty: 1),
    DuelQuestion(id: 'q2', text: 'تهران پایتخت ایران است.', answer: true, type: 'درست / غلط', category: 'عمومی', difficulty: 1),
    DuelQuestion(id: 'q3', text: 'عدد ۹ یک عدد زوج است.', answer: false, type: 'درست / غلط', category: 'ریاضی', difficulty: 1),
    DuelQuestion(id: 'q4', text: 'آب در دمای معمولی مایع است.', answer: true, type: 'درست / غلط', category: 'علمی', difficulty: 1),
    DuelQuestion(id: 'q5', text: 'قاره آفریقا کوچک‌ترین قاره جهان است.', answer: false, type: 'درست / غلط', category: 'جغرافیا', difficulty: 2),
    DuelQuestion(id: 'q6', text: 'آیا ماه از خودش نور تولید می‌کند؟', answer: false, type: 'بله / نه', category: 'علمی', difficulty: 2),
    DuelQuestion(id: 'q7', text: 'زبان فارسی از راست به چپ نوشته می‌شود.', answer: true, type: 'درست / غلط', category: 'عمومی', difficulty: 1),
    DuelQuestion(id: 'q8', text: 'در فوتبال هر تیم ۱۱ بازیکن اصلی دارد.', answer: true, type: 'درست / غلط', category: 'ورزشی', difficulty: 1),
    DuelQuestion(id: 'q9', text: 'آیا نهنگ یک ماهی است؟', answer: false, type: 'بله / نه', category: 'حیوانات', difficulty: 2),
    DuelQuestion(id: 'q10', text: 'کوه اورست بلندترین قله جهان است.', answer: true, type: 'درست / غلط', category: 'جغرافیا', difficulty: 1),
    DuelQuestion(id: 'q11', text: 'آیا اقیانوس آرام بزرگ‌ترین اقیانوس جهان است؟', answer: true, type: 'بله / نه', category: 'جغرافیا', difficulty: 2),
    DuelQuestion(id: 'q12', text: 'سرعت نور کمتر از سرعت صوت است.', answer: false, type: 'درست / غلط', category: 'علمی', difficulty: 3),
    DuelQuestion(id: 'q13', text: 'آیا زحل حلقه دارد؟', answer: true, type: 'بله / نه', category: 'علمی', difficulty: 1),
    DuelQuestion(id: 'q14', text: 'مثلث چهار ضلع دارد.', answer: false, type: 'درست / غلط', category: 'ریاضی', difficulty: 1),
    DuelQuestion(id: 'q15', text: 'آیا ایران در آسیا قرار دارد؟', answer: true, type: 'بله / نه', category: 'جغرافیا', difficulty: 1),
    DuelQuestion(id: 'q16', text: 'زرافه کوتاه‌ترین حیوان خشکی است.', answer: false, type: 'درست / غلط', category: 'حیوانات', difficulty: 2),
    DuelQuestion(id: 'q17', text: 'آیا بدن انسان بیش از ۲۰۰ استخوان دارد؟', answer: true, type: 'بله / نه', category: 'علمی', difficulty: 2),
    DuelQuestion(id: 'q18', text: 'در شطرنج، شاه مهم‌ترین مهره است.', answer: true, type: 'درست / غلط', category: 'ورزشی', difficulty: 2),
    DuelQuestion(id: 'q19', text: 'آیا زمستان بعد از پاییز می‌آید؟', answer: true, type: 'بله / نه', category: 'عمومی', difficulty: 1),
    DuelQuestion(id: 'q20', text: 'در زبان فارسی عدد ۱۰ با «ده» نوشته می‌شود.', answer: true, type: 'درست / غلط', category: 'عمومی', difficulty: 1),
    DuelQuestion(id: 'q21', text: 'آیا سیاره مریخ به سیاره سرخ معروف است؟', answer: true, type: 'بله / نه', category: 'علمی', difficulty: 1),
    DuelQuestion(id: 'q22', text: 'پایتخت فرانسه شهر لندن است.', answer: false, type: 'درست / غلط', category: 'جغرافیا', difficulty: 1),
    DuelQuestion(id: 'q23', text: 'آیا حافظ از شاعران بزرگ فارسی‌زبان است؟', answer: true, type: 'بله / نه', category: 'فرهنگ و هنر', difficulty: 1),
    DuelQuestion(id: 'q24', text: 'در والیبال هر تیم ۶ بازیکن داخل زمین دارد.', answer: true, type: 'درست / غلط', category: 'ورزشی', difficulty: 2),
    DuelQuestion(id: 'q25', text: 'آیا عدد ۲ تنها عدد اول زوج است؟', answer: true, type: 'بله / نه', category: 'ریاضی', difficulty: 2),
    DuelQuestion(id: 'q26', text: 'قاره اروپا بزرگ‌ترین قاره جهان است.', answer: false, type: 'درست / غلط', category: 'جغرافیا', difficulty: 2),
    DuelQuestion(id: 'q27', text: 'آیا اکسیژن برای تنفس انسان ضروری است؟', answer: true, type: 'بله / نه', category: 'علمی', difficulty: 1),
    DuelQuestion(id: 'q28', text: 'تخت جمشید در استان فارس قرار دارد.', answer: true, type: 'درست / غلط', category: 'تاریخی', difficulty: 2),
    DuelQuestion(id: 'q29', text: 'آیا اینترنت فقط در یک کشور قابل استفاده است؟', answer: false, type: 'بله / نه', category: 'فناوری', difficulty: 1),
    DuelQuestion(id: 'q30', text: 'CPU به عنوان مغز کامپیوتر شناخته می‌شود.', answer: true, type: 'درست / غلط', category: 'فناوری', difficulty: 1),
    DuelQuestion(id: 'q31', text: 'آیا زمین به دور خورشید می‌چرخد؟', answer: true, type: 'بله / نه', category: 'علمی', difficulty: 1),
    DuelQuestion(id: 'q32', text: 'دریای خزر یک اقیانوس است.', answer: false, type: 'درست / غلط', category: 'جغرافیا', difficulty: 2),
    DuelQuestion(id: 'q33', text: 'آیا سعدی نویسنده گلستان و بوستان است؟', answer: true, type: 'بله / نه', category: 'فرهنگ و هنر', difficulty: 2),
    DuelQuestion(id: 'q34', text: 'در بسکتبال، پرتاب آزاد یک امتیاز دارد.', answer: true, type: 'درست / غلط', category: 'ورزشی', difficulty: 2),
    DuelQuestion(id: 'q35', text: 'آیا ضرب عدد در صفر همیشه صفر می‌شود؟', answer: true, type: 'بله / نه', category: 'ریاضی', difficulty: 1),
    DuelQuestion(id: 'q36', text: 'ایران در نیمکره جنوبی قرار دارد.', answer: false, type: 'درست / غلط', category: 'جغرافیا', difficulty: 2),
    DuelQuestion(id: 'q37', text: 'آیا قلب انسان خون را پمپ می‌کند؟', answer: true, type: 'بله / نه', category: 'علمی', difficulty: 1),
    DuelQuestion(id: 'q38', text: 'کوروش بزرگ از پادشاهان هخامنشی بود.', answer: true, type: 'درست / غلط', category: 'تاریخی', difficulty: 2),
    DuelQuestion(id: 'q39', text: 'آیا رمز عبور قوی بهتر است ترکیبی از حروف و اعداد باشد؟', answer: true, type: 'بله / نه', category: 'فناوری', difficulty: 1),
    DuelQuestion(id: 'q40', text: 'HTML یک زبان نشانه‌گذاری برای صفحات وب است.', answer: true, type: 'درست / غلط', category: 'فناوری', difficulty: 2),
    DuelQuestion(id: 'q41', text: 'آیا شب و روز به چرخش زمین مربوط است؟', answer: true, type: 'بله / نه', category: 'علمی', difficulty: 2),
    DuelQuestion(id: 'q42', text: 'استرالیا هم کشور است و هم قاره محسوب می‌شود.', answer: true, type: 'درست / غلط', category: 'جغرافیا', difficulty: 2),
    DuelQuestion(id: 'q43', text: 'آیا مولانا از چهره‌های مهم ادبیات فارسی است؟', answer: true, type: 'بله / نه', category: 'فرهنگ و هنر', difficulty: 1),
    DuelQuestion(id: 'q44', text: 'در تنیس، توپ باید همیشه با پا زده شود.', answer: false, type: 'درست / غلط', category: 'ورزشی', difficulty: 1),
    DuelQuestion(id: 'q45', text: 'آیا مربع چهار ضلع برابر دارد؟', answer: true, type: 'بله / نه', category: 'ریاضی', difficulty: 1),
    DuelQuestion(id: 'q46', text: 'رود نیل از رودهای معروف جهان است.', answer: true, type: 'درست / غلط', category: 'جغرافیا', difficulty: 2),
    DuelQuestion(id: 'q47', text: 'آیا DNA در انتقال ویژگی‌های وراثتی نقش دارد؟', answer: true, type: 'بله / نه', category: 'علمی', difficulty: 3),
    DuelQuestion(id: 'q48', text: 'ابوعلی سینا از دانشمندان مشهور ایرانی بود.', answer: true, type: 'درست / غلط', category: 'تاریخی', difficulty: 2),
    DuelQuestion(id: 'q49', text: 'آیا فایل PDF معمولاً برای نمایش ثابت اسناد استفاده می‌شود؟', answer: true, type: 'بله / نه', category: 'فناوری', difficulty: 1),
    DuelQuestion(id: 'q50', text: 'Wi‑Fi همان برق شهری است.', answer: false, type: 'درست / غلط', category: 'فناوری', difficulty: 1),
    DuelQuestion(id: 'q51', text: 'آیا یخ حالت جامد آب است؟', answer: true, type: 'بله / نه', category: 'علمی', difficulty: 1),
    DuelQuestion(id: 'q52', text: 'جزیره کیش در خلیج فارس قرار دارد.', answer: true, type: 'درست / غلط', category: 'جغرافیا', difficulty: 2),
    DuelQuestion(id: 'q53', text: 'آیا نقاشی یکی از شاخه‌های هنر است؟', answer: true, type: 'بله / نه', category: 'فرهنگ و هنر', difficulty: 1),
    DuelQuestion(id: 'q54', text: 'المپیک هر سال برگزار می‌شود.', answer: false, type: 'درست / غلط', category: 'ورزشی', difficulty: 3),
    DuelQuestion(id: 'q55', text: 'آیا عدد ۱ عدد اول است؟', answer: false, type: 'بله / نه', category: 'ریاضی', difficulty: 2),
    DuelQuestion(id: 'q56', text: 'ژاپن در قاره آسیا قرار دارد.', answer: true, type: 'درست / غلط', category: 'جغرافیا', difficulty: 1),
    DuelQuestion(id: 'q57', text: 'آیا گیاهان برای رشد به نور نیاز دارند؟', answer: true, type: 'بله / نه', category: 'علمی', difficulty: 1),
    DuelQuestion(id: 'q58', text: 'ماشین چاپ در گسترش کتاب‌ها نقش مهمی داشت.', answer: true, type: 'درست / غلط', category: 'تاریخی', difficulty: 3),
    DuelQuestion(id: 'q59', text: 'آیا نسخه پشتیبان برای حفظ اطلاعات مهم است؟', answer: true, type: 'بله / نه', category: 'فناوری', difficulty: 1),
    DuelQuestion(id: 'q60', text: 'اپلیکیشن موبایل فقط روی تلویزیون نصب می‌شود.', answer: false, type: 'درست / غلط', category: 'فناوری', difficulty: 1),
  ];

  static const leaderboard = <Map<String, Object>>[
    {'name': 'علی رستمی', 'score': 2450, 'rank': 'الماس ۲', 'change': '+2', 'wins': 128},
    {'name': 'پارسا نیکو', 'score': 1890, 'rank': 'طلایی', 'change': '+1', 'wins': 74},
    {'name': 'نیما شریفی', 'score': 1200, 'rank': 'نقره‌ای', 'change': '+3', 'wins': 51},
    {'name': 'سینا کریمی', 'score': 980, 'rank': 'نقره‌ای', 'change': '0', 'wins': 39},
    {'name': 'آرمان امیری', 'score': 760, 'rank': 'برنزی ۱', 'change': '-1', 'wins': 24},
    {'name': 'امیر محمدی', 'score': 45, 'rank': 'برنزی ۲', 'change': '0', 'wins': 1},
    {'name': 'مهدی کریمی', 'score': 32, 'rank': 'برنزی ۳', 'change': '0', 'wins': 2},
    {'name': 'سامان احمدی', 'score': 21, 'rank': 'برنزی ۳', 'change': '0', 'wins': 1},
    {'name': 'رضا سلیمانی', 'score': 18, 'rank': 'برنزی ۴', 'change': '0', 'wins': 1},
  ];

  static const missions = <Mission>[
    Mission(icon: Icons.flash_on_rounded, title: 'شروع قدرتمند', description: '۳ مسابقه رقابتی انجام بده', progress: 2, target: 3, reward: 120, color: AppColors.cyan),
    Mission(icon: Icons.local_fire_department_rounded, title: 'کمبو آتشین', description: '۵ جواب درست پشت سر هم بزن', progress: 4, target: 5, reward: 180, color: AppColors.orange),
    Mission(icon: Icons.emoji_events_rounded, title: 'شکارچی جام', description: '۲ مسابقه را برنده شو', progress: 1, target: 2, reward: 250, color: AppColors.gold),
    Mission(icon: Icons.speed_rounded, title: 'جواب برق‌آسا', description: 'زیر ۲ ثانیه جواب درست بده', progress: 1, target: 1, reward: 90, color: AppColors.pink),
  ];

  static const store = <StoreItem>[
    StoreItem(icon: Icons.timer_rounded, title: 'زمان بیشتر', description: '+۳ ثانیه برای یک سوال حساس', price: 350, color: AppColors.cyan, keyName: 'extra_time'),
    StoreItem(icon: Icons.shield_rounded, title: 'سپر خطا', description: 'یک جواب غلط بدون جریمه', price: 450, color: AppColors.green, keyName: 'shield'),
    StoreItem(icon: Icons.bolt_rounded, title: 'ضریب امتیاز', description: 'امتیاز سوال بعدی دو برابر', price: 650, color: AppColors.gold, keyName: 'double_score'),
    StoreItem(icon: Icons.auto_awesome_rounded, title: 'قاب نئونی', description: 'ظاهر ویژه برای کارت پروفایل', price: 1200, color: AppColors.purple, keyName: 'neon_frame'),
  ];
}

class NeonBackground extends StatelessWidget {
  final Widget child;
  const NeonBackground({required this.child, super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [AppColors.bgTop, AppColors.bgMid, AppColors.bgBottom]),
      ),
      child: Stack(
        children: [
          const Positioned(top: -100, right: -70, child: _GlowOrb(size: 240, color: AppColors.blue)),
          const Positioned(top: 230, left: -90, child: _GlowOrb(size: 240, color: AppColors.pink)),
          const Positioned(bottom: -120, right: 60, child: _GlowOrb(size: 260, color: AppColors.purple)),
          Positioned.fill(child: CustomPaint(painter: _GridPainter())),
          child,
        ],
      ),
    );
  }
}

class _GlowOrb extends StatelessWidget {
  final double size;
  final Color color;
  const _GlowOrb({required this.size, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(shape: BoxShape.circle, boxShadow: [BoxShadow(color: color.withOpacity(.26), blurRadius: size * .36, spreadRadius: size * .08)]),
    );
  }
}

class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = Colors.white.withOpacity(.035)..strokeWidth = 1;
    for (double y = 90; y < size.height; y += 74) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
    for (double x = 34; x < size.width; x += 74) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class GlassPanel extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final double radius;
  final Gradient? gradient;
  final Color borderColor;
  final List<BoxShadow>? shadows;

  const GlassPanel({
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.radius = 24,
    this.gradient,
    this.borderColor = Colors.white24,
    this.shadows,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    // v1.4 performance: no BackdropFilter here. Blur was the main reason
    // for slow scrolling on mid-range Android devices.
    return RepaintBoundary(
      child: Container(
        padding: padding,
        decoration: BoxDecoration(
          gradient: gradient ?? LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Colors.white.withOpacity(.105), AppColors.panel, Colors.white.withOpacity(.035)]),
          borderRadius: BorderRadius.circular(radius),
          border: Border.all(color: borderColor.withOpacity(.46), width: 1.0),
          boxShadow: shadows ?? [BoxShadow(color: Colors.black.withOpacity(.24), blurRadius: 14, offset: const Offset(0, 9))],
        ),
        child: child,
      ),
    );
  }
}

class NeonButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback onTap;
  final Color color;
  final bool compact;

  const NeonButton({required this.label, required this.icon, required this.onTap, this.color = AppColors.cyan, this.compact = false, super.key});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(22),
      onTap: onTap,
      child: Container(
        height: compact ? 54 : 70,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          gradient: LinearGradient(colors: [color.withOpacity(.96), color.withOpacity(.24)], begin: Alignment.centerRight, end: Alignment.centerLeft),
          border: Border.all(color: color.withOpacity(.9), width: 1.6),
          boxShadow: [BoxShadow(color: color.withOpacity(.24), blurRadius: 16), BoxShadow(color: Colors.black.withOpacity(.24), blurRadius: 10, offset: const Offset(0, 7))],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            PremiumGameIcon(icon: icon, color: color, size: compact ? 34 : 42, iconSize: compact ? 20 : 25, solid: true),
            const SizedBox(width: 12),
            Text(label, style: TextStyle(fontSize: compact ? 17 : 22, color: Colors.white, fontWeight: FontWeight.w900, shadows: [Shadow(color: color.withOpacity(.75), blurRadius: 12)])),
          ],
        ),
      ),
    );
  }
}

class PlayerAvatar extends StatelessWidget {
  final PlayerProfile player;
  final double size;
  const PlayerAvatar({required this.player, this.size = 58, super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: [player.color, AppColors.purple]), boxShadow: [BoxShadow(color: player.color.withOpacity(.52), blurRadius: 20)]),
      padding: const EdgeInsets.all(3),
      child: Container(decoration: const BoxDecoration(shape: BoxShape.circle, color: Color(0xFF101A3C)), child: Icon(player.avatarIcon, size: size * .55, color: Colors.white)),
    );
  }
}

class PremiumGameIcon extends StatelessWidget {
  final IconData icon;
  final Color color;
  final double size;
  final double iconSize;
  final String? badge;
  final bool solid;

  const PremiumGameIcon({
    required this.icon,
    required this.color,
    this.size = 44,
    this.iconSize = 24,
    this.badge,
    this.solid = false,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: Stack(
        clipBehavior: Clip.none,
        alignment: Alignment.center,
        children: [
          Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(size * .32),
                gradient: RadialGradient(
                  center: const Alignment(-.35, -.45),
                  radius: 1.1,
                  colors: solid
                      ? [Colors.white.withOpacity(.34), color.withOpacity(.96), color.withOpacity(.42)]
                      : [Colors.white.withOpacity(.20), color.withOpacity(.24), const Color(0xFF08122F)],
                ),
                border: Border.all(color: color.withOpacity(.82), width: 1.1),
                boxShadow: [
                  BoxShadow(color: color.withOpacity(.22), blurRadius: size * .28),
                  BoxShadow(color: Colors.black.withOpacity(.22), blurRadius: size * .18, offset: Offset(0, size * .10)),
                ],
              ),
            ),
          ),
          Positioned(
            top: size * .13,
            left: size * .16,
            child: Container(width: size * .30, height: size * .10, decoration: BoxDecoration(color: Colors.white.withOpacity(.22), borderRadius: BorderRadius.circular(size))),
          ),
          Icon(icon, color: Colors.white, size: iconSize, shadows: [Shadow(color: color.withOpacity(.55), blurRadius: 7)]),
          if (badge != null)
            Positioned(
              top: -6,
              right: -6,
              child: Container(
                width: size * .42,
                height: size * .42,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const LinearGradient(colors: [Colors.white, AppColors.gold]),
                  border: Border.all(color: Colors.black.withOpacity(.18)),
                  boxShadow: [BoxShadow(color: AppColors.gold.withOpacity(.44), blurRadius: 10)],
                ),
                child: Text(badge!, style: const TextStyle(color: Color(0xFF1A1530), fontSize: 11, fontWeight: FontWeight.w900)),
              ),
            ),
        ],
      ),
    );
  }
}


class ProfileSetupScreen extends StatefulWidget {
  const ProfileSetupScreen({super.key});

  @override
  State<ProfileSetupScreen> createState() => _ProfileSetupScreenState();
}

class _ProfileSetupScreenState extends State<ProfileSetupScreen> {
  final _nameController = TextEditingController(text: 'علی رستمی');
  final _cityController = TextEditingController(text: 'تهران');
  final _titleController = TextEditingController(text: 'بازیکن رقابتی');
  int _avatarIndex = 0;
  int _colorIndex = 0;

  static const _avatars = [Icons.person_rounded, Icons.person_2_rounded, Icons.person_3_rounded, Icons.person_4_rounded, Icons.face_rounded, Icons.sports_esports_rounded];
  static const _colors = [AppColors.cyan, AppColors.pink, AppColors.purple, AppColors.green, AppColors.gold, AppColors.orange];

  @override
  void dispose() {
    _nameController.dispose();
    _cityController.dispose();
    _titleController.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    RuntimeState.instance.haptic('win');
    await RuntimeState.instance.updateProfile(
      name: _nameController.text,
      city: _cityController.text,
      title: _titleController.text,
      avatarIndex: _avatarIndex,
      colorIndex: _colorIndex,
    );
    if (!mounted) return;
    Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const ShellScreen()));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: NeonBackground(
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(18),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const SizedBox(height: 14),
              Center(child: Column(children: const [
                _GameLogo(),
                Text('پروفایلت را بساز و وارد رقابت شو', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: Colors.white70)),
              ])),
              const SizedBox(height: 20),
              GlassPanel(
                radius: 30,
                borderColor: _colors[_colorIndex],
                padding: const EdgeInsets.all(18),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Center(child: PlayerAvatar(player: SampleData.player.copyWith(name: _nameController.text.isEmpty ? 'بازیکن دوئل' : _nameController.text, color: _colors[_colorIndex], avatarIcon: _avatars[_avatarIndex]), size: 92)),
                  const SizedBox(height: 18),
                  _ProfileTextField(controller: _nameController, label: 'نام نمایشی', icon: Icons.badge_rounded, onChanged: (_) => setState(() {})),
                  const SizedBox(height: 12),
                  _ProfileTextField(controller: _cityController, label: 'شهر', icon: Icons.location_city_rounded),
                  const SizedBox(height: 12),
                  _ProfileTextField(controller: _titleController, label: 'عنوان کوتاه', icon: Icons.workspace_premium_rounded),
                  const SizedBox(height: 18),
                  const Text('انتخاب آواتار', style: TextStyle(fontWeight: FontWeight.w900)),
                  const SizedBox(height: 10),
                  Wrap(spacing: 10, runSpacing: 10, children: List.generate(_avatars.length, (i) => _ChoiceBubble(icon: _avatars[i], color: _colors[_colorIndex], selected: i == _avatarIndex, onTap: () => setState(() => _avatarIndex = i)))),
                  const SizedBox(height: 18),
                  const Text('رنگ پروفایل', style: TextStyle(fontWeight: FontWeight.w900)),
                  const SizedBox(height: 10),
                  Wrap(spacing: 10, children: List.generate(_colors.length, (i) => InkWell(borderRadius: BorderRadius.circular(18), onTap: () => setState(() => _colorIndex = i), child: Container(width: 38, height: 38, decoration: BoxDecoration(shape: BoxShape.circle, color: _colors[i], border: Border.all(color: i == _colorIndex ? Colors.white : Colors.white24, width: i == _colorIndex ? 2.4 : 1), boxShadow: [BoxShadow(color: _colors[i].withOpacity(.35), blurRadius: 14)]))))),
                ]),
              ),
              const SizedBox(height: 18),
              NeonButton(label: 'شروع بازی', icon: Icons.play_arrow_rounded, onTap: _save),
            ]),
          ),
        ),
      ),
    );
  }
}

class _ProfileTextField extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final IconData icon;
  final ValueChanged<String>? onChanged;
  const _ProfileTextField({required this.controller, required this.label, required this.icon, this.onChanged});

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      onChanged: onChanged,
      textInputAction: TextInputAction.next,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon, color: AppColors.cyan),
        filled: true,
        fillColor: Colors.white.withOpacity(.055),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(20), borderSide: BorderSide(color: Colors.white.withOpacity(.12))),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(20), borderSide: const BorderSide(color: AppColors.cyan, width: 1.4)),
      ),
    );
  }
}

class _ChoiceBubble extends StatelessWidget {
  final IconData icon;
  final Color color;
  final bool selected;
  final VoidCallback onTap;
  const _ChoiceBubble({required this.icon, required this.color, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(20),
      onTap: onTap,
      child: Container(
        width: 48,
        height: 48,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: LinearGradient(colors: [color.withOpacity(selected ? .85 : .22), Colors.white.withOpacity(.05)]),
          border: Border.all(color: selected ? Colors.white : color.withOpacity(.35), width: selected ? 2 : 1),
          boxShadow: selected ? [BoxShadow(color: color.withOpacity(.35), blurRadius: 18)] : null,
        ),
        child: Icon(icon, color: Colors.white, size: 25),
      ),
    );
  }
}

class ShellScreen extends StatefulWidget {
  const ShellScreen({super.key});

  @override
  State<ShellScreen> createState() => _ShellScreenState();
}

class _ShellScreenState extends State<ShellScreen> {
  int _index = 2;
  late final List<Widget> _pages;

  @override
  void initState() {
    super.initState();
    _pages = const [StoreScreen(), MissionsScreen(), HomeScreen(), FriendsScreen(), ProfileScreen()];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: NeonBackground(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 12, 18, 12),
            child: Column(
              children: [
                Expanded(child: IndexedStack(index: _index, children: _pages)),
                const SizedBox(height: 8),
                DuelBottomNav(current: _index, onChanged: (value) => setState(() => _index = value)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class DuelBottomNav extends StatelessWidget {
  final int current;
  final ValueChanged<int> onChanged;
  const DuelBottomNav({required this.current, required this.onChanged, super.key});

  @override
  Widget build(BuildContext context) {
    const items = [
      _NavItemData(Icons.storefront_rounded, 'فروشگاه', AppColors.gold),
      _NavItemData(Icons.flag_rounded, 'ماموریت', AppColors.purple),
      _NavItemData(Icons.bolt_rounded, 'خانه', AppColors.cyan),
      _NavItemData(Icons.group_rounded, 'دوستان', AppColors.pink),
      _NavItemData(Icons.person_rounded, 'پروفایل', AppColors.green),
    ];
    return GlassPanel(
      radius: 30,
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 6),
      borderColor: AppColors.cyan.withOpacity(.55),
      gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.white.withOpacity(.13), const Color(0xCC070D26), Colors.white.withOpacity(.045)]),
      shadows: [BoxShadow(color: AppColors.cyan.withOpacity(.16), blurRadius: 34, offset: const Offset(0, -4)), BoxShadow(color: Colors.black.withOpacity(.44), blurRadius: 28, offset: const Offset(0, 18))],
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: List.generate(items.length, (i) => Expanded(child: _DuelNavIcon(item: items[i], selected: i == current, onTap: () => onChanged(i)))),
      ),
    );
  }
}

class _NavItemData {
  final IconData icon;
  final String label;
  final Color color;
  const _NavItemData(this.icon, this.label, this.color);
}

class _DuelNavIcon extends StatelessWidget {
  final _NavItemData item;
  final bool selected;
  final VoidCallback onTap;
  const _DuelNavIcon({required this.item, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(22),
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 260),
        curve: Curves.easeOutCubic,
        margin: const EdgeInsets.symmetric(horizontal: 2),
        padding: EdgeInsets.symmetric(vertical: selected ? 8 : 7, horizontal: 4),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          gradient: selected
              ? LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [item.color.withOpacity(.92), AppColors.blue.withOpacity(.50), Colors.white.withOpacity(.06)])
              : LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.white.withOpacity(.06), Colors.white.withOpacity(.015)]),
          border: Border.all(color: selected ? item.color.withOpacity(.92) : Colors.white.withOpacity(.08), width: selected ? 1.3 : .8),
          boxShadow: selected ? [BoxShadow(color: item.color.withOpacity(.38), blurRadius: 20, offset: const Offset(0, 8)), BoxShadow(color: Colors.black.withOpacity(.25), blurRadius: 16, offset: const Offset(0, 10))] : null,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            PremiumGameIcon(icon: item.icon, color: selected ? item.color : Colors.blueGrey, size: 34, iconSize: 20, solid: selected),
            const SizedBox(height: 4),
            Text(item.label, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: selected ? 10.5 : 9.8, color: selected ? Colors.white : Colors.white.withOpacity(.50), fontWeight: selected ? FontWeight.w900 : FontWeight.w700)),
          ],
        ),
      ),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      key: const ValueKey('home'),
      physics: const ClampingScrollPhysics(),
      child: Column(
        children: [
          ValueListenableBuilder<PlayerProfile>(
            valueListenable: RuntimeState.instance.player,
            builder: (_, player, __) => _HomeHeader(player: player),
          ),
          const SizedBox(height: 20),
          const _GameLogo(),
          const SizedBox(height: 14),
          const _FeaturedHomeCard(),
          const SizedBox(height: 16),
          NeonButton(label: 'شروع رقابت', icon: Icons.flash_on_rounded, onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const MatchmakingScreen(mode: DuelMode.ranked)))),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(child: NeonButton(label: 'تمرین', icon: Icons.school_rounded, compact: true, color: AppColors.green, onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const MatchmakingScreen(mode: DuelMode.practice))))),
              const SizedBox(width: 12),
              Expanded(child: NeonButton(label: 'اتاق خصوصی', icon: Icons.groups_rounded, compact: true, color: AppColors.pink, onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const PrivateRoomScreen())))),
            ],
          ),
          const SizedBox(height: 18),
          const _StatsStrip(),
          const SizedBox(height: 18),
          _ModeCards(),
          const SizedBox(height: 18),
          _LeaderboardPreview(onOpen: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const LeaderboardScreen()))),
          const SizedBox(height: 18),
        ],
      ),
    );
  }
}

class _HomeHeader extends StatelessWidget {
  final PlayerProfile player;
  const _HomeHeader({required this.player});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        PlayerAvatar(player: player, size: 58),
        const SizedBox(width: 10),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(player.name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
            const SizedBox(height: 5),
            Row(children: [const Icon(Icons.diamond_rounded, color: AppColors.purple, size: 17), const SizedBox(width: 5), Text(player.rank, style: TextStyle(color: Colors.white.withOpacity(.72), fontSize: 12))]),
          ]),
        ),
        _CoinPill(amount: player.coins),
        const SizedBox(width: 8),
        _RoundIconButton(icon: Icons.quiz_rounded, onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const QuestionBankScreen()))),
        const SizedBox(width: 8),
        _RoundIconButton(icon: Icons.settings_rounded, onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SettingsScreen()))),
      ],
    );
  }
}

class _CoinPill extends StatelessWidget {
  final int amount;
  const _CoinPill({required this.amount});

  @override
  Widget build(BuildContext context) {
    return GlassPanel(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      radius: 16,
      borderColor: AppColors.gold,
      child: Row(children: [const Icon(Icons.monetization_on_rounded, color: AppColors.gold, size: 19), const SizedBox(width: 5), Text(_formatNumber(amount), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 13)), const SizedBox(width: 4), const Icon(Icons.add_box_rounded, color: AppColors.gold, size: 16)]),
    );
  }
}

class _RoundIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _RoundIconButton({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(borderRadius: BorderRadius.circular(16), onTap: onTap, child: GlassPanel(padding: const EdgeInsets.all(9), radius: 16, child: Icon(icon, size: 22)));
  }
}

class _GameLogo extends StatelessWidget {
  const _GameLogo();

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Stack(alignment: Alignment.center, children: [
        Text('دوئل', style: TextStyle(fontSize: 66, fontWeight: FontWeight.w900, letterSpacing: -3, foreground: Paint()..style = PaintingStyle.stroke..strokeWidth = 7..color = AppColors.cyan.withOpacity(.55))),
        ShaderMask(shaderCallback: (rect) => const LinearGradient(colors: [Colors.white, AppColors.cyan, AppColors.pink]).createShader(rect), child: const Text('دوئل', style: TextStyle(fontSize: 66, fontWeight: FontWeight.w900, letterSpacing: -3))),
      ]),
      Transform.translate(offset: const Offset(0, -14), child: Stack(alignment: Alignment.center, children: [
        Text('جواب', style: TextStyle(fontSize: 56, fontWeight: FontWeight.w900, letterSpacing: -3, foreground: Paint()..style = PaintingStyle.stroke..strokeWidth = 6..color = AppColors.pink.withOpacity(.52))),
        ShaderMask(shaderCallback: (rect) => const LinearGradient(colors: [Colors.white, AppColors.pink, AppColors.purple]).createShader(rect), child: const Text('جواب', style: TextStyle(fontSize: 56, fontWeight: FontWeight.w900, letterSpacing: -3))),
      ])),
    ]);
  }
}

class _FeaturedHomeCard extends StatelessWidget {
  const _FeaturedHomeCard();

  @override
  Widget build(BuildContext context) {
    return GlassPanel(
      radius: 28,
      padding: const EdgeInsets.all(14),
      borderColor: AppColors.cyan,
      gradient: LinearGradient(
        begin: Alignment.centerRight,
        end: Alignment.centerLeft,
        colors: [AppColors.cyan.withOpacity(.18), const Color(0xDD080F2E), AppColors.pink.withOpacity(.13)],
      ),
      shadows: [
        BoxShadow(color: AppColors.cyan.withOpacity(.20), blurRadius: 34, offset: const Offset(0, 14)),
        BoxShadow(color: AppColors.pink.withOpacity(.12), blurRadius: 30, offset: const Offset(-8, 12)),
      ],
      child: Row(children: [
        Stack(alignment: Alignment.center, children: [
          Container(width: 92, height: 78, decoration: BoxDecoration(borderRadius: BorderRadius.circular(22), gradient: RadialGradient(colors: [AppColors.gold.withOpacity(.28), AppColors.pink.withOpacity(.10), Colors.transparent]))),
          const PremiumTrophy(size: 64),
        ]),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: const [
            Expanded(child: Text('حالت کلاسیک', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: Colors.white))),
            PremiumGameIcon(icon: Icons.bolt_rounded, color: AppColors.cyan, size: 40, iconSize: 23, solid: true),
          ]),
          const SizedBox(height: 7),
          Text('۱۰ سؤال سریع، تایمر هیجانی، امتیاز بیشتر برای جواب سریع‌تر', style: TextStyle(fontSize: 12, color: Colors.white.withOpacity(.68), height: 1.55, fontWeight: FontWeight.w700)),
          const SizedBox(height: 10),
          Row(children: [
            _FeaturePill(icon: Icons.timer_rounded, text: '۷ ثانیه'),
            const SizedBox(width: 8),
            _FeaturePill(icon: Icons.local_fire_department_rounded, text: 'کمبو'),
          ]),
        ])),
      ]),
    );
  }
}

class _FeaturePill extends StatelessWidget {
  final IconData icon;
  final String text;
  const _FeaturePill({required this.icon, required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(999), color: Colors.white.withOpacity(.07), border: Border.all(color: Colors.white.withOpacity(.12))),
      child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(icon, size: 14, color: AppColors.gold), const SizedBox(width: 5), Text(text, style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.w800))]),
    );
  }
}

class _StatsStrip extends StatelessWidget {
  const _StatsStrip();

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<PlayerProfile>(
      valueListenable: RuntimeState.instance.player,
      builder: (_, player, __) => GlassPanel(
        radius: 26,
        padding: const EdgeInsets.all(14),
        borderColor: AppColors.purple,
        gradient: LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [Colors.white.withOpacity(.12), AppColors.cyan.withOpacity(.08), AppColors.pink.withOpacity(.08), Colors.white.withOpacity(.035)]),
        shadows: [BoxShadow(color: AppColors.purple.withOpacity(.18), blurRadius: 28, offset: const Offset(0, 14))],
        child: Row(children: [
          Expanded(child: _MiniStat(icon: Icons.speed_rounded, label: 'میانگین سرعت', value: '۱.۲ ثانیه', color: AppColors.cyan)),
          Container(width: 1, height: 58, color: Colors.white.withOpacity(.12)),
          Expanded(child: _MiniStat(icon: Icons.local_fire_department_rounded, label: 'برد امروز', value: '${player.streak}', color: AppColors.pink)),
          Container(width: 1, height: 58, color: Colors.white.withOpacity(.12)),
          Expanded(child: _MiniStat(icon: Icons.emoji_events_rounded, label: 'جام', value: '${player.trophy}', color: AppColors.gold)),
        ]),
      ),
    );
  }
}

class _MiniStat extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color color;
  const _MiniStat({required this.icon, required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Column(children: [PremiumGameIcon(icon: icon, color: color, size: 36, iconSize: 21, solid: true), const SizedBox(height: 8), Text(value, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)), Text(label, style: TextStyle(fontSize: 11, color: Colors.white.withOpacity(.62), fontWeight: FontWeight.w700))]);
  }
}

class _ModeCards extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Expanded(child: _ModeCard(mode: DuelMode.daily, icon: Icons.today_rounded, color: AppColors.gold, onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const MatchmakingScreen(mode: DuelMode.daily))))),
      const SizedBox(width: 12),
      Expanded(child: _ModeCard(mode: DuelMode.private, icon: Icons.lock_rounded, color: AppColors.pink, onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const PrivateRoomScreen())))),
    ]);
  }
}

class _ModeCard extends StatelessWidget {
  final DuelMode mode;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  const _ModeCard({required this.mode, required this.icon, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(24),
      onTap: onTap,
      child: GlassPanel(
        radius: 24,
        borderColor: color,
        padding: const EdgeInsets.all(14),
        gradient: LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [color.withOpacity(.20), Colors.white.withOpacity(.06), Colors.black.withOpacity(.08)]),
        shadows: [BoxShadow(color: color.withOpacity(.16), blurRadius: 24, offset: const Offset(0, 12))],
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [PremiumGameIcon(icon: icon, color: color, size: 40, iconSize: 23, solid: true), const Spacer(), Icon(Icons.chevron_left_rounded, color: Colors.white.withOpacity(.45))]),
          const SizedBox(height: 12),
          Text(mode.title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
          const SizedBox(height: 6),
          Text(mode.subtitle, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.white.withOpacity(.65), fontSize: 11, height: 1.5, fontWeight: FontWeight.w600)),
        ]),
      ),
    );
  }
}

class _LeaderboardPreview extends StatelessWidget {
  final VoidCallback onOpen;
  const _LeaderboardPreview({required this.onOpen});

  @override
  Widget build(BuildContext context) {
    return GlassPanel(
      padding: const EdgeInsets.all(14),
      child: Column(children: [
        Row(children: [const Expanded(child: Text('رتبه‌بندی', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900))), TextButton(onPressed: onOpen, child: const Text('مشاهده همه'))]),
        const SizedBox(height: 8),
        ...SampleData.leaderboard.take(3).toList().asMap().entries.map((entry) => _RankRow(index: entry.key + 1, data: entry.value)),
      ]),
    );
  }
}

class _RankRow extends StatelessWidget {
  final int index;
  final Map<String, Object> data;
  const _RankRow({required this.index, required this.data});

  @override
  Widget build(BuildContext context) {
    final color = index == 1 ? AppColors.gold : index == 2 ? Colors.blueGrey.shade100 : Colors.orangeAccent;
    final name = data['name'].toString();
    final rank = data['rank'].toString();
    final wins = data['wins'] ?? 0;
    final score = data['score'] as int;
    return Container(
      margin: const EdgeInsets.only(bottom: 9),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(16), color: Colors.white.withOpacity(index == 1 ? .12 : .06), border: Border.all(color: color.withOpacity(.35))),
      child: Row(children: [
        Container(width: 30, height: 30, alignment: Alignment.center, decoration: BoxDecoration(shape: BoxShape.circle, color: color.withOpacity(.18), border: Border.all(color: color.withOpacity(.7))), child: Text('$index', style: TextStyle(color: color, fontWeight: FontWeight.w900))),
        const SizedBox(width: 10),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(name, style: const TextStyle(fontWeight: FontWeight.w800)),
            const SizedBox(height: 3),
            Text('$rank • $wins برد', style: TextStyle(fontSize: 10.5, color: Colors.white.withOpacity(.54))),
          ]),
        ),
        const SizedBox(width: 8),
        Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Text(_formatNumber(score), style: const TextStyle(color: AppColors.gold, fontWeight: FontWeight.w900)),
          Text('جام', style: TextStyle(fontSize: 10, color: Colors.white.withOpacity(.46))),
        ]),
      ]),
    );
  }
}

class MatchmakingScreen extends StatefulWidget {
  final DuelMode mode;
  const MatchmakingScreen({required this.mode, super.key});

  @override
  State<MatchmakingScreen> createState() => _MatchmakingScreenState();
}

class _MatchmakingScreenState extends State<MatchmakingScreen> {
  Timer? _timer;
  int _phase = 0;
  int _countdown = 3;
  late final PlayerProfile opponent;

  @override
  void initState() {
    super.initState();
    opponent = SampleData.opponents[Random().nextInt(SampleData.opponents.length)];
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      setState(() {
        if (_phase < 3) {
          _phase++;
        } else if (_countdown > 1) {
          _countdown--;
        } else {
          _timer?.cancel();
          Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => GameScreen(mode: widget.mode, opponent: opponent)));
        }
      });
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final found = _phase >= 2;
    return Scaffold(
      body: NeonBackground(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(children: [
              _ScreenHeader(title: widget.mode.title, onBack: () => Navigator.of(context).pop()),
              const Spacer(),
              Text(found ? 'حریف پیدا شد!' : widget.mode == DuelMode.practice ? 'در حال آماده‌سازی تمرین...' : 'در حال پیدا کردن حریف...', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
              const SizedBox(height: 30),
              _VersusMatchCard(found: found, opponent: opponent),
              const SizedBox(height: 34),
              Text(found ? 'بازی شروع می‌شود' : 'در حال بررسی حریف‌ها', style: TextStyle(color: Colors.white.withOpacity(.72))),
              const SizedBox(height: 20),
              Directionality(
                textDirection: TextDirection.ltr,
                child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  _CountdownBox(label: found ? '$_countdown' : '3', active: found && _countdown == 3, color: AppColors.cyan),
                  const SizedBox(width: 12),
                  _CountdownBox(label: '2', active: found && _countdown == 2, color: AppColors.purple),
                  const SizedBox(width: 12),
                  _CountdownBox(label: '1', active: found && _countdown == 1, color: AppColors.pink),
                ]),
              ),
              const Spacer(),
              GlassPanel(padding: const EdgeInsets.all(13), child: Row(children: [const Icon(Icons.shield_rounded, color: AppColors.cyan), const SizedBox(width: 10), Expanded(child: Text('حریف‌ها با پروفایل و آمار کامل وارد مسابقه می‌شوند و سطح بازی بر اساس سختی سوال تغییر می‌کند.', style: TextStyle(color: Colors.white.withOpacity(.72), fontSize: 12)))])),
            ]),
          ),
        ),
      ),
    );
  }
}

class _VersusMatchCard extends StatelessWidget {
  final bool found;
  final PlayerProfile opponent;
  const _VersusMatchCard({required this.found, required this.opponent});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<PlayerProfile>(
      valueListenable: RuntimeState.instance.player,
      builder: (_, player, __) => SizedBox(
        height: 310,
        child: Stack(alignment: Alignment.center, children: [
          Container(width: 270, height: 270, decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: AppColors.cyan.withOpacity(.25), width: 2), boxShadow: [BoxShadow(color: AppColors.cyan.withOpacity(.18), blurRadius: 55)])),
          Positioned(top: 8, child: _MatchPlayerCard(player: player, color: AppColors.cyan, isUnknown: false)),
          Positioned(bottom: 8, child: _MatchPlayerCard(player: opponent, color: AppColors.pink, isUnknown: !found)),
          ShaderMask(shaderCallback: (rect) => const LinearGradient(colors: [AppColors.cyan, Colors.white, AppColors.pink]).createShader(rect), child: const Text('VS', style: TextStyle(fontSize: 68, fontWeight: FontWeight.w900))),
        ]),
      ),
    );
  }
}

class _MatchPlayerCard extends StatelessWidget {
  final PlayerProfile player;
  final Color color;
  final bool isUnknown;
  const _MatchPlayerCard({required this.player, required this.color, required this.isUnknown});

  @override
  Widget build(BuildContext context) {
    return GlassPanel(
      radius: 24,
      borderColor: color,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      gradient: LinearGradient(colors: [color.withOpacity(.16), Colors.white.withOpacity(.05)]),
      child: SizedBox(width: 246, child: Row(children: [
        isUnknown ? Container(width: 56, height: 56, alignment: Alignment.center, decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withOpacity(.08), border: Border.all(color: color.withOpacity(.5))), child: const Text('؟', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900))) : PlayerAvatar(player: player, size: 56),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
          Text(isUnknown ? 'حریف در حال جستجو' : player.name, style: const TextStyle(fontWeight: FontWeight.w900)),
          const SizedBox(height: 6),
          Text(isUnknown ? 'در حال بررسی...' : '${player.rank} • ${player.city} • ${player.wins} برد', style: TextStyle(fontSize: 12, color: Colors.white.withOpacity(.65))),
        ])),
      ])),
    );
  }
}

class _CountdownBox extends StatelessWidget {
  final String label;
  final bool active;
  final Color color;
  const _CountdownBox({required this.label, required this.active, required this.color});

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(duration: const Duration(milliseconds: 220), width: active ? 68 : 58, height: active ? 68 : 58, alignment: Alignment.center, decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), gradient: LinearGradient(colors: [color.withOpacity(active ? .9 : .28), color.withOpacity(.08)]), border: Border.all(color: color.withOpacity(active ? .95 : .35), width: 1.4), boxShadow: active ? [BoxShadow(color: color.withOpacity(.45), blurRadius: 26)] : null), child: Text(label, style: TextStyle(fontSize: active ? 32 : 25, fontWeight: FontWeight.w900)));
  }
}

class GameScreen extends StatefulWidget {
  final DuelMode mode;
  final PlayerProfile opponent;
  const GameScreen({required this.mode, required this.opponent, super.key});

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> {
  static const int secondsPerQuestion = 7;
  final _random = Random();
  late final List<DuelQuestion> questions;
  Timer? _questionTimer;
  Timer? _opponentTimer;
  DateTime _questionStartedAt = DateTime.now();

  int _questionIndex = 0;
  int _secondsLeft = secondsPerQuestion;
  int _playerScore = 0;
  int _opponentScore = 0;
  int _combo = 0;
  int _opponentCombo = 0;
  int _maxCombo = 0;
  int _correct = 0;
  int _wrong = 0;
  int _fastestMs = 999999;
  int _extraTime = 1;
  int _shield = 1;
  int _doubleScore = 1;
  bool _shieldActive = false;
  bool _doubleActive = false;
  bool _answered = false;
  bool? _selectedAnswer;
  bool? _lastWasCorrect;
  String? _feedbackText;
  bool _opponentAnswered = false;

  DuelQuestion get _question => questions[_questionIndex];

  @override
  void initState() {
    super.initState();
    questions = _buildQuestions();
    final inv = RuntimeState.instance.inventory.value;
    _extraTime = 1 + (inv['extra_time'] ?? 0);
    _shield = 1 + (inv['shield'] ?? 0);
    _doubleScore = 1 + (inv['double_score'] ?? 0);
    _startQuestion();
  }

  List<DuelQuestion> _buildQuestions() {
    final list = [...SampleData.questions]..shuffle(_random);
    if (widget.mode == DuelMode.daily) return list.where((q) => q.difficulty <= 2).take(10).toList();
    if (widget.mode == DuelMode.practice) return list.take(8).toList();
    return list.take(10).toList();
  }

  @override
  void dispose() {
    _questionTimer?.cancel();
    _opponentTimer?.cancel();
    super.dispose();
  }

  void _startQuestion() {
    _questionTimer?.cancel();
    _opponentTimer?.cancel();
    setState(() {
      _secondsLeft = secondsPerQuestion;
      _answered = false;
      _selectedAnswer = null;
      _lastWasCorrect = null;
      _feedbackText = null;
      _opponentAnswered = false;
      _questionStartedAt = DateTime.now();
    });
    final jitter = _random.nextInt(1100) - 550;
    final naturalDelay = (widget.opponent.avgResponseMs + jitter).clamp(1100, 6200).toInt();
    final opponentDelay = Duration(milliseconds: naturalDelay);
    _opponentTimer = Timer(opponentDelay, _simulateOpponentAnswer);
    _questionTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) return;
      if (_secondsLeft <= 1) {
        timer.cancel();
        if (!_answered) {
          setState(() {
            _combo = 0;
            _wrong++;
            _lastWasCorrect = false;
            _feedbackText = 'زمان تمام شد';
          });
        }
        Future.delayed(const Duration(milliseconds: 650), _goNextQuestion);
      } else {
        setState(() => _secondsLeft--);
      }
    });
  }

  void _simulateOpponentAnswer() {
    if (!mounted || _opponentAnswered) return;

    final isTrailing = _opponentScore < _playerScore;
    final categoryAffinity = _categoryAffinity(widget.opponent.id, _question.category);
    final skipChance = (widget.opponent.noAnswerRate + (_question.difficulty * 2) - (isTrailing ? 2 : 0)).clamp(4, 32) / 100;
    final didSkip = _random.nextDouble() < skipChance;
    final difficultyPenalty = _question.difficulty * .06;
    final pressureBoost = isTrailing ? .035 : -.015;
    final modeBoost = widget.mode == DuelMode.practice ? -.06 : 0.0;
    final accuracy = (widget.opponent.accuracy + categoryAffinity + pressureBoost + modeBoost - difficultyPenalty).clamp(.20, .76);
    final isCorrect = !didSkip && _random.nextDouble() < accuracy;
    final speedBonus = max(0, _secondsLeft * 4);

    setState(() {
      _opponentAnswered = true;
      if (isCorrect) {
        _opponentCombo++;
        final comboBonus = _opponentCombo >= 3 ? 22 : 0;
        _opponentScore += 54 + speedBonus + comboBonus + (_random.nextInt(12));
      } else {
        _opponentCombo = 0;
        if (!didSkip && _random.nextDouble() < .18) {
          _opponentScore = max(0, _opponentScore - 10);
        }
      }
    });
  }

  double _categoryAffinity(String opponentId, String category) {
    final seed = opponentId.hashCode + category.hashCode;
    final value = seed.abs() % 5;
    switch (value) {
      case 0:
        return .08;
      case 1:
        return .04;
      case 2:
        return 0;
      case 3:
        return -.035;
      default:
        return -.07;
    }
  }

  void _submitAnswer(bool value) {
    if (_answered) return;
    RuntimeState.instance.haptic();
    _questionTimer?.cancel();
    final responseMs = DateTime.now().difference(_questionStartedAt).inMilliseconds;
    final isCorrect = value == _question.answer;
    final speedBonus = max(0, _secondsLeft * 6);
    setState(() {
      _answered = true;
      _selectedAnswer = value;
      _lastWasCorrect = isCorrect;
      if (isCorrect) {
        _combo++;
        _correct++;
        _maxCombo = max(_maxCombo, _combo);
        _fastestMs = min(_fastestMs, responseMs);
        final multiplier = _doubleActive ? 2 : 1;
        final comboBonus = _combo >= 3 ? 50 : 0;
        _playerScore += (100 + speedBonus + comboBonus) * multiplier;
        _feedbackText = _doubleActive ? 'پاسخ درست؛ امتیاز دو برابر شد' : 'پاسخ درست؛ امتیاز سرعت گرفتی';
        _doubleActive = false;
      } else {
        RuntimeState.instance.haptic('wrong');
        _combo = 0;
        _wrong++;
        if (_shieldActive) {
          _feedbackText = 'سپر خطا فعال بود؛ جریمه حذف شد';
          _shieldActive = false;
        } else {
          _playerScore = max(0, _playerScore - 40);
          _feedbackText = 'پاسخ اشتباه؛ ۴۰ امتیاز کم شد';
        }
      }
    });
    Future.delayed(const Duration(milliseconds: 900), _goNextQuestion);
  }

  void _useExtraTime() {
    if (_answered || _extraTime <= 0) return;
    RuntimeState.instance.haptic();
    setState(() {
      _extraTime--;
      _secondsLeft = min(12, _secondsLeft + 3);
    });
  }

  void _useShield() {
    if (_answered || _shield <= 0 || _shieldActive) return;
    RuntimeState.instance.haptic();
    setState(() {
      _shield--;
      _shieldActive = true;
    });
  }

  void _useDoubleScore() {
    if (_answered || _doubleScore <= 0 || _doubleActive) return;
    RuntimeState.instance.haptic();
    setState(() {
      _doubleScore--;
      _doubleActive = true;
    });
  }

  void _goNextQuestion() {
    if (!mounted) return;
    _questionTimer?.cancel();
    _opponentTimer?.cancel();
    if (_questionIndex >= questions.length - 1) {
      final won = _playerScore >= _opponentScore;
      final stats = GameStats(
        playerScore: _playerScore,
        opponentScore: _opponentScore,
        correctAnswers: _correct,
        wrongAnswers: _wrong,
        maxCombo: _maxCombo,
        fastestMs: _fastestMs == 999999 ? 0 : _fastestMs,
        coins: widget.mode == DuelMode.practice ? 0 : (won ? 200 : 60),
        xp: 90 + (_correct * 12),
        trophyChange: widget.mode == DuelMode.practice ? 0 : (won ? 28 : -14),
        mode: widget.mode,
        player: RuntimeState.instance.player.value,
        opponent: widget.opponent,
      );
      RuntimeState.instance.haptic(won ? 'win' : 'wrong');
      RuntimeState.instance.applyMatch(stats);
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => ResultScreen(stats: stats)));
      return;
    }
    setState(() => _questionIndex++);
    _startQuestion();
  }

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.sizeOf(context).height;
    final compact = screenHeight < 820;
    final progress = (_questionIndex + 1) / questions.length;
    final positiveLabel = _question.type.contains('درست') ? 'درست' : 'بله';
    final negativeLabel = _question.type.contains('درست') ? 'غلط' : 'نه';
    Color answerColor(bool option) {
      if (!_answered) return option ? AppColors.green : AppColors.red;
      if (option == _question.answer) return AppColors.green;
      if (option == _selectedAnswer) return AppColors.red;
      return Colors.blueGrey;
    }
    bool answerEmphasis(bool option) => _answered && (option == _question.answer || option == _selectedAnswer);

    return Scaffold(
      body: NeonBackground(
        child: SafeArea(
          child: Padding(
            padding: EdgeInsets.fromLTRB(14, compact ? 8 : 10, 14, compact ? 9 : 12),
            child: Column(children: [
              Row(children: [
                Expanded(child: ValueListenableBuilder<PlayerProfile>(valueListenable: RuntimeState.instance.player, builder: (_, player, __) => PlayerScoreCard(player: player, score: _playerScore, alignRight: true, compact: compact))),
                Padding(padding: const EdgeInsets.symmetric(horizontal: 7), child: ShaderMask(shaderCallback: (rect) => const LinearGradient(colors: [AppColors.cyan, Colors.white, AppColors.pink]).createShader(rect), child: Text('VS', style: TextStyle(fontWeight: FontWeight.w900, fontSize: compact ? 18 : 20)))),
                Expanded(child: PlayerScoreCard(player: widget.opponent, score: _opponentScore, alignRight: false, compact: compact)),
              ]),
              SizedBox(height: compact ? 10 : 12),
              Row(children: [
                Expanded(child: ClipRRect(borderRadius: BorderRadius.circular(12), child: LinearProgressIndicator(value: progress, minHeight: compact ? 7 : 8, backgroundColor: Colors.white.withOpacity(.10), valueColor: const AlwaysStoppedAnimation<Color>(AppColors.cyan)))),
                const SizedBox(width: 10),
                Text('سوال ${_questionIndex + 1} از ${questions.length}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12)),
              ]),
              SizedBox(height: compact ? 9 : 11),
              Row(children: [
                _GameChip(icon: Icons.flash_on_rounded, label: 'کمبو x$_combo', color: AppColors.gold, compact: compact),
                const SizedBox(width: 7),
                if (_shieldActive) _GameChip(icon: Icons.shield_rounded, label: 'سپر فعال', color: AppColors.green, compact: compact),
                if (_doubleActive) ...[const SizedBox(width: 7), _GameChip(icon: Icons.bolt_rounded, label: 'ضریب ۲x', color: AppColors.orange, compact: compact)],
                const Spacer(),
                _GameChip(icon: Icons.category_rounded, label: _question.category, color: AppColors.purple, compact: compact),
              ]),
              SizedBox(height: compact ? 7 : 10),
              TimerRing(secondsLeft: _secondsLeft, totalSeconds: secondsPerQuestion, size: compact ? 92 : 106),
              SizedBox(height: compact ? 9 : 12),
              Expanded(
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Flexible(flex: 6, child: Center(child: PremiumQuestionCard(question: _question, compact: compact))),
                  SizedBox(height: compact ? 10 : 14),
                  Row(children: [
                    Expanded(child: AnswerButton(label: positiveLabel, color: answerColor(true), onTap: () => _submitAnswer(true), disabled: _answered, compact: compact, emphasized: answerEmphasis(true))),
                    const SizedBox(width: 12),
                    Expanded(child: AnswerButton(label: negativeLabel, color: answerColor(false), onTap: () => _submitAnswer(false), disabled: _answered, compact: compact, emphasized: answerEmphasis(false))),
                  ]),
                  SizedBox(height: compact ? 8 : 10),
                  SizedBox(
                    height: compact ? 54 : 58,
                    child: AnimatedSwitcher(
                      duration: const Duration(milliseconds: 220),
                      child: _lastWasCorrect == null ? const SizedBox.shrink() : FeedbackPanel(isCorrect: _lastWasCorrect!, text: _feedbackText ?? '', compact: compact),
                    ),
                  ),
                ]),
              ),
              SizedBox(height: compact ? 6 : 8),
              Row(children: [
                Expanded(child: PowerUpTile(icon: Icons.timer_rounded, title: 'زمان بیشتر', count: _extraTime, active: !_answered && _extraTime > 0, selected: _extraTime > 0, onTap: _useExtraTime, compact: compact)),
                const SizedBox(width: 9),
                Expanded(child: PowerUpTile(icon: Icons.shield_rounded, title: 'سپر خطا', count: _shield, active: !_answered && (_shield > 0 || _shieldActive), selected: _shieldActive, onTap: _useShield, compact: compact)),
                const SizedBox(width: 9),
                Expanded(child: PowerUpTile(icon: Icons.bolt_rounded, title: 'ضریب ۲x', count: _doubleScore, active: !_answered && (_doubleScore > 0 || _doubleActive), selected: _doubleActive, onTap: _useDoubleScore, compact: compact)),
              ]),
            ]),
          ),
        ),
      ),
    );
  }

}

class PlayerScoreCard extends StatelessWidget {
  final PlayerProfile player;
  final int score;
  final bool alignRight;
  final bool compact;
  const PlayerScoreCard({required this.player, required this.score, required this.alignRight, this.compact = false, super.key});

  @override
  Widget build(BuildContext context) {
    return GlassPanel(
      radius: compact ? 18 : 22,
      padding: EdgeInsets.symmetric(horizontal: compact ? 8 : 10, vertical: compact ? 7 : 10),
      borderColor: player.color,
      gradient: LinearGradient(colors: [player.color.withOpacity(.18), const Color(0x99081232)]),
      shadows: [BoxShadow(color: player.color.withOpacity(.10), blurRadius: compact ? 10 : 14, offset: const Offset(0, 7))],
      child: Row(textDirection: alignRight ? TextDirection.rtl : TextDirection.ltr, children: [
        PlayerAvatar(player: player, size: compact ? 38 : 44),
        SizedBox(width: compact ? 6 : 8),
        Expanded(child: Column(crossAxisAlignment: alignRight ? CrossAxisAlignment.start : CrossAxisAlignment.end, mainAxisSize: MainAxisSize.min, children: [
          Text(player.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: compact ? 10.5 : 11.5, fontWeight: FontWeight.w900)),
          SizedBox(height: compact ? 2 : 4),
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 220),
            child: Text('$score', key: ValueKey(score), style: TextStyle(fontSize: compact ? 19 : 22, fontWeight: FontWeight.w900, color: player.color, height: 1.0)),
          ),
        ])),
      ]),
    );
  }
}

class _GameChip extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final bool compact;
  const _GameChip({required this.icon, required this.label, required this.color, this.compact = false});

  @override
  Widget build(BuildContext context) {
    return GlassPanel(
      radius: 18,
      padding: EdgeInsets.symmetric(horizontal: compact ? 7 : 9, vertical: compact ? 5 : 6),
      borderColor: color,
      gradient: LinearGradient(colors: [color.withOpacity(.13), Colors.white.withOpacity(.035)]),
      shadows: [BoxShadow(color: color.withOpacity(.08), blurRadius: 10, offset: const Offset(0, 5))],
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        PremiumGameIcon(icon: icon, color: color, size: compact ? 23 : 26, iconSize: compact ? 13 : 15, solid: true),
        const SizedBox(width: 5),
        Text(label, style: TextStyle(fontSize: compact ? 10.8 : 12, fontWeight: FontWeight.w900)),
      ]),
    );
  }
}

class TimerRing extends StatelessWidget {
  final int secondsLeft;
  final int totalSeconds;
  final double size;
  const TimerRing({required this.secondsLeft, required this.totalSeconds, this.size = 106, super.key});

  @override
  Widget build(BuildContext context) {
    final safeTotal = max(1, totalSeconds);
    final progress = (secondsLeft / safeTotal).clamp(0.0, 1.0).toDouble();
    return RepaintBoundary(
      child: SizedBox(width: size, height: size, child: Stack(alignment: Alignment.center, children: [
        CustomPaint(size: Size(size, size), painter: _TimerRingPainter(progress: progress)),
        Column(mainAxisSize: MainAxisSize.min, children: [
          Text('$secondsLeft'.padLeft(2, '0'), style: TextStyle(fontSize: size * .30, fontWeight: FontWeight.w900, height: 1.0)),
          const SizedBox(height: 4),
          Text('ثانیه', style: TextStyle(fontSize: size * .10, color: Colors.white.withOpacity(.62))),
        ]),
      ])),
    );
  }
}



class _TimerRingPainter extends CustomPainter {
  final double progress;
  const _TimerRingPainter({required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = min(size.width, size.height) / 2;
    final strokeWidth = radius * .16;
    final ringRect = Rect.fromCircle(center: center, radius: radius - strokeWidth / 2);

    final trackPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth
      ..strokeCap = StrokeCap.round
      ..color = Colors.white.withOpacity(.10);

    final glowPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth * 1.15
      ..strokeCap = StrokeCap.round
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 7)
      ..shader = const SweepGradient(
        startAngle: -pi / 2,
        endAngle: pi * 1.5,
        colors: [AppColors.pink, AppColors.purple, AppColors.cyan, AppColors.pink],
      ).createShader(ringRect);

    final progressPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth
      ..strokeCap = StrokeCap.round
      ..shader = const SweepGradient(
        startAngle: -pi / 2,
        endAngle: pi * 1.5,
        colors: [AppColors.pink, AppColors.purple, AppColors.cyan, AppColors.pink],
      ).createShader(ringRect);

    canvas.drawCircle(center, radius - strokeWidth / 2, trackPaint);
    final sweep = (pi * 2 * progress).clamp(0.0, pi * 2).toDouble();
    if (sweep > 0.001) {
      canvas.drawArc(ringRect, -pi / 2, sweep, false, glowPaint);
      canvas.drawArc(ringRect, -pi / 2, sweep, false, progressPaint);
    }

    final innerPaint = Paint()
      ..shader = RadialGradient(
        colors: [Colors.white.withOpacity(.05), Colors.black.withOpacity(.18)],
      ).createShader(Rect.fromCircle(center: center, radius: radius * .68));
    canvas.drawCircle(center, radius * .58, innerPaint);
  }

  @override
  bool shouldRepaint(covariant _TimerRingPainter oldDelegate) => oldDelegate.progress != progress;
}

class PremiumQuestionCard extends StatelessWidget {
  final DuelQuestion question;
  final bool compact;
  const PremiumQuestionCard({required this.question, this.compact = false, super.key});

  @override
  Widget build(BuildContext context) {
    final longText = question.text.length > 42;
    final questionFont = compact ? (longText ? 21.5 : 24.5) : (longText ? 25.0 : 28.0);
    final verticalPadding = compact ? 18.0 : 24.0;
    return Stack(
      clipBehavior: Clip.none,
      alignment: Alignment.center,
      children: [
        GlassPanel(
          radius: 30,
          borderColor: AppColors.cyan,
          padding: EdgeInsets.fromLTRB(16, verticalPadding, 16, verticalPadding + 2),
          gradient: const LinearGradient(
            begin: Alignment.topRight,
            end: Alignment.bottomLeft,
            colors: [Color(0x6620B6FF), Color(0xE6081232), Color(0x4DFF3FA4)],
          ),
          shadows: [
            BoxShadow(color: AppColors.cyan.withOpacity(.18), blurRadius: 22, offset: const Offset(0, 10)),
            BoxShadow(color: Colors.black.withOpacity(.28), blurRadius: 18, offset: const Offset(0, 12)),
          ],
          child: ConstrainedBox(
            constraints: BoxConstraints(minHeight: compact ? 168 : 198),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Container(
                padding: EdgeInsets.symmetric(horizontal: compact ? 12 : 14, vertical: compact ? 5 : 7),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(999),
                  color: Colors.white.withOpacity(.06),
                  border: Border.all(color: Colors.white.withOpacity(.16)),
                ),
                child: Text(question.type, style: TextStyle(color: Colors.white.withOpacity(.78), fontWeight: FontWeight.w900, fontSize: compact ? 11 : 12)),
              ),
              SizedBox(height: compact ? 12 : 16),
              Text(
                question.text,
                textAlign: TextAlign.center,
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(fontSize: questionFont, height: 1.48, fontWeight: FontWeight.w900, shadows: const [Shadow(color: AppColors.cyan, blurRadius: 9)]),
              ),
              SizedBox(height: compact ? 10 : 12),
              Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                PremiumGameIcon(icon: Icons.category_rounded, color: AppColors.purple, size: compact ? 26 : 30, iconSize: compact ? 15 : 17, solid: true),
                const SizedBox(width: 7),
                Text(question.category, style: TextStyle(color: Colors.white.withOpacity(.58), fontSize: compact ? 11 : 12, fontWeight: FontWeight.w800)),
              ]),
            ]),
          ),
        ),
        Positioned(
          bottom: -8,
          child: Transform.rotate(
            angle: pi / 4,
            child: Container(
              width: compact ? 18 : 22,
              height: compact ? 18 : 22,
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [AppColors.pink, AppColors.cyan]),
                borderRadius: BorderRadius.circular(6),
                boxShadow: [BoxShadow(color: AppColors.cyan.withOpacity(.34), blurRadius: 12)],
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class AnswerButton extends StatelessWidget {
  final String label;
  final Color color;
  final VoidCallback onTap;
  final bool disabled;
  final bool compact;
  final bool emphasized;
  const AnswerButton({required this.label, required this.color, required this.onTap, this.disabled = false, this.compact = false, this.emphasized = false, super.key});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(22),
      onTap: disabled ? null : onTap,
      child: AnimatedOpacity(
        duration: const Duration(milliseconds: 160),
        opacity: disabled && !emphasized ? .42 : 1,
        child: Container(
          height: compact ? 56 : 64,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            gradient: LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [Colors.white.withOpacity(.15), color.withOpacity(.94), color.withOpacity(.46)]),
            border: Border.all(color: emphasized ? Colors.white.withOpacity(.62) : disabled ? Colors.white.withOpacity(.18) : Colors.white.withOpacity(.36), width: emphasized ? 1.7 : 1.35),
            boxShadow: disabled && !emphasized ? null : [BoxShadow(color: color.withOpacity(emphasized ? .36 : .23), blurRadius: emphasized ? 18 : 14, offset: const Offset(0, 7)), BoxShadow(color: Colors.black.withOpacity(.24), blurRadius: 10, offset: const Offset(0, 6))],
          ),
          child: Text(label, style: TextStyle(fontSize: compact ? 21 : 24, color: Colors.white, fontWeight: FontWeight.w900, shadows: [Shadow(color: color.withOpacity(.50), blurRadius: 6)])),
        ),
      ),
    );
  }
}

class FeedbackPanel extends StatelessWidget {
  final bool isCorrect;
  final String text;
  final bool compact;
  const FeedbackPanel({required this.isCorrect, required this.text, this.compact = false, super.key});

  @override
  Widget build(BuildContext context) {
    final color = isCorrect ? AppColors.green : AppColors.red;
    return Align(
      alignment: Alignment.center,
      child: GlassPanel(
        key: ValueKey('$isCorrect$text'),
        radius: 18,
        borderColor: color,
        padding: EdgeInsets.symmetric(horizontal: compact ? 10 : 12, vertical: compact ? 7 : 8),
        gradient: LinearGradient(colors: [color.withOpacity(.16), Colors.white.withOpacity(.035)]),
        shadows: [BoxShadow(color: color.withOpacity(.10), blurRadius: 10, offset: const Offset(0, 5))],
        child: Row(mainAxisSize: MainAxisSize.min, mainAxisAlignment: MainAxisAlignment.center, children: [
          PremiumGameIcon(icon: isCorrect ? Icons.check_rounded : Icons.close_rounded, color: color, size: compact ? 30 : 32, iconSize: compact ? 18 : 19, solid: true),
          const SizedBox(width: 8),
          ConstrainedBox(
            constraints: BoxConstraints(maxWidth: MediaQuery.sizeOf(context).width - 122),
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(isCorrect ? 'درست!' : 'غلط!', style: TextStyle(fontWeight: FontWeight.w900, color: color, fontSize: compact ? 15.5 : 17, height: 1.0)),
              const SizedBox(height: 3),
              Text(text, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: compact ? 10.5 : 11.5, color: Colors.white.withOpacity(.65), height: 1.0)),
            ]),
          ),
        ]),
      ),
    );
  }
}

class PowerUpTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final int count;
  final bool active;
  final bool selected;
  final bool compact;
  final VoidCallback onTap;
  const PowerUpTile({required this.icon, required this.title, required this.count, required this.active, required this.onTap, this.selected = false, this.compact = false, super.key});

  @override
  Widget build(BuildContext context) {
    final color = selected ? AppColors.gold : active ? AppColors.cyan : Colors.blueGrey;
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: active ? onTap : null,
      child: AnimatedOpacity(
        duration: const Duration(milliseconds: 160),
        opacity: active || selected ? 1 : .42,
        child: GlassPanel(
          radius: 20,
          padding: EdgeInsets.symmetric(vertical: compact ? 8 : 10, horizontal: 6),
          borderColor: color,
          gradient: LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [color.withOpacity(selected ? .22 : .14), Colors.white.withOpacity(.045), Colors.black.withOpacity(.10)]),
          shadows: [BoxShadow(color: color.withOpacity(active ? .08 : .02), blurRadius: 10, offset: const Offset(0, 6))],
          child: SizedBox(
            height: compact ? 68 : 78,
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              PremiumGameIcon(icon: icon, color: color, size: compact ? 34 : 39, iconSize: compact ? 20 : 23, badge: '$count', solid: active || selected),
              SizedBox(height: compact ? 5 : 7),
              Text(title, textAlign: TextAlign.center, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: compact ? 10.2 : 11, fontWeight: FontWeight.w900)),
              if (selected) Text('فعال', style: TextStyle(fontSize: compact ? 8.5 : 9, color: AppColors.gold.withOpacity(.85), fontWeight: FontWeight.w800)),
            ]),
          ),
        ),
      ),
    );
  }
}

class PremiumTrophy extends StatelessWidget {
  final double size;
  final bool winner;
  const PremiumTrophy({this.size = 86, this.winner = true, super.key});

  @override
  Widget build(BuildContext context) {
    final trophyColor = winner ? AppColors.gold : AppColors.pink;
    return SizedBox(width: size * 1.28, height: size * 1.08, child: Stack(alignment: Alignment.center, children: [
      Positioned.fill(child: DecoratedBox(decoration: BoxDecoration(shape: BoxShape.circle, boxShadow: [BoxShadow(color: trophyColor.withOpacity(.48), blurRadius: size * .46, spreadRadius: size * .04), BoxShadow(color: AppColors.cyan.withOpacity(.18), blurRadius: size * .34, spreadRadius: size * .02)]))),
      CustomPaint(size: Size(size * 1.10, size), painter: _PremiumTrophyPainter(color: trophyColor, winner: winner)),
      Positioned(top: size * .04, right: size * .23, child: _Spark(size: size * .12, color: Colors.white.withOpacity(.95))),
      Positioned(top: size * .21, left: size * .16, child: _Spark(size: size * .09, color: trophyColor.withOpacity(.95))),
    ]));
  }
}

class _Spark extends StatelessWidget {
  final double size;
  final Color color;
  const _Spark({required this.size, required this.color});

  @override
  Widget build(BuildContext context) {
    return Transform.rotate(angle: pi / 4, child: Container(width: size, height: size, decoration: BoxDecoration(gradient: RadialGradient(colors: [color, color.withOpacity(.08)]), borderRadius: BorderRadius.circular(3))));
  }
}

class _PremiumTrophyPainter extends CustomPainter {
  final Color color;
  final bool winner;
  const _PremiumTrophyPainter({required this.color, required this.winner});

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final center = Offset(w / 2, h / 2);
    final shadow = Paint()..color = Colors.black.withOpacity(.35)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10);
    final rimRect = Rect.fromCenter(center: Offset(center.dx, h * .20), width: w * .48, height: h * .12);
    final cupPath = Path()..moveTo(w * .25, h * .22)..cubicTo(w * .28, h * .48, w * .36, h * .61, w * .50, h * .63)..cubicTo(w * .64, h * .61, w * .72, h * .48, w * .75, h * .22)..close();
    final bodyGradient = LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: winner ? const [Color(0xFFFFF3A0), Color(0xFFFFC857), Color(0xFFC87400), Color(0xFFFFDF73)] : const [Color(0xFFFFB0DC), Color(0xFFFF3FA4), Color(0xFF9F185D), Color(0xFFFF8FCC)], stops: const [.02, .38, .72, 1]);
    canvas.drawPath(cupPath.shift(const Offset(0, 6)), shadow);
    canvas.drawPath(cupPath, Paint()..shader = bodyGradient.createShader(Rect.fromLTWH(0, 0, w, h)));
    canvas.drawOval(rimRect, Paint()..shader = bodyGradient.createShader(rimRect));
    canvas.drawOval(rimRect.deflate(1), Paint()..style = PaintingStyle.stroke..strokeWidth = 2.2..color = Colors.white.withOpacity(.55));
    final handlePaint = Paint()..style = PaintingStyle.stroke..strokeWidth = w * .055..strokeCap = StrokeCap.round..shader = bodyGradient.createShader(Rect.fromLTWH(0, h * .18, w, h * .34));
    canvas.drawPath(Path()..moveTo(w * .27, h * .29)..cubicTo(w * .08, h * .28, w * .11, h * .55, w * .33, h * .50), handlePaint);
    canvas.drawPath(Path()..moveTo(w * .73, h * .29)..cubicTo(w * .92, h * .28, w * .89, h * .55, w * .67, h * .50), handlePaint);
    final stemRect = RRect.fromRectAndRadius(Rect.fromCenter(center: Offset(center.dx, h * .72), width: w * .20, height: h * .20), Radius.circular(w * .05));
    canvas.drawRRect(stemRect, Paint()..shader = bodyGradient.createShader(stemRect.outerRect));
    final baseRect = RRect.fromRectAndRadius(Rect.fromCenter(center: Offset(center.dx, h * .86), width: w * .55, height: h * .15), Radius.circular(w * .07));
    canvas.drawRRect(baseRect.shift(const Offset(0, 5)), shadow);
    canvas.drawRRect(baseRect, Paint()..shader = const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF30225E), Color(0xFF0A102B), Color(0xFF6A4BFF)]).createShader(baseRect.outerRect));
    canvas.drawRRect(baseRect, Paint()..style = PaintingStyle.stroke..strokeWidth = 1.4..color = color.withOpacity(.72));
    final plateRect = RRect.fromRectAndRadius(Rect.fromCenter(center: Offset(center.dx, h * .86), width: w * .30, height: h * .062), Radius.circular(w * .03));
    canvas.drawRRect(plateRect, Paint()..color = color.withOpacity(.92));
    final shinePaint = Paint()..style = PaintingStyle.stroke..strokeCap = StrokeCap.round..strokeWidth = 2.3..color = Colors.white.withOpacity(.58);
    canvas.drawLine(Offset(w * .39, h * .27), Offset(w * .34, h * .50), shinePaint);
    canvas.drawLine(Offset(w * .49, h * .21), Offset(w * .61, h * .21), Paint()..style = PaintingStyle.stroke..strokeCap = StrokeCap.round..strokeWidth = 1.6..color = Colors.white.withOpacity(.58));
  }

  @override
  bool shouldRepaint(covariant _PremiumTrophyPainter oldDelegate) => oldDelegate.color != color || oldDelegate.winner != winner;
}

class ResultScreen extends StatelessWidget {
  final GameStats stats;
  const ResultScreen({required this.stats, super.key});

  @override
  Widget build(BuildContext context) {
    final title = stats.isWinner ? 'شما برنده شدید!' : 'باختی، ولی نزدیک بود!';
    final color = stats.isWinner ? AppColors.gold : AppColors.pink;
    return Scaffold(
      body: NeonBackground(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: SingleChildScrollView(child: Column(children: [
              const SizedBox(height: 16),
              PremiumTrophy(size: 92, winner: stats.isWinner),
              const SizedBox(height: 10),
              Text(title, textAlign: TextAlign.center, style: TextStyle(fontSize: 31, fontWeight: FontWeight.w900, color: color)),
              const SizedBox(height: 10),
              Text(stats.mode.title, style: TextStyle(color: Colors.white.withOpacity(.65))),
              const SizedBox(height: 22),
              GlassPanel(radius: 30, padding: const EdgeInsets.all(18), borderColor: color, child: Column(children: [
                Row(children: [
                  Expanded(child: _ResultPlayer(player: stats.player, score: stats.playerScore, color: AppColors.cyan)),
                  Column(children: [const PremiumTrophy(size: 56), Text('VS', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: Colors.white.withOpacity(.9)))]),
                  Expanded(child: _ResultPlayer(player: stats.opponent, score: stats.opponentScore, color: AppColors.pink)),
                ]),
                const SizedBox(height: 18),
                Row(children: [
                  Expanded(child: _RewardTile(icon: Icons.monetization_on_rounded, value: '+${stats.coins}', label: 'سکه', color: AppColors.gold)),
                  const SizedBox(width: 10),
                  Expanded(child: _RewardTile(icon: Icons.hexagon_rounded, value: '+${stats.xp}', label: 'XP', color: AppColors.cyan)),
                  const SizedBox(width: 10),
                  Expanded(child: _RewardTile(icon: stats.trophyChange >= 0 ? Icons.trending_up_rounded : Icons.trending_down_rounded, value: '${stats.trophyChange}', label: 'جام', color: stats.trophyChange >= 0 ? AppColors.green : AppColors.red)),
                ]),
              ])),
              const SizedBox(height: 14),
              _ResultProgressCard(stats: stats),
              const SizedBox(height: 14),
              GlassPanel(padding: const EdgeInsets.all(14), radius: 24, child: Row(children: [
                Expanded(child: _MiniStat(icon: Icons.check_circle_rounded, label: 'درست', value: '${stats.correctAnswers}', color: AppColors.green)),
                Container(width: 1, height: 44, color: Colors.white.withOpacity(.12)),
                Expanded(child: _MiniStat(icon: Icons.flash_on_rounded, label: 'بهترین کمبو', value: '${stats.maxCombo}', color: AppColors.gold)),
                Container(width: 1, height: 44, color: Colors.white.withOpacity(.12)),
                Expanded(child: _MiniStat(icon: Icons.speed_rounded, label: 'سریع‌ترین', value: stats.fastestMs == 0 ? '-' : '${(stats.fastestMs / 1000).toStringAsFixed(1)}ث', color: AppColors.cyan)),
              ])),
              NeonButton(label: 'بازی دوباره', icon: Icons.restart_alt_rounded, onTap: () => Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => MatchmakingScreen(mode: stats.mode)))),
              const SizedBox(height: 12),
              NeonButton(label: 'بازگشت به خانه', icon: Icons.home_rounded, color: Colors.blueGrey, compact: true, onTap: () => Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const ShellScreen()), (_) => false)),
            ])),
          ),
        ),
      ),
    );
  }
}

class _ResultPlayer extends StatelessWidget {
  final PlayerProfile player;
  final int score;
  final Color color;
  const _ResultPlayer({required this.player, required this.score, required this.color});

  @override
  Widget build(BuildContext context) {
    return Column(children: [PlayerAvatar(player: player, size: 68), const SizedBox(height: 10), Text(player.name, textAlign: TextAlign.center, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w900)), const SizedBox(height: 7), Text('$score', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: color))]);
  }
}

class _RewardTile extends StatelessWidget {
  final IconData icon;
  final String value;
  final String label;
  final Color color;
  const _RewardTile({required this.icon, required this.value, required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8), decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), color: Colors.white.withOpacity(.06), border: Border.all(color: color.withOpacity(.35))), child: Column(children: [Icon(icon, color: color, size: 30), const SizedBox(height: 8), Text(value, style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18, color: color)), Text(label, style: TextStyle(fontSize: 11, color: Colors.white.withOpacity(.63)))]));
  }
}

class _ResultProgressCard extends StatelessWidget {
  final GameStats stats;
  const _ResultProgressCard({required this.stats});

  @override
  Widget build(BuildContext context) {
    final playerAfter = RuntimeState.instance.player.value;
    final currentXp = playerAfter.xp % 1000;
    final progress = currentXp / 1000;
    final rankColor = stats.trophyChange >= 0 ? AppColors.green : AppColors.red;
    return GlassPanel(
      radius: 24,
      borderColor: rankColor,
      padding: const EdgeInsets.all(14),
      gradient: LinearGradient(colors: [rankColor.withOpacity(.12), Colors.white.withOpacity(.04)]),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          PremiumGameIcon(icon: Icons.trending_up_rounded, color: rankColor, size: 44, iconSize: 26, solid: true),
          const SizedBox(width: 10),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(stats.trophyChange >= 0 ? 'پیشرفت رتبه ثبت شد' : 'فرصت جبران داری', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15)),
            const SizedBox(height: 4),
            Text('لیگ فعلی: ${playerAfter.rank} • جام: ${playerAfter.trophy}', style: TextStyle(color: Colors.white.withOpacity(.62), fontSize: 11.5)),
          ])),
          Text('${stats.trophyChange >= 0 ? '+' : ''}${stats.trophyChange}', style: TextStyle(color: rankColor, fontWeight: FontWeight.w900, fontSize: 18)),
        ]),
        const SizedBox(height: 13),
        ClipRRect(borderRadius: BorderRadius.circular(999), child: LinearProgressIndicator(value: progress, minHeight: 10, backgroundColor: Colors.white.withOpacity(.10), valueColor: const AlwaysStoppedAnimation<Color>(AppColors.cyan))),
        const SizedBox(height: 8),
        Text('$currentXp / 1000 XP تا مرحله بعد', style: TextStyle(color: Colors.white.withOpacity(.58), fontSize: 11.5, fontWeight: FontWeight.w700)),
      ]),
    );
  }
}


class StoreScreen extends StatelessWidget {
  const StoreScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(key: const ValueKey('store'), physics: const ClampingScrollPhysics(), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const _SectionHeader(title: 'فروشگاه', subtitle: 'پاورآپ و آیتم‌های ویژه'),
      const SizedBox(height: 16),
      ValueListenableBuilder<PlayerProfile>(valueListenable: RuntimeState.instance.player, builder: (_, player, __) => GlassPanel(borderColor: AppColors.gold, child: Row(children: [const Icon(Icons.monetization_on_rounded, color: AppColors.gold, size: 42), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('موجودی سکه', style: TextStyle(fontWeight: FontWeight.w900)), Text('${_formatNumber(player.coins)} سکه برای خرید آیتم داری', style: TextStyle(color: Colors.white.withOpacity(.62), fontSize: 12))])), Text(_formatNumber(player.coins), style: const TextStyle(color: AppColors.gold, fontWeight: FontWeight.w900, fontSize: 20))]))),
      const SizedBox(height: 14),
      ...SampleData.store.map((item) => Padding(padding: const EdgeInsets.only(bottom: 12), child: _StoreItemCard(item: item))),
    ]));
  }
}

class _StoreItemCard extends StatelessWidget {
  final StoreItem item;
  const _StoreItemCard({required this.item});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<Map<String, int>>(
      valueListenable: RuntimeState.instance.inventory,
      builder: (_, inventory, __) {
        final owned = inventory[item.keyName] ?? 0;
        return GlassPanel(radius: 24, borderColor: item.color, gradient: LinearGradient(colors: [item.color.withOpacity(.13), Colors.white.withOpacity(.04)]), child: Row(children: [
          PremiumGameIcon(icon: item.icon, color: item.color, size: 56, iconSize: 32, badge: owned > 0 ? '$owned' : null, solid: true),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(item.title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
            const SizedBox(height: 5),
            Text(item.description, style: TextStyle(color: Colors.white.withOpacity(.62), fontSize: 12, height: 1.45)),
            if (owned > 0) ...[const SizedBox(height: 6), Text('موجودی: $owned عدد', style: TextStyle(color: item.color.withOpacity(.9), fontSize: 11, fontWeight: FontWeight.w900))],
          ])),
          InkWell(
            borderRadius: BorderRadius.circular(15),
            onTap: () async {
              RuntimeState.instance.haptic();
              final ok = await RuntimeState.instance.buyStoreItem(item);
              if (!context.mounted) return;
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(ok ? '${item.title} اضافه شد' : 'سکه کافی نداری'), backgroundColor: ok ? AppColors.green : AppColors.red, behavior: SnackBarBehavior.floating));
            },
            child: Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9), decoration: BoxDecoration(borderRadius: BorderRadius.circular(15), color: item.color.withOpacity(.16), border: Border.all(color: item.color.withOpacity(.4))), child: Row(children: [const Icon(Icons.monetization_on_rounded, color: AppColors.gold, size: 16), const SizedBox(width: 4), Text('${item.price}', style: const TextStyle(fontWeight: FontWeight.w900))])),
          ),
        ]));
      },
    );
  }
}

class MissionsScreen extends StatelessWidget {
  const MissionsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<PlayerProfile>(
      valueListenable: RuntimeState.instance.player,
      builder: (_, player, __) => ValueListenableBuilder<List<GameStats>>(
        valueListenable: RuntimeState.instance.history,
        builder: (_, history, __) {
          final totalCorrect = history.fold<int>(0, (sum, s) => sum + s.correctAnswers);
          final bestCombo = history.fold<int>(0, (best, s) => max(best, s.maxCombo));
          final wins = history.where((s) => s.isWinner).length;
          final fast = history.where((s) => s.fastestMs > 0 && s.fastestMs <= 2000).length;
          final missions = <Mission>[
            Mission(icon: Icons.flash_on_rounded, title: 'شروع قدرتمند', description: '۳ مسابقه انجام بده', progress: min(history.length, 3), target: 3, reward: 120, color: AppColors.cyan),
            Mission(icon: Icons.local_fire_department_rounded, title: 'کمبو آتشین', description: '۵ جواب درست پشت سر هم بزن', progress: min(bestCombo, 5), target: 5, reward: 180, color: AppColors.orange),
            Mission(icon: Icons.emoji_events_rounded, title: 'شکارچی جام', description: '۲ مسابقه را برنده شو', progress: min(wins, 2), target: 2, reward: 250, color: AppColors.gold),
            Mission(icon: Icons.speed_rounded, title: 'جواب برق‌آسا', description: 'زیر ۲ ثانیه جواب درست بده', progress: min(fast, 1), target: 1, reward: 90, color: AppColors.pink),
            Mission(icon: Icons.check_circle_rounded, title: 'دقت بالا', description: '۱۵ جواب درست ثبت کن', progress: min(totalCorrect, 15), target: 15, reward: 210, color: AppColors.green),
          ];
          return SingleChildScrollView(key: const ValueKey('missions'), physics: const ClampingScrollPhysics(), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const _SectionHeader(title: 'ماموریت‌ها', subtitle: 'چالش‌های روزانه واقعی‌تر براساس عملکردت'),
            const SizedBox(height: 16),
            GlassPanel(radius: 24, borderColor: AppColors.purple, child: Row(children: [
              const PremiumGameIcon(icon: Icons.workspace_premium_rounded, color: AppColors.purple, size: 50, iconSize: 28, solid: true),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('${player.streak} برد پیاپی', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
                Text('ماموریت‌ها با هر مسابقه بروزرسانی می‌شوند', style: TextStyle(color: Colors.white.withOpacity(.62), fontSize: 12)),
              ])),
            ])),
            const SizedBox(height: 14),
            ...missions.map((m) => Padding(padding: const EdgeInsets.only(bottom: 12), child: _MissionCard(mission: m))),
          ]));
        },
      ),
    );
  }
}

class _MissionCard extends StatelessWidget {
  final Mission mission;
  const _MissionCard({required this.mission});

  @override
  Widget build(BuildContext context) {
    final progress = mission.progress / mission.target;
    return GlassPanel(radius: 24, borderColor: mission.color, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [Icon(mission.icon, color: mission.color, size: 34), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(mission.title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)), Text(mission.description, style: TextStyle(color: Colors.white.withOpacity(.62), fontSize: 12))])), Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7), decoration: BoxDecoration(borderRadius: BorderRadius.circular(14), color: AppColors.gold.withOpacity(.13)), child: Text('+${mission.reward}', style: const TextStyle(color: AppColors.gold, fontWeight: FontWeight.w900)))]),
      const SizedBox(height: 14),
      ClipRRect(borderRadius: BorderRadius.circular(20), child: LinearProgressIndicator(value: progress, minHeight: 10, backgroundColor: Colors.white.withOpacity(.10), valueColor: AlwaysStoppedAnimation<Color>(mission.color))),
      const SizedBox(height: 8),
      Text('${mission.progress} از ${mission.target}', style: TextStyle(color: Colors.white.withOpacity(.55), fontSize: 12)),
    ]));
  }
}

class FriendsScreen extends StatelessWidget {
  const FriendsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(key: const ValueKey('friends'), physics: const ClampingScrollPhysics(), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const _SectionHeader(title: 'دوستان', subtitle: 'دعوت، رقابت خصوصی و حریف‌های آماده بازی'),
      const SizedBox(height: 16),
      NeonButton(label: 'دعوت با لینک', icon: Icons.link_rounded, compact: true, color: AppColors.pink, onTap: () {}),
      const SizedBox(height: 14),
      ...SampleData.opponents.map((opponent) => Padding(padding: const EdgeInsets.only(bottom: 12), child: _FriendCard(player: opponent))),
    ]));
  }
}

class _FriendCard extends StatelessWidget {
  final PlayerProfile player;
  const _FriendCard({required this.player});

  @override
  Widget build(BuildContext context) {
    return GlassPanel(radius: 24, borderColor: player.color, child: Row(children: [
      PlayerAvatar(player: player, size: 54),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(player.name, style: const TextStyle(fontWeight: FontWeight.w900)), const SizedBox(height: 5), Text('${player.title} • ${player.city} • ${player.wins} برد', style: TextStyle(color: Colors.white.withOpacity(.62), fontSize: 12))])),
      IconButton(onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => GameScreen(mode: DuelMode.private, opponent: player))), icon: const Icon(Icons.sports_esports_rounded, color: AppColors.cyan)),
    ]));
  }
}

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<PlayerProfile>(valueListenable: RuntimeState.instance.player, builder: (_, player, __) {
      final total = player.wins + player.losses;
      final winRate = total == 0 ? 0 : ((player.wins / total) * 100).round();
      return SingleChildScrollView(key: const ValueKey('profile'), physics: const ClampingScrollPhysics(), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const _SectionHeader(title: 'پروفایل', subtitle: 'آمار رقابتی و پیشرفت کاربر'),
        const SizedBox(height: 16),
        GlassPanel(radius: 30, borderColor: player.color, child: Column(children: [
          PlayerAvatar(player: player, size: 86),
          const SizedBox(height: 12),
          Text(player.name, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900)),
          const SizedBox(height: 6),
          Text(player.rank, style: TextStyle(color: Colors.white.withOpacity(.62))),
          const SizedBox(height: 18),
          Row(children: [Expanded(child: _MiniStat(icon: Icons.emoji_events_rounded, label: 'جام', value: '${player.trophy}', color: AppColors.gold)), Expanded(child: _MiniStat(icon: Icons.workspace_premium_rounded, label: 'برد', value: '${player.wins}', color: AppColors.green)), Expanded(child: _MiniStat(icon: Icons.percent_rounded, label: 'برد٪', value: '$winRate٪', color: AppColors.cyan))]),
        ])),
        const SizedBox(height: 14),
        _ProfileProgressPanel(player: player),
        const SizedBox(height: 14),
        NeonButton(label: 'ویرایش پروفایل', icon: Icons.edit_rounded, compact: true, color: AppColors.purple, onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ProfileSetupScreen()))),
        const SizedBox(height: 14),
        const Text('آخرین مسابقات', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
        const SizedBox(height: 10),
        ValueListenableBuilder<List<GameStats>>(valueListenable: RuntimeState.instance.history, builder: (_, history, __) {
          if (history.isEmpty) return GlassPanel(child: Text('هنوز مسابقه‌ای انجام ندادی.', style: TextStyle(color: Colors.white.withOpacity(.65))));
          return Column(children: history.take(5).map((s) => Padding(padding: const EdgeInsets.only(bottom: 10), child: _HistoryRow(stats: s))).toList());
        }),
      ]));
    });
  }
}

class _ProfileProgressPanel extends StatelessWidget {
  final PlayerProfile player;
  const _ProfileProgressPanel({required this.player});

  @override
  Widget build(BuildContext context) {
    final xp = player.xp % 1000;
    final progress = xp / 1000;
    return GlassPanel(
      radius: 24,
      borderColor: AppColors.cyan,
      padding: const EdgeInsets.all(14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const PremiumGameIcon(icon: Icons.auto_graph_rounded, color: AppColors.cyan, size: 46, iconSize: 27, solid: true),
          const SizedBox(width: 10),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('پیشرفت لیگ', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
            Text('${player.rank} • ${player.trophy} جام', style: TextStyle(color: Colors.white.withOpacity(.62), fontSize: 12)),
          ])),
          Text('$xp XP', style: const TextStyle(color: AppColors.cyan, fontWeight: FontWeight.w900)),
        ]),
        const SizedBox(height: 12),
        ClipRRect(borderRadius: BorderRadius.circular(999), child: LinearProgressIndicator(value: progress, minHeight: 10, backgroundColor: Colors.white.withOpacity(.10), valueColor: const AlwaysStoppedAnimation<Color>(AppColors.cyan))),
      ]),
    );
  }
}


class _HistoryRow extends StatelessWidget {
  final GameStats stats;
  const _HistoryRow({required this.stats});

  @override
  Widget build(BuildContext context) {
    final color = stats.isWinner ? AppColors.green : AppColors.red;
    return GlassPanel(radius: 20, padding: const EdgeInsets.all(12), borderColor: color, child: Row(children: [Icon(stats.isWinner ? Icons.check_circle_rounded : Icons.cancel_rounded, color: color), const SizedBox(width: 10), Expanded(child: Text('${stats.mode.title} مقابل ${stats.opponent.name}', style: const TextStyle(fontWeight: FontWeight.w800))), Text('${stats.playerScore} - ${stats.opponentScore}', style: TextStyle(color: color, fontWeight: FontWeight.w900))]));
  }
}

class PrivateRoomScreen extends StatelessWidget {
  const PrivateRoomScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: NeonBackground(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(children: [
              _ScreenHeader(title: 'اتاق خصوصی', onBack: () => Navigator.of(context).pop()),
              const SizedBox(height: 40),
              GlassPanel(radius: 30, padding: const EdgeInsets.all(22), borderColor: AppColors.pink, child: Column(children: [
                const Icon(Icons.groups_rounded, color: AppColors.pink, size: 64),
                const SizedBox(height: 16),
                const Text('ساخت اتاق دوستانه', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
                const SizedBox(height: 12),
                Text('کد اتاق برای شروع سریع آماده است. بعد از تهیه سرور، همین بخش به اتاق واقعی وصل می‌شود.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white.withOpacity(.7))),
                const SizedBox(height: 22),
                Container(padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16), decoration: BoxDecoration(borderRadius: BorderRadius.circular(22), color: Colors.white.withOpacity(.08), border: Border.all(color: AppColors.cyan.withOpacity(.35))), child: const Text('کد اتاق: DJ-4821', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900, letterSpacing: 1))),
                const SizedBox(height: 20),
                NeonButton(label: 'شروع اتاق خصوصی', icon: Icons.play_arrow_rounded, compact: true, onTap: () => Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => MatchmakingScreen(mode: DuelMode.private)))),
              ])),
            ]),
          ),
        ),
      ),
    );
  }
}


class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: NeonBackground(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              _ScreenHeader(title: 'تنظیمات', onBack: () => Navigator.of(context).pop()),
              const SizedBox(height: 20),
              ValueListenableBuilder<bool>(
                valueListenable: RuntimeState.instance.soundEnabled,
                builder: (_, enabled, __) => _SettingSwitch(
                  icon: Icons.volume_up_rounded,
                  title: 'صدای بازی',
                  subtitle: 'آماده اتصال به افکت‌های صوتی نسخه بعد',
                  value: enabled,
                  color: AppColors.cyan,
                  onChanged: RuntimeState.instance.setSound,
                ),
              ),
              const SizedBox(height: 12),
              ValueListenableBuilder<bool>(
                valueListenable: RuntimeState.instance.vibrationEnabled,
                builder: (_, enabled, __) => _SettingSwitch(
                  icon: Icons.vibration_rounded,
                  title: 'ویبره و لرزش',
                  subtitle: 'بازخورد لمسی برای جواب درست، غلط و برد',
                  value: enabled,
                  color: AppColors.pink,
                  onChanged: RuntimeState.instance.setVibration,
                ),
              ),
              const SizedBox(height: 12),
              InkWell(
                borderRadius: BorderRadius.circular(24),
                onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ProfileSetupScreen())),
                child: GlassPanel(
                  radius: 24,
                  borderColor: AppColors.gold,
                  child: Row(children: [
                    const PremiumGameIcon(icon: Icons.edit_rounded, color: AppColors.gold, size: 48, iconSize: 27, solid: true),
                    const SizedBox(width: 12),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const Text('ویرایش پروفایل', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                      Text('نام، شهر، آواتار و رنگ کارتت را تغییر بده', style: TextStyle(color: Colors.white.withOpacity(.62), fontSize: 12)),
                    ])),
                    const Icon(Icons.chevron_left_rounded),
                  ]),
                ),
              ),
              const SizedBox(height: 12),
              GlassPanel(
                radius: 24,
                borderColor: AppColors.purple,
                child: Row(children: [
                  const PremiumGameIcon(icon: Icons.info_rounded, color: AppColors.purple, size: 48, iconSize: 27, solid: true),
                  const SizedBox(width: 12),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('دوئل جواب v1.6.0', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                    Text('پروفایل، لیگ، مأموریت، فروشگاه و منطق حرفه‌ای‌تر حریف', style: TextStyle(color: Colors.white.withOpacity(.62), fontSize: 12, height: 1.5)),
                  ])),
                ]),
              ),
            ]),
          ),
        ),
      ),
    );
  }
}

class _SettingSwitch extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final bool value;
  final Color color;
  final ValueChanged<bool> onChanged;
  const _SettingSwitch({required this.icon, required this.title, required this.subtitle, required this.value, required this.color, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return GlassPanel(
      radius: 24,
      borderColor: color,
      gradient: LinearGradient(colors: [color.withOpacity(.12), Colors.white.withOpacity(.04)]),
      child: Row(children: [
        PremiumGameIcon(icon: icon, color: color, size: 48, iconSize: 27, solid: true),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
          const SizedBox(height: 4),
          Text(subtitle, style: TextStyle(color: Colors.white.withOpacity(.62), fontSize: 12, height: 1.45)),
        ])),
        Switch(value: value, activeColor: color, onChanged: onChanged),
      ]),
    );
  }
}

class LeaderboardScreen extends StatelessWidget {
  const LeaderboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: NeonBackground(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(children: [
              _ScreenHeader(title: 'رتبه‌بندی', onBack: () => Navigator.of(context).pop()),
              const SizedBox(height: 20),
              GlassPanel(radius: 26, padding: const EdgeInsets.all(12), child: Row(children: const [Expanded(child: _LeagueTab(label: 'روزانه', selected: true)), Expanded(child: _LeagueTab(label: 'هفتگی', selected: false)), Expanded(child: _LeagueTab(label: 'ماهانه', selected: false))])),
              const SizedBox(height: 18),
              Expanded(child: GlassPanel(radius: 28, padding: const EdgeInsets.all(14), child: ListView.builder(physics: const ClampingScrollPhysics(), itemCount: SampleData.leaderboard.length, itemBuilder: (context, index) => _RankRow(index: index + 1, data: SampleData.leaderboard[index])))),
            ]),
          ),
        ),
      ),
    );
  }
}

class QuestionBankScreen extends StatelessWidget {
  const QuestionBankScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final cats = SampleData.questions.map((q) => q.category).toSet().toList();
    return Scaffold(
      body: NeonBackground(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(children: [
              _ScreenHeader(title: 'بانک سوالات', onBack: () => Navigator.of(context).pop()),
              const SizedBox(height: 16),
              GlassPanel(radius: 24, borderColor: AppColors.cyan, child: Row(children: [const Icon(Icons.quiz_rounded, color: AppColors.cyan, size: 42), const SizedBox(width: 12), Expanded(child: Text('${SampleData.questions.length} سوال آماده در ${cats.length} دسته‌بندی', style: const TextStyle(fontWeight: FontWeight.w900))), const Icon(Icons.cloud_upload_rounded, color: AppColors.pink)])),
              const SizedBox(height: 14),
              Expanded(child: GlassPanel(radius: 26, padding: const EdgeInsets.all(12), child: ListView.builder(physics: const ClampingScrollPhysics(), itemCount: SampleData.questions.length, itemBuilder: (_, i) {
                final q = SampleData.questions[i];
                return Container(margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.all(12), decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), color: Colors.white.withOpacity(.06), border: Border.all(color: Colors.white.withOpacity(.09))), child: Row(children: [Container(width: 32, height: 32, alignment: Alignment.center, decoration: BoxDecoration(shape: BoxShape.circle, color: (q.answer ? AppColors.green : AppColors.red).withOpacity(.18)), child: Text(q.answer ? 'ب' : 'ن', style: TextStyle(color: q.answer ? AppColors.green : AppColors.red, fontWeight: FontWeight.w900))), const SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(q.text, style: const TextStyle(fontWeight: FontWeight.w800)), const SizedBox(height: 4), Text('${q.category} • سختی ${q.difficulty}', style: TextStyle(color: Colors.white.withOpacity(.55), fontSize: 11))]))]));
              }))),
            ]),
          ),
        ),
      ),
    );
  }
}

class _LeagueTab extends StatelessWidget {
  final String label;
  final bool selected;
  const _LeagueTab({required this.label, required this.selected});

  @override
  Widget build(BuildContext context) {
    return Container(margin: const EdgeInsets.symmetric(horizontal: 4), padding: const EdgeInsets.symmetric(vertical: 12), alignment: Alignment.center, decoration: BoxDecoration(borderRadius: BorderRadius.circular(17), gradient: selected ? const LinearGradient(colors: [AppColors.blue, AppColors.cyan]) : null, color: selected ? null : Colors.white.withOpacity(.05)), child: Text(label, style: const TextStyle(fontWeight: FontWeight.w900)));
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  final String subtitle;
  const _SectionHeader({required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w900)), const SizedBox(height: 5), Text(subtitle, style: TextStyle(color: Colors.white.withOpacity(.62), fontSize: 12))])),
      const PremiumTrophy(size: 48),
    ]);
  }
}

class _ScreenHeader extends StatelessWidget {
  final String title;
  final VoidCallback onBack;
  const _ScreenHeader({required this.title, required this.onBack});

  @override
  Widget build(BuildContext context) {
    return Row(children: [_RoundIconButton(icon: Icons.arrow_back_rounded, onTap: onBack), Expanded(child: Center(child: Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)))), const SizedBox(width: 48)]);
  }
}

String _formatNumber(int value) {
  final s = value.toString();
  final buffer = StringBuffer();
  for (int i = 0; i < s.length; i++) {
    final reverseIndex = s.length - i;
    buffer.write(s[i]);
    if (reverseIndex > 1 && reverseIndex % 3 == 1) buffer.write(',');
  }
  return buffer.toString();
}
