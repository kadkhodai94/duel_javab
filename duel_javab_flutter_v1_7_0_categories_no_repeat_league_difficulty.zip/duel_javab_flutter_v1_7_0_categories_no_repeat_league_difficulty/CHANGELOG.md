# Duel Javab v1.7.0+9

## نسخه v1.7.0 - Categories, No Repeat, League Difficulty

### Added
- Category selection screen before starting a match.
- Per-user seen question storage using SharedPreferences.
- No-repeat question selection per user.
- Remaining question counter for each category.
- Category progress percentage.
- League-based difficulty plan.
- Opponent selection aligned with player league.
- More local categorized questions.
- Difficulty pill inside question card.

### Changed
- Start buttons now open category selection first.
- Matchmaking receives selected category.
- Game question builder filters by category and excludes seen questions.
- Daily/practice/ranked modes use their own required match size.
- Settings text updated to v1.7.0.

### Version
- `version: 1.7.0+9`
