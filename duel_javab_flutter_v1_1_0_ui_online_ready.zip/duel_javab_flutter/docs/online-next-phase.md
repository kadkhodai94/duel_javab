# مرحله بعد آنلاین واقعی

برای تبدیل نسخه فعلی به آنلاین واقعی، مسیر پیشنهادی این است:

1. ورود کاربر با Firebase Auth یا ورود مهمان.
2. ساخت Collection/Node برای `matchmaking_queue`.
3. ساخت `rooms/{roomId}` برای اتاق مسابقه.
4. ذخیره سوالات داخل `questions` و ارسال فقط شناسه سوال به کلاینت.
5. ثبت جواب با server timestamp.
6. محاسبه امتیاز در Cloud Functions یا سرور Node.js.
7. ارسال نتیجه نهایی به کلاینت‌ها.

## ساختار دیتابیس پیشنهادی

```text
rooms/{roomId}
  status: waiting | countdown | playing | finished
  player1: uid
  player2: uid
  currentQuestionIndex: number
  startedAt: serverTimestamp
  scores:
    player1: number
    player2: number
  answers:
    {questionId}:
      {uid}:
        answer: true | false
        answeredAt: serverTimestamp
        elapsedMs: number
```

## ضدتقلب

- امتیاز نهایی نباید داخل موبایل محاسبه شود.
- زمان شروع سوال باید server timestamp باشد.
- جواب‌های بعد از پایان تایمر نباید پذیرفته شوند.
- اگر کاربر از اتاق خارج شد، وضعیت مسابقه باید `cancelled` یا `opponent_left` شود.
