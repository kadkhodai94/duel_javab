import 'dart:async';
import 'dart:math';
import 'dart:ui';

import 'package:flutter/material.dart';

void main() {
  runApp(const DuelJavabApp());
}

class DuelJavabApp extends StatelessWidget {
  const DuelJavabApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'دوئل جواب',
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF00A3FF),
          brightness: Brightness.dark,
        ),
        scaffoldBackgroundColor: const Color(0xFF05091D),
        textTheme: const TextTheme(
          titleLarge: TextStyle(fontWeight: FontWeight.w900),
          titleMedium: TextStyle(fontWeight: FontWeight.w800),
          bodyMedium: TextStyle(height: 1.7),
        ),
      ),
      builder: (context, child) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: child ?? const SizedBox.shrink(),
        );
      },
      home: const HomeScreen(),
    );
  }
}

class PlayerProfile {
  final String name;
  final String rank;
  final int trophy;
  final int coins;
  final Color color;
  final IconData avatarIcon;

  const PlayerProfile({
    required this.name,
    required this.rank,
    required this.trophy,
    required this.coins,
    required this.color,
    required this.avatarIcon,
  });
}

class DuelQuestion {
  final String text;
  final bool answer;
  final String type;
  final String category;

  const DuelQuestion({
    required this.text,
    required this.answer,
    required this.type,
    required this.category,
  });
}

class MatchSummary {
  final PlayerProfile player;
  final PlayerProfile opponent;
  final int playerScore;
  final int opponentScore;
  final int correctAnswers;
  final int maxCombo;
  final int coins;
  final int xp;

  const MatchSummary({
    required this.player,
    required this.opponent,
    required this.playerScore,
    required this.opponentScore,
    required this.correctAnswers,
    required this.maxCombo,
    required this.coins,
    required this.xp,
  });

  bool get isWinner => playerScore >= opponentScore;
}

class SampleData {
  static const player = PlayerProfile(
    name: 'علی رستمی',
    rank: 'الماس ۲',
    trophy: 2450,
    coins: 12450,
    color: Color(0xFF20B6FF),
    avatarIcon: Icons.person_rounded,
  );

  static const opponent = PlayerProfile(
    name: 'امیر محمدی',
    rank: 'الماس ۱',
    trophy: 2140,
    coins: 8350,
    color: Color(0xFFFF3FA4),
    avatarIcon: Icons.person_4_rounded,
  );

  static const questions = <DuelQuestion>[
    DuelQuestion(text: 'آیا خورشید یک ستاره است؟', answer: true, type: 'بله / نه', category: 'علمی'),
    DuelQuestion(text: 'تهران پایتخت ایران است.', answer: true, type: 'درست / غلط', category: 'عمومی'),
    DuelQuestion(text: 'عدد ۹ یک عدد زوج است.', answer: false, type: 'درست / غلط', category: 'ریاضی'),
    DuelQuestion(text: 'آب در دمای معمولی مایع است.', answer: true, type: 'درست / غلط', category: 'علمی'),
    DuelQuestion(text: 'قاره آفریقا کوچک‌ترین قاره جهان است.', answer: false, type: 'درست / غلط', category: 'جغرافیا'),
    DuelQuestion(text: 'آیا ماه از خودش نور تولید می‌کند؟', answer: false, type: 'بله / نه', category: 'علمی'),
    DuelQuestion(text: 'زبان فارسی از راست به چپ نوشته می‌شود.', answer: true, type: 'درست / غلط', category: 'عمومی'),
    DuelQuestion(text: 'در فوتبال هر تیم ۱۱ بازیکن اصلی دارد.', answer: true, type: 'درست / غلط', category: 'ورزشی'),
    DuelQuestion(text: 'آیا نهنگ یک ماهی است؟', answer: false, type: 'بله / نه', category: 'حیوانات'),
    DuelQuestion(text: 'کوه اورست بلندترین قله جهان است.', answer: true, type: 'درست / غلط', category: 'جغرافیا'),
  ];

  static const leaderboard = <Map<String, Object>>[
    {'name': 'پارسا نیکو', 'score': 28450, 'rank': 'الماس'},
    {'name': 'مهدی اسدی', 'score': 24780, 'rank': 'الماس'},
    {'name': 'نیما شریفی', 'score': 21300, 'rank': 'یاقوت'},
    {'name': 'سینا کریمی', 'score': 20120, 'rank': 'طلا'},
    {'name': 'آرمان امیری', 'score': 18970, 'rank': 'طلا'},
  ];
}

class AppColors {
  static const bgTop = Color(0xFF05091D);
  static const bgBottom = Color(0xFF13062D);
  static const cyan = Color(0xFF20B6FF);
  static const blue = Color(0xFF006DFF);
  static const pink = Color(0xFFFF3FA4);
  static const purple = Color(0xFF8B5CFF);
  static const gold = Color(0xFFFFC857);
  static const green = Color(0xFF15D17C);
  static const red = Color(0xFFFF435D);
  static const panel = Color(0xCC0B1230);
  static const panel2 = Color(0x99081228);
}

class NeonBackground extends StatelessWidget {
  final Widget child;
  const NeonBackground({required this.child, super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [AppColors.bgTop, Color(0xFF08143A), AppColors.bgBottom],
        ),
      ),
      child: Stack(
        children: [
          const Positioned(
            top: -90,
            right: -60,
            child: _GlowOrb(size: 220, color: AppColors.blue),
          ),
          const Positioned(
            top: 210,
            left: -80,
            child: _GlowOrb(size: 220, color: AppColors.pink),
          ),
          const Positioned(
            bottom: -130,
            right: 40,
            child: _GlowOrb(size: 260, color: AppColors.purple),
          ),
          Positioned.fill(child: CustomPaint(painter: _GridPainter())),
          child,
        ],
      ),
    );
  }
}

class _GlowOrb extends StatelessWidget {
  final double size;
  final Color color;
  const _GlowOrb({required this.size, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(
            color: color.withOpacity(.45),
            blurRadius: size * .55,
            spreadRadius: size * .2,
          ),
        ],
      ),
    );
  }
}

class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withOpacity(.035)
      ..strokeWidth = 1;
    for (double y = 90; y < size.height; y += 74) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
    for (double x = 34; x < size.width; x += 74) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class GlassPanel extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final double radius;
  final Gradient? gradient;
  final Color borderColor;
  final List<BoxShadow>? shadows;

  const GlassPanel({
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.radius = 24,
    this.gradient,
    this.borderColor = Colors.white24,
    this.shadows,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            gradient: gradient ??
                LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Colors.white.withOpacity(.10),
                    AppColors.panel2,
                    Colors.white.withOpacity(.045),
                  ],
                ),
            borderRadius: BorderRadius.circular(radius),
            border: Border.all(color: borderColor.withOpacity(.55), width: 1.1),
            boxShadow: shadows ??
                [
                  BoxShadow(
                    color: Colors.black.withOpacity(.35),
                    blurRadius: 24,
                    offset: const Offset(0, 16),
                  ),
                ],
          ),
          child: child,
        ),
      ),
    );
  }
}

class NeonButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback onTap;
  final Color color;
  final bool compact;

  const NeonButton({
    required this.label,
    required this.icon,
    required this.onTap,
    this.color = AppColors.cyan,
    this.compact = false,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(22),
      onTap: onTap,
      child: Container(
        height: compact ? 54 : 70,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          gradient: LinearGradient(
            colors: [color.withOpacity(.95), color.withOpacity(.22)],
            begin: Alignment.centerRight,
            end: Alignment.centerLeft,
          ),
          border: Border.all(color: color.withOpacity(.9), width: 1.6),
          boxShadow: [
            BoxShadow(color: color.withOpacity(.42), blurRadius: 26),
            BoxShadow(color: Colors.black.withOpacity(.34), blurRadius: 18, offset: const Offset(0, 10)),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.white, size: compact ? 22 : 30),
            const SizedBox(width: 12),
            Text(
              label,
              style: TextStyle(
                fontSize: compact ? 17 : 22,
                color: Colors.white,
                fontWeight: FontWeight.w900,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class PlayerAvatar extends StatelessWidget {
  final PlayerProfile player;
  final double size;
  const PlayerAvatar({required this.player, this.size = 58, super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(colors: [player.color, AppColors.purple]),
        boxShadow: [BoxShadow(color: player.color.withOpacity(.52), blurRadius: 20)],
      ),
      padding: const EdgeInsets.all(3),
      child: Container(
        decoration: const BoxDecoration(
          shape: BoxShape.circle,
          color: Color(0xFF101A3C),
        ),
        child: Icon(player.avatarIcon, size: size * .55, color: Colors.white),
      ),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: NeonBackground(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 12, 18, 12),
            child: Column(
              children: [
                _HomeHeader(),
                const SizedBox(height: 22),
                Expanded(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    child: Column(
                      children: [
                        const SizedBox(height: 4),
                        const _GameLogo(),
                        const SizedBox(height: 26),
                        NeonButton(
                          label: 'شروع رقابت',
                          icon: Icons.flash_on_rounded,
                          onTap: () => Navigator.of(context).push(
                            MaterialPageRoute(builder: (_) => const MatchmakingScreen()),
                          ),
                        ),
                        const SizedBox(height: 14),
                        NeonButton(
                          label: 'اتاق خصوصی',
                          icon: Icons.groups_rounded,
                          color: AppColors.pink,
                          compact: true,
                          onTap: () => Navigator.of(context).push(
                            MaterialPageRoute(builder: (_) => const PrivateRoomScreen()),
                          ),
                        ),
                        const SizedBox(height: 18),
                        _StatsStrip(),
                        const SizedBox(height: 18),
                        _LeaderboardPreview(
                          onOpen: () => Navigator.of(context).push(
                            MaterialPageRoute(builder: (_) => const LeaderboardScreen()),
                          ),
                        ),
                        const SizedBox(height: 18),
                      ],
                    ),
                  ),
                ),
                const _BottomNav(),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _HomeHeader extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final player = SampleData.player;
    return Row(
      children: [
        PlayerAvatar(player: player, size: 58),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(player.name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
              const SizedBox(height: 5),
              Row(
                children: [
                  const Icon(Icons.diamond_rounded, color: AppColors.purple, size: 17),
                  const SizedBox(width: 5),
                  Text(player.rank, style: TextStyle(color: Colors.white.withOpacity(.72), fontSize: 12)),
                ],
              ),
            ],
          ),
        ),
        _CoinPill(amount: player.coins),
        const SizedBox(width: 8),
        _RoundIconButton(icon: Icons.menu_rounded, onTap: () {}),
      ],
    );
  }
}

class _CoinPill extends StatelessWidget {
  final int amount;
  const _CoinPill({required this.amount});

  @override
  Widget build(BuildContext context) {
    return GlassPanel(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      radius: 16,
      borderColor: AppColors.gold,
      child: Row(
        children: [
          const Icon(Icons.monetization_on_rounded, color: AppColors.gold, size: 19),
          const SizedBox(width: 5),
          Text(_formatNumber(amount), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 13)),
          const SizedBox(width: 4),
          const Icon(Icons.add_box_rounded, color: AppColors.gold, size: 16),
        ],
      ),
    );
  }
}

class _RoundIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _RoundIconButton({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: GlassPanel(
        padding: const EdgeInsets.all(9),
        radius: 16,
        child: Icon(icon, size: 22),
      ),
    );
  }
}

class _GameLogo extends StatelessWidget {
  const _GameLogo();

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Stack(
          alignment: Alignment.center,
          children: [
            Text(
              'دوئل',
              style: TextStyle(
                fontSize: 66,
                fontWeight: FontWeight.w900,
                letterSpacing: -3,
                foreground: Paint()
                  ..style = PaintingStyle.stroke
                  ..strokeWidth = 7
                  ..color = AppColors.cyan.withOpacity(.55),
              ),
            ),
            ShaderMask(
              shaderCallback: (rect) => const LinearGradient(
                colors: [Colors.white, AppColors.cyan, AppColors.pink],
              ).createShader(rect),
              child: const Text(
                'دوئل',
                style: TextStyle(fontSize: 66, fontWeight: FontWeight.w900, letterSpacing: -3),
              ),
            ),
          ],
        ),
        Transform.translate(
          offset: const Offset(0, -14),
          child: Stack(
            alignment: Alignment.center,
            children: [
              Text(
                'جواب',
                style: TextStyle(
                  fontSize: 56,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -3,
                  foreground: Paint()
                    ..style = PaintingStyle.stroke
                    ..strokeWidth = 6
                    ..color = AppColors.pink.withOpacity(.52),
                ),
              ),
              ShaderMask(
                shaderCallback: (rect) => const LinearGradient(
                  colors: [Colors.white, AppColors.pink, AppColors.purple],
                ).createShader(rect),
                child: const Text('جواب', style: TextStyle(fontSize: 56, fontWeight: FontWeight.w900, letterSpacing: -3)),
              ),
            ],
          ),
        ),
        Text('فقط یک پاسخ درست وجود دارد!', style: TextStyle(color: Colors.white.withOpacity(.7), fontSize: 15)),
      ],
    );
  }
}

class _StatsStrip extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GlassPanel(
      padding: const EdgeInsets.all(14),
      child: Row(
        children: [
          Expanded(child: _MiniStat(icon: Icons.speed_rounded, label: 'رکورد سرعت', value: '۱.۲ ثانیه', color: AppColors.cyan)),
          Container(width: 1, height: 44, color: Colors.white.withOpacity(.12)),
          Expanded(child: _MiniStat(icon: Icons.local_fire_department_rounded, label: 'برد امروز', value: '۸', color: AppColors.pink)),
          Container(width: 1, height: 44, color: Colors.white.withOpacity(.12)),
          Expanded(child: _MiniStat(icon: Icons.emoji_events_rounded, label: 'جام', value: '۲۴۵۰', color: AppColors.gold)),
        ],
      ),
    );
  }
}

class _MiniStat extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color color;
  const _MiniStat({required this.icon, required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Icon(icon, color: color, size: 26),
        const SizedBox(height: 8),
        Text(value, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15)),
        Text(label, style: TextStyle(fontSize: 11, color: Colors.white.withOpacity(.56))),
      ],
    );
  }
}

class _LeaderboardPreview extends StatelessWidget {
  final VoidCallback onOpen;
  const _LeaderboardPreview({required this.onOpen});

  @override
  Widget build(BuildContext context) {
    return GlassPanel(
      padding: const EdgeInsets.all(14),
      child: Column(
        children: [
          Row(
            children: [
              const Expanded(child: Text('رتبه‌بندی', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900))),
              TextButton(onPressed: onOpen, child: const Text('مشاهده همه')),
            ],
          ),
          const SizedBox(height: 8),
          ...SampleData.leaderboard.take(3).toList().asMap().entries.map((entry) {
            return _RankRow(index: entry.key + 1, data: entry.value);
          }),
        ],
      ),
    );
  }
}

class _RankRow extends StatelessWidget {
  final int index;
  final Map<String, Object> data;
  const _RankRow({required this.index, required this.data});

  @override
  Widget build(BuildContext context) {
    final color = index == 1 ? AppColors.gold : index == 2 ? Colors.blueGrey.shade100 : Colors.orangeAccent;
    return Container(
      margin: const EdgeInsets.only(bottom: 9),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        color: Colors.white.withOpacity(index == 1 ? .12 : .06),
        border: Border.all(color: color.withOpacity(.35)),
      ),
      child: Row(
        children: [
          Container(
            width: 30,
            height: 30,
            alignment: Alignment.center,
            decoration: BoxDecoration(shape: BoxShape.circle, color: color.withOpacity(.18), border: Border.all(color: color.withOpacity(.7))),
            child: Text('$index', style: TextStyle(color: color, fontWeight: FontWeight.w900)),
          ),
          const SizedBox(width: 10),
          Expanded(child: Text(data['name'].toString(), style: const TextStyle(fontWeight: FontWeight.w800))),
          const Icon(Icons.diamond_rounded, color: AppColors.purple, size: 18),
          const SizedBox(width: 6),
          Text(_formatNumber(data['score'] as int), style: const TextStyle(color: AppColors.gold, fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }
}


class _NavItemData {
  final IconData icon;
  final String label;
  final Color color;

  const _NavItemData(this.icon, this.label, this.color);
}

class _BottomNav extends StatelessWidget {
  const _BottomNav();

  @override
  Widget build(BuildContext context) {
    const items = [
      _NavItemData(Icons.storefront_rounded, 'فروشگاه', AppColors.gold),
      _NavItemData(Icons.flag_rounded, 'ماموریت', AppColors.purple),
      _NavItemData(Icons.bolt_rounded, 'خانه', AppColors.cyan),
      _NavItemData(Icons.group_rounded, 'دوستان', AppColors.pink),
      _NavItemData(Icons.person_rounded, 'پروفایل', AppColors.green),
    ];

    return GlassPanel(
      radius: 30,
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 6),
      borderColor: AppColors.cyan.withOpacity(.55),
      gradient: LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          Colors.white.withOpacity(.13),
          const Color(0xCC070D26),
          Colors.white.withOpacity(.045),
        ],
      ),
      shadows: [
        BoxShadow(color: AppColors.cyan.withOpacity(.16), blurRadius: 34, offset: const Offset(0, -4)),
        BoxShadow(color: Colors.black.withOpacity(.44), blurRadius: 28, offset: const Offset(0, 18)),
      ],
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: items.map((item) {
          final selected = item.label == 'خانه';
          return Expanded(
            child: _DuelNavIcon(
              item: item,
              selected: selected,
              onTap: () {},
            ),
          );
        }).toList(),
      ),
    );
  }
}

class _DuelNavIcon extends StatelessWidget {
  final _NavItemData item;
  final bool selected;
  final VoidCallback onTap;

  const _DuelNavIcon({required this.item, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(22),
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 260),
        curve: Curves.easeOutCubic,
        margin: const EdgeInsets.symmetric(horizontal: 2),
        padding: EdgeInsets.symmetric(vertical: selected ? 8 : 7, horizontal: 4),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          gradient: selected
              ? LinearGradient(
                  begin: Alignment.topRight,
                  end: Alignment.bottomLeft,
                  colors: [
                    item.color.withOpacity(.92),
                    AppColors.blue.withOpacity(.50),
                    Colors.white.withOpacity(.06),
                  ],
                )
              : LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Colors.white.withOpacity(.06), Colors.white.withOpacity(.015)],
                ),
          border: Border.all(color: selected ? item.color.withOpacity(.92) : Colors.white.withOpacity(.08), width: selected ? 1.3 : .8),
          boxShadow: selected
              ? [
                  BoxShadow(color: item.color.withOpacity(.38), blurRadius: 20, offset: const Offset(0, 8)),
                  BoxShadow(color: Colors.black.withOpacity(.25), blurRadius: 16, offset: const Offset(0, 10)),
                ]
              : null,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Stack(
              alignment: Alignment.center,
              children: [
                if (selected)
                  Container(
                    width: 35,
                    height: 25,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      boxShadow: [BoxShadow(color: item.color.withOpacity(.55), blurRadius: 18, spreadRadius: 1)],
                    ),
                  ),
                Container(
                  width: 34,
                  height: 34,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      colors: selected
                          ? [Colors.white.withOpacity(.24), Colors.white.withOpacity(.06)]
                          : [Colors.white.withOpacity(.10), Colors.white.withOpacity(.02)],
                    ),
                    border: Border.all(color: selected ? Colors.white.withOpacity(.42) : Colors.white.withOpacity(.10)),
                  ),
                  child: Icon(item.icon, size: 21, color: selected ? Colors.white : Colors.white.withOpacity(.56)),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              item.label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: selected ? 10.5 : 9.8,
                color: selected ? Colors.white : Colors.white.withOpacity(.50),
                fontWeight: selected ? FontWeight.w900 : FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class MatchmakingScreen extends StatefulWidget {
  const MatchmakingScreen({super.key});

  @override
  State<MatchmakingScreen> createState() => _MatchmakingScreenState();
}

class _MatchmakingScreenState extends State<MatchmakingScreen> {
  Timer? _timer;
  int _phase = 0;
  int _countdown = 3;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      setState(() {
        if (_phase < 3) {
          _phase++;
        } else if (_countdown > 1) {
          _countdown--;
        } else {
          _timer?.cancel();
          Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const GameScreen()));
        }
      });
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final found = _phase >= 2;
    return Scaffold(
      body: NeonBackground(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              children: [
                Row(
                  children: [
                    _RoundIconButton(icon: Icons.arrow_back_rounded, onTap: () => Navigator.of(context).pop()),
                    const Expanded(
                      child: Center(child: Text('جستجوی حریف', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900))),
                    ),
                    const SizedBox(width: 48),
                  ],
                ),
                const Spacer(),
                Text(
                  found ? 'حریف پیدا شد!' : 'در حال پیدا کردن حریف...',
                  style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 30),
                _VersusMatchCard(found: found),
                const SizedBox(height: 34),
                Text(
                  found ? 'بازی شروع می‌شود' : 'در حال بررسی بازیکنان آنلاین',
                  style: TextStyle(color: Colors.white.withOpacity(.72)),
                ),
                const SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    _CountdownBox(label: found ? '$_countdown' : '3', active: found && _countdown == 3, color: AppColors.cyan),
                    const SizedBox(width: 12),
                    _CountdownBox(label: '2', active: found && _countdown == 2, color: AppColors.purple),
                    const SizedBox(width: 12),
                    _CountdownBox(label: '1', active: found && _countdown == 1, color: AppColors.pink),
                  ],
                ),
                const Spacer(),
                GlassPanel(
                  padding: const EdgeInsets.all(13),
                  child: Row(
                    children: [
                      const Icon(Icons.shield_rounded, color: AppColors.cyan),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          'اتاق آنلاین امن: جواب‌ها با زمان ثبت می‌شوند تا امتیاز قابل تقلب نباشد.',
                          style: TextStyle(color: Colors.white.withOpacity(.72), fontSize: 12),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _VersusMatchCard extends StatelessWidget {
  final bool found;
  const _VersusMatchCard({required this.found});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 310,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Container(
            width: 270,
            height: 270,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: AppColors.cyan.withOpacity(.25), width: 2),
              boxShadow: [BoxShadow(color: AppColors.cyan.withOpacity(.18), blurRadius: 55)],
            ),
          ),
          Positioned(
            top: 8,
            child: _MatchPlayerCard(player: SampleData.player, color: AppColors.cyan, isUnknown: false),
          ),
          Positioned(
            bottom: 8,
            child: _MatchPlayerCard(player: SampleData.opponent, color: AppColors.pink, isUnknown: !found),
          ),
          ShaderMask(
            shaderCallback: (rect) => const LinearGradient(colors: [AppColors.cyan, Colors.white, AppColors.pink]).createShader(rect),
            child: const Text('VS', style: TextStyle(fontSize: 68, fontWeight: FontWeight.w900)),
          ),
        ],
      ),
    );
  }
}

class _MatchPlayerCard extends StatelessWidget {
  final PlayerProfile player;
  final Color color;
  final bool isUnknown;
  const _MatchPlayerCard({required this.player, required this.color, required this.isUnknown});

  @override
  Widget build(BuildContext context) {
    return GlassPanel(
      radius: 24,
      borderColor: color,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      gradient: LinearGradient(colors: [color.withOpacity(.16), Colors.white.withOpacity(.05)]),
      child: SizedBox(
        width: 246,
        child: Row(
          children: [
            isUnknown
                ? Container(
                    width: 56,
                    height: 56,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withOpacity(.08), border: Border.all(color: color.withOpacity(.5))),
                    child: const Text('؟', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
                  )
                : PlayerAvatar(player: player, size: 56),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(isUnknown ? 'حریف در حال جستجو' : player.name, style: const TextStyle(fontWeight: FontWeight.w900)),
                  const SizedBox(height: 6),
                  Text(isUnknown ? 'در حال بررسی...' : '${player.rank}  •  ${player.trophy}', style: TextStyle(fontSize: 12, color: Colors.white.withOpacity(.65))),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _CountdownBox extends StatelessWidget {
  final String label;
  final bool active;
  final Color color;
  const _CountdownBox({required this.label, required this.active, required this.color});

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 220),
      width: active ? 68 : 58,
      height: active ? 68 : 58,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        gradient: LinearGradient(colors: [color.withOpacity(active ? .9 : .28), color.withOpacity(.08)]),
        border: Border.all(color: color.withOpacity(active ? .95 : .35), width: 1.4),
        boxShadow: active ? [BoxShadow(color: color.withOpacity(.45), blurRadius: 26)] : null,
      ),
      child: Text(label, style: TextStyle(fontSize: active ? 32 : 25, fontWeight: FontWeight.w900)),
    );
  }
}

class GameScreen extends StatefulWidget {
  const GameScreen({super.key});

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> {
  static const int secondsPerQuestion = 7;
  final _random = Random();
  Timer? _questionTimer;
  Timer? _opponentTimer;

  int _questionIndex = 0;
  int _secondsLeft = secondsPerQuestion;
  int _playerScore = 0;
  int _opponentScore = 0;
  int _combo = 0;
  int _maxCombo = 0;
  int _correct = 0;
  bool _answered = false;
  bool? _lastWasCorrect;
  bool _opponentAnswered = false;

  DuelQuestion get _question => SampleData.questions[_questionIndex];

  @override
  void initState() {
    super.initState();
    _startQuestion();
  }

  @override
  void dispose() {
    _questionTimer?.cancel();
    _opponentTimer?.cancel();
    super.dispose();
  }

  void _startQuestion() {
    _questionTimer?.cancel();
    _opponentTimer?.cancel();
    setState(() {
      _secondsLeft = secondsPerQuestion;
      _answered = false;
      _lastWasCorrect = null;
      _opponentAnswered = false;
    });

    final opponentDelay = Duration(milliseconds: 1400 + _random.nextInt(4300));
    _opponentTimer = Timer(opponentDelay, _simulateOpponentAnswer);

    _questionTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) return;
      if (_secondsLeft <= 1) {
        timer.cancel();
        if (!_answered) {
          setState(() {
            _combo = 0;
            _lastWasCorrect = false;
          });
        }
        Future.delayed(const Duration(milliseconds: 650), _goNextQuestion);
      } else {
        setState(() => _secondsLeft--);
      }
    });
  }

  void _simulateOpponentAnswer() {
    if (!mounted || _opponentAnswered) return;
    final isCorrect = _random.nextDouble() > .25;
    final speedBonus = max(0, _secondsLeft * 5);
    setState(() {
      _opponentAnswered = true;
      if (isCorrect) _opponentScore += 70 + speedBonus;
    });
  }

  void _submitAnswer(bool value) {
    if (_answered) return;
    final isCorrect = value == _question.answer;
    final speedBonus = max(0, _secondsLeft * 6);
    setState(() {
      _answered = true;
      _lastWasCorrect = isCorrect;
      if (isCorrect) {
        _combo++;
        _correct++;
        _maxCombo = max(_maxCombo, _combo);
        _playerScore += 100 + speedBonus + (_combo >= 3 ? 50 : 0);
      } else {
        _combo = 0;
        _playerScore = max(0, _playerScore - 40);
      }
    });
    Future.delayed(const Duration(milliseconds: 850), _goNextQuestion);
  }

  void _goNextQuestion() {
    if (!mounted) return;
    _questionTimer?.cancel();
    _opponentTimer?.cancel();
    if (_questionIndex >= SampleData.questions.length - 1) {
      final summary = MatchSummary(
        player: SampleData.player,
        opponent: SampleData.opponent,
        playerScore: _playerScore,
        opponentScore: _opponentScore,
        correctAnswers: _correct,
        maxCombo: _maxCombo,
        coins: _playerScore >= _opponentScore ? 200 : 60,
        xp: 110 + (_correct * 12),
      );
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => ResultScreen(summary: summary)));
      return;
    }
    setState(() => _questionIndex++);
    _startQuestion();
  }

  @override
  Widget build(BuildContext context) {
    final progress = (_questionIndex + 1) / SampleData.questions.length;
    return Scaffold(
      body: NeonBackground(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 14),
            child: Column(
              children: [
                Row(
                  children: [
                    Expanded(child: PlayerScoreCard(player: SampleData.player, score: _playerScore, alignRight: true)),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                      child: ShaderMask(
                        shaderCallback: (rect) => const LinearGradient(colors: [AppColors.cyan, Colors.white, AppColors.pink]).createShader(rect),
                        child: const Text('VS', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 20)),
                      ),
                    ),
                    Expanded(child: PlayerScoreCard(player: SampleData.opponent, score: _opponentScore, alignRight: false)),
                  ],
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    Expanded(
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(12),
                        child: LinearProgressIndicator(
                          value: progress,
                          minHeight: 9,
                          backgroundColor: Colors.white.withOpacity(.1),
                          valueColor: const AlwaysStoppedAnimation<Color>(AppColors.cyan),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Text('سوال ${_questionIndex + 1} از ${SampleData.questions.length}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12)),
                  ],
                ),
                const SizedBox(height: 18),
                Row(
                  children: [
                    _GameChip(icon: Icons.flash_on_rounded, label: 'کمبو x$_combo', color: AppColors.gold),
                    const Spacer(),
                    _GameChip(icon: Icons.category_rounded, label: _question.category, color: AppColors.purple),
                  ],
                ),
                const SizedBox(height: 12),
                TimerRing(secondsLeft: _secondsLeft, totalSeconds: secondsPerQuestion),
                const SizedBox(height: 18),
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      GlassPanel(
                        radius: 28,
                        borderColor: AppColors.cyan.withOpacity(.72),
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 28),
                        shadows: [BoxShadow(color: AppColors.cyan.withOpacity(.2), blurRadius: 28)],
                        child: Column(
                          children: [
                            Text(_question.type, style: TextStyle(color: Colors.white.withOpacity(.64), fontWeight: FontWeight.w800)),
                            const SizedBox(height: 12),
                            Text(
                              _question.text,
                              textAlign: TextAlign.center,
                              style: const TextStyle(fontSize: 27, height: 1.55, fontWeight: FontWeight.w900),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 20),
                      Row(
                        children: [
                          Expanded(child: AnswerButton(label: 'بله', color: AppColors.green, onTap: () => _submitAnswer(true), disabled: _answered)),
                          const SizedBox(width: 12),
                          Expanded(child: AnswerButton(label: 'نه', color: AppColors.red, onTap: () => _submitAnswer(false), disabled: _answered)),
                        ],
                      ),
                      const SizedBox(height: 14),
                      AnimatedSwitcher(
                        duration: const Duration(milliseconds: 220),
                        child: _lastWasCorrect == null
                            ? const SizedBox(height: 62)
                            : FeedbackPanel(isCorrect: _lastWasCorrect!),
                      ),
                    ],
                  ),
                ),
                Row(
                  children: [
                    Expanded(child: PowerUpTile(icon: Icons.filter_2_rounded, title: '۵۰:۵۰', count: 2)),
                    const SizedBox(width: 10),
                    Expanded(child: PowerUpTile(icon: Icons.block_rounded, title: 'حذف گزینه', count: 2)),
                    const SizedBox(width: 10),
                    Expanded(child: PowerUpTile(icon: Icons.timer_rounded, title: 'زمان بیشتر', count: 1)),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class PlayerScoreCard extends StatelessWidget {
  final PlayerProfile player;
  final int score;
  final bool alignRight;
  const PlayerScoreCard({required this.player, required this.score, required this.alignRight, super.key});

  @override
  Widget build(BuildContext context) {
    return GlassPanel(
      radius: 22,
      padding: const EdgeInsets.all(10),
      borderColor: player.color,
      gradient: LinearGradient(colors: [player.color.withOpacity(.20), Colors.white.withOpacity(.04)]),
      child: Row(
        textDirection: alignRight ? TextDirection.rtl : TextDirection.ltr,
        children: [
          PlayerAvatar(player: player, size: 44),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: alignRight ? CrossAxisAlignment.start : CrossAxisAlignment.end,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(player.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800)),
                const SizedBox(height: 4),
                Text('$score', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: player.color)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _GameChip extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  const _GameChip({required this.icon, required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return GlassPanel(
      radius: 16,
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      borderColor: color,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: color, size: 17),
          const SizedBox(width: 6),
          Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }
}

class TimerRing extends StatelessWidget {
  final int secondsLeft;
  final int totalSeconds;
  const TimerRing({required this.secondsLeft, required this.totalSeconds, super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 122,
      height: 122,
      child: Stack(
        alignment: Alignment.center,
        children: [
          CustomPaint(
            size: const Size(122, 122),
            painter: _TimerRingPainter(progress: secondsLeft / totalSeconds),
          ),
          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('$secondsLeft'.padLeft(2, '0'), style: const TextStyle(fontSize: 35, fontWeight: FontWeight.w900)),
              Text('ثانیه', style: TextStyle(fontSize: 12, color: Colors.white.withOpacity(.62))),
            ],
          ),
        ],
      ),
    );
  }
}

class _TimerRingPainter extends CustomPainter {
  final double progress;
  const _TimerRingPainter({required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    final center = size.center(Offset.zero);
    final rect = Rect.fromCircle(center: center, radius: size.width / 2 - 8);
    final base = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 10
      ..strokeCap = StrokeCap.round
      ..color = Colors.white.withOpacity(.10);
    canvas.drawArc(rect, -pi / 2, pi * 2, false, base);

    final sweep = pi * 2 * progress.clamp(0, 1);
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 10
      ..strokeCap = StrokeCap.round
      ..shader = const SweepGradient(
        colors: [AppColors.cyan, AppColors.purple, AppColors.pink, AppColors.cyan],
      ).createShader(rect);
    canvas.drawArc(rect, -pi / 2, sweep, false, paint);
  }

  @override
  bool shouldRepaint(covariant _TimerRingPainter oldDelegate) => oldDelegate.progress != progress;
}

class AnswerButton extends StatelessWidget {
  final String label;
  final Color color;
  final VoidCallback onTap;
  final bool disabled;
  const AnswerButton({required this.label, required this.color, required this.onTap, this.disabled = false, super.key});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(22),
      onTap: disabled ? null : onTap,
      child: AnimatedOpacity(
        duration: const Duration(milliseconds: 160),
        opacity: disabled ? .65 : 1,
        child: Container(
          height: 70,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            gradient: LinearGradient(colors: [color, color.withOpacity(.46)]),
            border: Border.all(color: Colors.white.withOpacity(.28), width: 1.4),
            boxShadow: [BoxShadow(color: color.withOpacity(.36), blurRadius: 24, offset: const Offset(0, 10))],
          ),
          child: Text(label, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
        ),
      ),
    );
  }
}

class FeedbackPanel extends StatelessWidget {
  final bool isCorrect;
  const FeedbackPanel({required this.isCorrect, super.key});

  @override
  Widget build(BuildContext context) {
    final color = isCorrect ? AppColors.green : AppColors.red;
    return GlassPanel(
      key: ValueKey(isCorrect),
      radius: 20,
      borderColor: color,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      gradient: LinearGradient(colors: [color.withOpacity(.18), Colors.white.withOpacity(.04)]),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(isCorrect ? Icons.check_circle_rounded : Icons.cancel_rounded, color: color, size: 30),
          const SizedBox(width: 10),
          Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(isCorrect ? 'درست!' : 'غلط!', style: TextStyle(fontWeight: FontWeight.w900, color: color, fontSize: 18)),
              Text(isCorrect ? '+ امتیاز سرعت' : '-۴۰ امتیاز', style: TextStyle(fontSize: 12, color: Colors.white.withOpacity(.65))),
            ],
          ),
        ],
      ),
    );
  }
}

class PowerUpTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final int count;
  const PowerUpTile({required this.icon, required this.title, required this.count, super.key});

  @override
  Widget build(BuildContext context) {
    return GlassPanel(
      radius: 20,
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
      borderColor: AppColors.cyan,
      child: Column(
        children: [
          Stack(
            clipBehavior: Clip.none,
            children: [
              Icon(icon, color: AppColors.cyan, size: 27),
              Positioned(
                top: -8,
                left: -12,
                child: Container(
                  width: 22,
                  height: 22,
                  alignment: Alignment.center,
                  decoration: const BoxDecoration(color: AppColors.gold, shape: BoxShape.circle),
                  child: Text('$count', style: const TextStyle(fontSize: 11, color: Colors.black, fontWeight: FontWeight.w900)),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(title, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800)),
        ],
      ),
    );
  }
}


class PremiumTrophy extends StatelessWidget {
  final double size;
  final bool winner;

  const PremiumTrophy({this.size = 86, this.winner = true, super.key});

  @override
  Widget build(BuildContext context) {
    final trophyColor = winner ? AppColors.gold : AppColors.pink;
    return SizedBox(
      width: size * 1.28,
      height: size * 1.08,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(color: trophyColor.withOpacity(.48), blurRadius: size * .46, spreadRadius: size * .04),
                  BoxShadow(color: AppColors.cyan.withOpacity(.18), blurRadius: size * .34, spreadRadius: size * .02),
                ],
              ),
            ),
          ),
          CustomPaint(
            size: Size(size * 1.10, size),
            painter: _PremiumTrophyPainter(color: trophyColor, winner: winner),
          ),
          Positioned(
            top: size * .04,
            right: size * .23,
            child: _Spark(size: size * .12, color: Colors.white.withOpacity(.95)),
          ),
          Positioned(
            top: size * .21,
            left: size * .16,
            child: _Spark(size: size * .09, color: trophyColor.withOpacity(.95)),
          ),
        ],
      ),
    );
  }
}

class _Spark extends StatelessWidget {
  final double size;
  final Color color;

  const _Spark({required this.size, required this.color});

  @override
  Widget build(BuildContext context) {
    return Transform.rotate(
      angle: pi / 4,
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          gradient: RadialGradient(colors: [color, color.withOpacity(.08)]),
          borderRadius: BorderRadius.circular(3),
        ),
      ),
    );
  }
}

class _PremiumTrophyPainter extends CustomPainter {
  final Color color;
  final bool winner;

  const _PremiumTrophyPainter({required this.color, required this.winner});

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final center = Offset(w / 2, h / 2);
    final shadow = Paint()
      ..color = Colors.black.withOpacity(.35)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10);

    final rimRect = Rect.fromCenter(center: Offset(center.dx, h * .20), width: w * .48, height: h * .12);
    final cupPath = Path()
      ..moveTo(w * .25, h * .22)
      ..cubicTo(w * .28, h * .48, w * .36, h * .61, w * .50, h * .63)
      ..cubicTo(w * .64, h * .61, w * .72, h * .48, w * .75, h * .22)
      ..close();

    final bodyGradient = LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: winner
          ? const [Color(0xFFFFF3A0), Color(0xFFFFC857), Color(0xFFC87400), Color(0xFFFFDF73)]
          : const [Color(0xFFFFB0DC), Color(0xFFFF3FA4), Color(0xFF9F185D), Color(0xFFFF8FCC)],
      stops: const [.02, .38, .72, 1],
    );

    canvas.drawPath(cupPath.shift(const Offset(0, 6)), shadow);
    canvas.drawPath(cupPath, Paint()..shader = bodyGradient.createShader(Rect.fromLTWH(0, 0, w, h)));
    canvas.drawOval(rimRect, Paint()..shader = bodyGradient.createShader(rimRect));

    final rimStroke = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.2
      ..color = Colors.white.withOpacity(.55);
    canvas.drawOval(rimRect.deflate(1), rimStroke);

    final handlePaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = w * .055
      ..strokeCap = StrokeCap.round
      ..shader = bodyGradient.createShader(Rect.fromLTWH(0, h * .18, w, h * .34));
    final leftHandle = Path()
      ..moveTo(w * .27, h * .29)
      ..cubicTo(w * .08, h * .28, w * .11, h * .55, w * .33, h * .50);
    final rightHandle = Path()
      ..moveTo(w * .73, h * .29)
      ..cubicTo(w * .92, h * .28, w * .89, h * .55, w * .67, h * .50);
    canvas.drawPath(leftHandle, handlePaint);
    canvas.drawPath(rightHandle, handlePaint);

    final stemRect = RRect.fromRectAndRadius(Rect.fromCenter(center: Offset(center.dx, h * .72), width: w * .20, height: h * .20), Radius.circular(w * .05));
    canvas.drawRRect(stemRect, Paint()..shader = bodyGradient.createShader(stemRect.outerRect));

    final baseRect = RRect.fromRectAndRadius(Rect.fromCenter(center: Offset(center.dx, h * .86), width: w * .55, height: h * .15), Radius.circular(w * .07));
    final basePaint = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [Color(0xFF30225E), Color(0xFF0A102B), Color(0xFF6A4BFF)],
      ).createShader(baseRect.outerRect);
    canvas.drawRRect(baseRect.shift(const Offset(0, 5)), shadow);
    canvas.drawRRect(baseRect, basePaint);
    canvas.drawRRect(baseRect, Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.4
      ..color = color.withOpacity(.72));

    final plateRect = RRect.fromRectAndRadius(Rect.fromCenter(center: Offset(center.dx, h * .86), width: w * .30, height: h * .062), Radius.circular(w * .03));
    canvas.drawRRect(plateRect, Paint()..color = color.withOpacity(.92));

    final shinePaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeWidth = 2.3
      ..color = Colors.white.withOpacity(.58);
    canvas.drawLine(Offset(w * .39, h * .27), Offset(w * .34, h * .50), shinePaint);
    canvas.drawLine(Offset(w * .49, h * .21), Offset(w * .61, h * .21), shinePaint..strokeWidth = 1.6);
  }

  @override
  bool shouldRepaint(covariant _PremiumTrophyPainter oldDelegate) {
    return oldDelegate.color != color || oldDelegate.winner != winner;
  }
}

class ResultScreen extends StatelessWidget {
  final MatchSummary summary;
  const ResultScreen({required this.summary, super.key});

  @override
  Widget build(BuildContext context) {
    final title = summary.isWinner ? 'شما برنده شدید!' : 'باختی، ولی نزدیک بود!';
    final color = summary.isWinner ? AppColors.gold : AppColors.pink;
    return Scaffold(
      body: NeonBackground(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              children: [
                const SizedBox(height: 16),
                PremiumTrophy(size: 92, winner: summary.isWinner),
                const SizedBox(height: 10),
                Text(title, style: TextStyle(fontSize: 31, fontWeight: FontWeight.w900, color: color)),
                const SizedBox(height: 10),
                Text('نتیجه مسابقه آنلاین', style: TextStyle(color: Colors.white.withOpacity(.65))),
                const SizedBox(height: 28),
                GlassPanel(
                  radius: 30,
                  padding: const EdgeInsets.all(18),
                  borderColor: color,
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Expanded(child: _ResultPlayer(player: summary.player, score: summary.playerScore, color: AppColors.cyan)),
                          Column(
                            children: [
                              const PremiumTrophy(size: 56),
                              Text('VS', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: Colors.white.withOpacity(.9))),
                            ],
                          ),
                          Expanded(child: _ResultPlayer(player: summary.opponent, score: summary.opponentScore, color: AppColors.pink)),
                        ],
                      ),
                      const SizedBox(height: 22),
                      Row(
                        children: [
                          Expanded(child: _RewardTile(icon: Icons.monetization_on_rounded, value: '+${summary.coins}', label: 'سکه', color: AppColors.gold)),
                          const SizedBox(width: 10),
                          Expanded(child: _RewardTile(icon: Icons.hexagon_rounded, value: '+${summary.xp}', label: 'XP', color: AppColors.cyan)),
                          const SizedBox(width: 10),
                          Expanded(child: _RewardTile(icon: Icons.flash_on_rounded, value: '${summary.maxCombo}', label: 'بهترین کمبو', color: AppColors.purple)),
                        ],
                      ),
                    ],
                  ),
                ),
                const Spacer(),
                NeonButton(
                  label: 'بازی دوباره',
                  icon: Icons.restart_alt_rounded,
                  onTap: () => Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const MatchmakingScreen())),
                ),
                const SizedBox(height: 12),
                NeonButton(
                  label: 'بازگشت به خانه',
                  icon: Icons.home_rounded,
                  color: Colors.blueGrey,
                  compact: true,
                  onTap: () => Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (_) => const HomeScreen()),
                    (_) => false,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _ResultPlayer extends StatelessWidget {
  final PlayerProfile player;
  final int score;
  final Color color;
  const _ResultPlayer({required this.player, required this.score, required this.color});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        PlayerAvatar(player: player, size: 68),
        const SizedBox(height: 10),
        Text(player.name, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w900)),
        const SizedBox(height: 7),
        Text('$score', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: color)),
      ],
    );
  }
}

class _RewardTile extends StatelessWidget {
  final IconData icon;
  final String value;
  final String label;
  final Color color;
  const _RewardTile({required this.icon, required this.value, required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: Colors.white.withOpacity(.06),
        border: Border.all(color: color.withOpacity(.35)),
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: 30),
          const SizedBox(height: 8),
          Text(value, style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18, color: color)),
          Text(label, style: TextStyle(fontSize: 11, color: Colors.white.withOpacity(.63))),
        ],
      ),
    );
  }
}

class PrivateRoomScreen extends StatelessWidget {
  const PrivateRoomScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: NeonBackground(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              children: [
                Row(
                  children: [
                    _RoundIconButton(icon: Icons.arrow_back_rounded, onTap: () => Navigator.of(context).pop()),
                    const Expanded(child: Center(child: Text('اتاق خصوصی', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)))),
                    const SizedBox(width: 48),
                  ],
                ),
                const SizedBox(height: 40),
                GlassPanel(
                  radius: 30,
                  padding: const EdgeInsets.all(22),
                  borderColor: AppColors.pink,
                  child: Column(
                    children: [
                      const Icon(Icons.groups_rounded, color: AppColors.pink, size: 64),
                      const SizedBox(height: 16),
                      const Text('ساخت اتاق دوستانه', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
                      const SizedBox(height: 12),
                      Text(
                        'در نسخه آنلاین، این بخش یک کد کوتاه می‌سازد تا دوستت با لینک یا کد وارد رقابت شود.',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.white.withOpacity(.7)),
                      ),
                      const SizedBox(height: 22),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(22),
                          color: Colors.white.withOpacity(.08),
                          border: Border.all(color: AppColors.cyan.withOpacity(.35)),
                        ),
                        child: const Text('کد اتاق: DJ-4821', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900, letterSpacing: 1)),
                      ),
                      const SizedBox(height: 20),
                      NeonButton(label: 'شروع اتاق خصوصی', icon: Icons.play_arrow_rounded, onTap: () {}, compact: true),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class LeaderboardScreen extends StatelessWidget {
  const LeaderboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: NeonBackground(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              children: [
                Row(
                  children: [
                    _RoundIconButton(icon: Icons.arrow_back_rounded, onTap: () => Navigator.of(context).pop()),
                    const Expanded(child: Center(child: Text('رتبه‌بندی', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)))),
                    const SizedBox(width: 48),
                  ],
                ),
                const SizedBox(height: 20),
                GlassPanel(
                  radius: 26,
                  padding: const EdgeInsets.all(12),
                  child: Row(
                    children: [
                      Expanded(child: _LeagueTab(label: 'روزانه', selected: true)),
                      Expanded(child: _LeagueTab(label: 'هفتگی', selected: false)),
                      Expanded(child: _LeagueTab(label: 'ماهانه', selected: false)),
                    ],
                  ),
                ),
                const SizedBox(height: 18),
                Expanded(
                  child: GlassPanel(
                    radius: 28,
                    padding: const EdgeInsets.all(14),
                    child: ListView.builder(
                      physics: const BouncingScrollPhysics(),
                      itemCount: SampleData.leaderboard.length,
                      itemBuilder: (context, index) => _RankRow(index: index + 1, data: SampleData.leaderboard[index]),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _LeagueTab extends StatelessWidget {
  final String label;
  final bool selected;
  const _LeagueTab({required this.label, required this.selected});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 4),
      padding: const EdgeInsets.symmetric(vertical: 12),
      alignment: Alignment.center,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(17),
        gradient: selected ? const LinearGradient(colors: [AppColors.blue, AppColors.cyan]) : null,
        color: selected ? null : Colors.white.withOpacity(.05),
      ),
      child: Text(label, style: const TextStyle(fontWeight: FontWeight.w900)),
    );
  }
}

String _formatNumber(int value) {
  final s = value.toString();
  final buffer = StringBuffer();
  for (int i = 0; i < s.length; i++) {
    final reverseIndex = s.length - i;
    buffer.write(s[i]);
    if (reverseIndex > 1 && reverseIndex % 3 == 1) buffer.write(',');
  }
  return buffer.toString();
}
