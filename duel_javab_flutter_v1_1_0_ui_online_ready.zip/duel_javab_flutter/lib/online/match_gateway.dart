import 'dart:async';

/// مرحله بعد معماری آنلاین بازی.
///
/// این فایل عمداً بدون وابستگی Firebase نوشته شده تا پروژه فعلی بدون تنظیمات
/// google-services.json هم خروجی APK بگیرد. برای آنلاین واقعی، فقط کافی است
/// یک پیاده‌سازی FirebaseMatchGateway یا SocketMatchGateway از این قرارداد ساخته شود.
abstract class MatchGateway {
  Future<MatchRoomSnapshot> createOrJoinQuickMatch(PlayerIdentity player);

  Future<MatchRoomSnapshot> createPrivateRoom(PlayerIdentity player);

  Future<MatchRoomSnapshot> joinPrivateRoom({
    required String roomCode,
    required PlayerIdentity player,
  });

  Stream<MatchRoomSnapshot> watchRoom(String roomId);

  Future<void> submitAnswer({
    required String roomId,
    required String playerId,
    required String questionId,
    required bool answer,
    required int clientElapsedMs,
  });

  Future<void> leaveRoom({
    required String roomId,
    required String playerId,
  });
}

class PlayerIdentity {
  final String id;
  final String name;
  final String rank;
  final int trophies;

  const PlayerIdentity({
    required this.id,
    required this.name,
    required this.rank,
    required this.trophies,
  });

  Map<String, Object> toJson() => {
        'id': id,
        'name': name,
        'rank': rank,
        'trophies': trophies,
      };
}

class MatchRoomSnapshot {
  final String roomId;
  final String roomCode;
  final MatchStatus status;
  final List<PlayerIdentity> players;
  final int currentQuestionIndex;
  final int playerScore;
  final int opponentScore;
  final DateTime? serverStartedAt;

  const MatchRoomSnapshot({
    required this.roomId,
    required this.roomCode,
    required this.status,
    required this.players,
    required this.currentQuestionIndex,
    required this.playerScore,
    required this.opponentScore,
    required this.serverStartedAt,
  });
}

enum MatchStatus {
  waiting,
  countdown,
  playing,
  finished,
  cancelled,
}

/// پیاده‌سازی موقت برای تست UI. بعداً با Firebase/Socket جایگزین می‌شود.
class LocalSimulatedMatchGateway implements MatchGateway {
  final StreamController<MatchRoomSnapshot> _roomController = StreamController<MatchRoomSnapshot>.broadcast();
  MatchRoomSnapshot? _lastRoom;

  @override
  Future<MatchRoomSnapshot> createOrJoinQuickMatch(PlayerIdentity player) async {
    final room = MatchRoomSnapshot(
      roomId: 'local-room-${DateTime.now().millisecondsSinceEpoch}',
      roomCode: 'DUEL24',
      status: MatchStatus.countdown,
      players: [
        player,
        const PlayerIdentity(id: 'bot-1', name: 'امیر محمدی', rank: 'الماس ۱', trophies: 2140),
      ],
      currentQuestionIndex: 0,
      playerScore: 0,
      opponentScore: 0,
      serverStartedAt: DateTime.now(),
    );
    _lastRoom = room;
    _roomController.add(room);
    return room;
  }

  @override
  Future<MatchRoomSnapshot> createPrivateRoom(PlayerIdentity player) async {
    final room = MatchRoomSnapshot(
      roomId: 'private-${DateTime.now().millisecondsSinceEpoch}',
      roomCode: 'JAVAB-${1000 + DateTime.now().second}',
      status: MatchStatus.waiting,
      players: [player],
      currentQuestionIndex: 0,
      playerScore: 0,
      opponentScore: 0,
      serverStartedAt: null,
    );
    _lastRoom = room;
    _roomController.add(room);
    return room;
  }

  @override
  Future<MatchRoomSnapshot> joinPrivateRoom({required String roomCode, required PlayerIdentity player}) async {
    final room = MatchRoomSnapshot(
      roomId: 'joined-$roomCode',
      roomCode: roomCode,
      status: MatchStatus.countdown,
      players: [
        const PlayerIdentity(id: 'host', name: 'بازیکن میزبان', rank: 'طلا ۳', trophies: 1760),
        player,
      ],
      currentQuestionIndex: 0,
      playerScore: 0,
      opponentScore: 0,
      serverStartedAt: DateTime.now(),
    );
    _lastRoom = room;
    _roomController.add(room);
    return room;
  }

  @override
  Stream<MatchRoomSnapshot> watchRoom(String roomId) {
    if (_lastRoom != null) {
      Future<void>.microtask(() => _roomController.add(_lastRoom!));
    }
    return _roomController.stream;
  }

  @override
  Future<void> submitAnswer({
    required String roomId,
    required String playerId,
    required String questionId,
    required bool answer,
    required int clientElapsedMs,
  }) async {
    // در نسخه آنلاین واقعی، امتیاز باید سمت سرور و با server timestamp محاسبه شود.
  }

  @override
  Future<void> leaveRoom({required String roomId, required String playerId}) async {
    _lastRoom = null;
  }

  void dispose() {
    _roomController.close();
  }
}
