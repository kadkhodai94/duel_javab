import 'dart:async';
import 'dart:math';
import 'dart:ui';

import 'package:flutter/material.dart';

void main() {
  runApp(const DuelJavabApp());
}

class DuelJavabApp extends StatelessWidget {
  const DuelJavabApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'دوئل جواب',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: null,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: AppColors.bgTop,
        colorScheme: ColorScheme.fromSeed(seedColor: AppColors.cyan, brightness: Brightness.dark),
      ),
      builder: (context, child) {
        return Directionality(textDirection: TextDirection.rtl, child: child ?? const SizedBox.shrink());
      },
      home: const ShellScreen(),
    );
  }
}

class AppColors {
  static const bgTop = Color(0xFF05091D);
  static const bgMid = Color(0xFF08143A);
  static const bgBottom = Color(0xFF170633);
  static const cyan = Color(0xFF20B6FF);
  static const blue = Color(0xFF006DFF);
  static const pink = Color(0xFFFF3FA4);
  static const purple = Color(0xFF8B5CFF);
  static const gold = Color(0xFFFFC857);
  static const green = Color(0xFF15D17C);
  static const red = Color(0xFFFF435D);
  static const orange = Color(0xFFFF8A3D);
  static const panel = Color(0xCC0B1230);
}

class PlayerProfile {
  final String id;
  final String name;
  final String rank;
  final int trophy;
  final int coins;
  final int xp;
  final int wins;
  final int losses;
  final int streak;
  final Color color;
  final IconData avatarIcon;

  const PlayerProfile({
    required this.id,
    required this.name,
    required this.rank,
    required this.trophy,
    required this.coins,
    required this.xp,
    required this.wins,
    required this.losses,
    required this.streak,
    required this.color,
    required this.avatarIcon,
  });

  PlayerProfile copyWith({
    String? id,
    String? name,
    String? rank,
    int? trophy,
    int? coins,
    int? xp,
    int? wins,
    int? losses,
    int? streak,
    Color? color,
    IconData? avatarIcon,
  }) {
    return PlayerProfile(
      id: id ?? this.id,
      name: name ?? this.name,
      rank: rank ?? this.rank,
      trophy: trophy ?? this.trophy,
      coins: coins ?? this.coins,
      xp: xp ?? this.xp,
      wins: wins ?? this.wins,
      losses: losses ?? this.losses,
      streak: streak ?? this.streak,
      color: color ?? this.color,
      avatarIcon: avatarIcon ?? this.avatarIcon,
    );
  }
}

class DuelQuestion {
  final String id;
  final String text;
  final bool answer;
  final String type;
  final String category;
  final int difficulty;

  const DuelQuestion({
    required this.id,
    required this.text,
    required this.answer,
    required this.type,
    required this.category,
    required this.difficulty,
  });
}

enum DuelMode { ranked, private, practice, daily }

extension DuelModeLabel on DuelMode {
  String get title {
    switch (this) {
      case DuelMode.ranked:
        return 'رقابت آنلاین';
      case DuelMode.private:
        return 'اتاق خصوصی';
      case DuelMode.practice:
        return 'تمرین سریع';
      case DuelMode.daily:
        return 'چالش روزانه';
    }
  }

  String get subtitle {
    switch (this) {
      case DuelMode.ranked:
        return 'شبیه‌ساز آنلاین آماده اتصال به Socket.IO';
      case DuelMode.private:
        return 'بازی با کد اتاق و دعوت دوست';
      case DuelMode.practice:
        return 'تمرین بدون تغییر رتبه';
      case DuelMode.daily:
        return '۱۰ سوال ویژه امروز';
    }
  }
}

class GameStats {
  final int playerScore;
  final int opponentScore;
  final int correctAnswers;
  final int wrongAnswers;
  final int maxCombo;
  final int fastestMs;
  final int coins;
  final int xp;
  final int trophyChange;
  final DuelMode mode;
  final PlayerProfile player;
  final PlayerProfile opponent;

  const GameStats({
    required this.playerScore,
    required this.opponentScore,
    required this.correctAnswers,
    required this.wrongAnswers,
    required this.maxCombo,
    required this.fastestMs,
    required this.coins,
    required this.xp,
    required this.trophyChange,
    required this.mode,
    required this.player,
    required this.opponent,
  });

  bool get isWinner => playerScore >= opponentScore;
}

class Mission {
  final IconData icon;
  final String title;
  final String description;
  final int progress;
  final int target;
  final int reward;
  final Color color;

  const Mission({
    required this.icon,
    required this.title,
    required this.description,
    required this.progress,
    required this.target,
    required this.reward,
    required this.color,
  });
}

class StoreItem {
  final IconData icon;
  final String title;
  final String description;
  final int price;
  final Color color;

  const StoreItem({required this.icon, required this.title, required this.description, required this.price, required this.color});
}

class RuntimeState {
  RuntimeState._();
  static final RuntimeState instance = RuntimeState._();

  final ValueNotifier<PlayerProfile> player = ValueNotifier<PlayerProfile>(SampleData.player);
  final ValueNotifier<List<GameStats>> history = ValueNotifier<List<GameStats>>(<GameStats>[]);

  void applyMatch(GameStats stats) {
    history.value = [stats, ...history.value].take(20).toList();
    if (stats.mode == DuelMode.practice) return;
    final current = player.value;
    player.value = current.copyWith(
      coins: current.coins + stats.coins,
      xp: current.xp + stats.xp,
      trophy: max(0, current.trophy + stats.trophyChange),
      wins: current.wins + (stats.isWinner ? 1 : 0),
      losses: current.losses + (stats.isWinner ? 0 : 1),
      streak: stats.isWinner ? current.streak + 1 : 0,
      rank: _rankForTrophy(max(0, current.trophy + stats.trophyChange)),
    );
  }

  String _rankForTrophy(int trophy) {
    if (trophy >= 5000) return 'قهرمان';
    if (trophy >= 3000) return 'الماس ۱';
    if (trophy >= 2200) return 'الماس ۲';
    if (trophy >= 1500) return 'طلایی';
    if (trophy >= 800) return 'نقره‌ای';
    return 'برنزی';
  }
}

class SampleData {
  static const player = PlayerProfile(
    id: 'me',
    name: 'علی رستمی',
    rank: 'الماس ۲',
    trophy: 2450,
    coins: 12450,
    xp: 7600,
    wins: 128,
    losses: 42,
    streak: 8,
    color: AppColors.cyan,
    avatarIcon: Icons.person_rounded,
  );

  static const bots = <PlayerProfile>[
    PlayerProfile(id: 'bot_1', name: 'امیر محمدی', rank: 'الماس ۱', trophy: 2140, coins: 8350, xp: 5900, wins: 96, losses: 38, streak: 4, color: AppColors.pink, avatarIcon: Icons.person_4_rounded),
    PlayerProfile(id: 'bot_2', name: 'نیما شریفی', rank: 'یاقوت', trophy: 2010, coins: 6400, xp: 5200, wins: 87, losses: 44, streak: 2, color: AppColors.purple, avatarIcon: Icons.face_rounded),
    PlayerProfile(id: 'bot_3', name: 'سینا کریمی', rank: 'طلا', trophy: 1840, coins: 5300, xp: 4700, wins: 74, losses: 31, streak: 6, color: AppColors.orange, avatarIcon: Icons.support_agent_rounded),
  ];

  static const questions = <DuelQuestion>[
    DuelQuestion(id: 'q1', text: 'آیا خورشید یک ستاره است؟', answer: true, type: 'بله / نه', category: 'علمی', difficulty: 1),
    DuelQuestion(id: 'q2', text: 'تهران پایتخت ایران است.', answer: true, type: 'درست / غلط', category: 'عمومی', difficulty: 1),
    DuelQuestion(id: 'q3', text: 'عدد ۹ یک عدد زوج است.', answer: false, type: 'درست / غلط', category: 'ریاضی', difficulty: 1),
    DuelQuestion(id: 'q4', text: 'آب در دمای معمولی مایع است.', answer: true, type: 'درست / غلط', category: 'علمی', difficulty: 1),
    DuelQuestion(id: 'q5', text: 'قاره آفریقا کوچک‌ترین قاره جهان است.', answer: false, type: 'درست / غلط', category: 'جغرافیا', difficulty: 2),
    DuelQuestion(id: 'q6', text: 'آیا ماه از خودش نور تولید می‌کند؟', answer: false, type: 'بله / نه', category: 'علمی', difficulty: 2),
    DuelQuestion(id: 'q7', text: 'زبان فارسی از راست به چپ نوشته می‌شود.', answer: true, type: 'درست / غلط', category: 'عمومی', difficulty: 1),
    DuelQuestion(id: 'q8', text: 'در فوتبال هر تیم ۱۱ بازیکن اصلی دارد.', answer: true, type: 'درست / غلط', category: 'ورزشی', difficulty: 1),
    DuelQuestion(id: 'q9', text: 'آیا نهنگ یک ماهی است؟', answer: false, type: 'بله / نه', category: 'حیوانات', difficulty: 2),
    DuelQuestion(id: 'q10', text: 'کوه اورست بلندترین قله جهان است.', answer: true, type: 'درست / غلط', category: 'جغرافیا', difficulty: 1),
    DuelQuestion(id: 'q11', text: 'آیا اقیانوس آرام بزرگ‌ترین اقیانوس جهان است؟', answer: true, type: 'بله / نه', category: 'جغرافیا', difficulty: 2),
    DuelQuestion(id: 'q12', text: 'سرعت نور کمتر از سرعت صوت است.', answer: false, type: 'درست / غلط', category: 'علمی', difficulty: 3),
    DuelQuestion(id: 'q13', text: 'آیا زحل حلقه دارد؟', answer: true, type: 'بله / نه', category: 'علمی', difficulty: 1),
    DuelQuestion(id: 'q14', text: 'مثلث چهار ضلع دارد.', answer: false, type: 'درست / غلط', category: 'ریاضی', difficulty: 1),
    DuelQuestion(id: 'q15', text: 'آیا ایران در آسیا قرار دارد؟', answer: true, type: 'بله / نه', category: 'جغرافیا', difficulty: 1),
    DuelQuestion(id: 'q16', text: 'زرافه کوتاه‌ترین حیوان خشکی است.', answer: false, type: 'درست / غلط', category: 'حیوانات', difficulty: 2),
    DuelQuestion(id: 'q17', text: 'آیا بدن انسان بیش از ۲۰۰ استخوان دارد؟', answer: true, type: 'بله / نه', category: 'علمی', difficulty: 2),
    DuelQuestion(id: 'q18', text: 'در شطرنج، شاه مهم‌ترین مهره است.', answer: true, type: 'درست / غلط', category: 'ورزشی', difficulty: 2),
    DuelQuestion(id: 'q19', text: 'آیا زمستان بعد از پاییز می‌آید؟', answer: true, type: 'بله / نه', category: 'عمومی', difficulty: 1),
    DuelQuestion(id: 'q20', text: 'در زبان فارسی عدد ۱۰ با «ده» نوشته می‌شود.', answer: true, type: 'درست / غلط', category: 'عمومی', difficulty: 1),
  ];

  static const leaderboard = <Map<String, Object>>[
    {'name': 'پارسا نیکو', 'score': 28450, 'rank': 'قهرمان', 'change': '+3'},
    {'name': 'مهدی اسدی', 'score': 24780, 'rank': 'الماس ۱', 'change': '+1'},
    {'name': 'نیما شریفی', 'score': 21300, 'rank': 'یاقوت', 'change': '-1'},
    {'name': 'سینا کریمی', 'score': 20120, 'rank': 'طلایی', 'change': '+4'},
    {'name': 'آرمان امیری', 'score': 18970, 'rank': 'طلایی', 'change': '0'},
    {'name': 'علی رستمی', 'score': 17650, 'rank': 'الماس ۲', 'change': '+2'},
  ];

  static const missions = <Mission>[
    Mission(icon: Icons.flash_on_rounded, title: 'شروع قدرتمند', description: '۳ مسابقه رقابتی انجام بده', progress: 2, target: 3, reward: 120, color: AppColors.cyan),
    Mission(icon: Icons.local_fire_department_rounded, title: 'کمبو آتشین', description: '۵ جواب درست پشت سر هم بزن', progress: 4, target: 5, reward: 180, color: AppColors.orange),
    Mission(icon: Icons.emoji_events_rounded, title: 'شکارچی جام', description: '۲ مسابقه را برنده شو', progress: 1, target: 2, reward: 250, color: AppColors.gold),
    Mission(icon: Icons.speed_rounded, title: 'جواب برق‌آسا', description: 'زیر ۲ ثانیه جواب درست بده', progress: 1, target: 1, reward: 90, color: AppColors.pink),
  ];

  static const store = <StoreItem>[
    StoreItem(icon: Icons.timer_rounded, title: 'زمان بیشتر', description: '+۳ ثانیه برای یک سوال حساس', price: 350, color: AppColors.cyan),
    StoreItem(icon: Icons.shield_rounded, title: 'سپر خطا', description: 'یک جواب غلط بدون جریمه', price: 450, color: AppColors.green),
    StoreItem(icon: Icons.bolt_rounded, title: 'ضریب امتیاز', description: 'امتیاز سوال بعدی دو برابر', price: 650, color: AppColors.gold),
    StoreItem(icon: Icons.auto_awesome_rounded, title: 'قاب نئونی', description: 'ظاهر ویژه برای کارت پروفایل', price: 1200, color: AppColors.purple),
  ];
}

class NeonBackground extends StatelessWidget {
  final Widget child;
  const NeonBackground({required this.child, super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [AppColors.bgTop, AppColors.bgMid, AppColors.bgBottom]),
      ),
      child: Stack(
        children: [
          const Positioned(top: -100, right: -70, child: _GlowOrb(size: 240, color: AppColors.blue)),
          const Positioned(top: 230, left: -90, child: _GlowOrb(size: 240, color: AppColors.pink)),
          const Positioned(bottom: -120, right: 60, child: _GlowOrb(size: 260, color: AppColors.purple)),
          Positioned.fill(child: CustomPaint(painter: _GridPainter())),
          child,
        ],
      ),
    );
  }
}

class _GlowOrb extends StatelessWidget {
  final double size;
  final Color color;
  const _GlowOrb({required this.size, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(shape: BoxShape.circle, boxShadow: [BoxShadow(color: color.withOpacity(.42), blurRadius: size * .55, spreadRadius: size * .16)]),
    );
  }
}

class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = Colors.white.withOpacity(.035)..strokeWidth = 1;
    for (double y = 90; y < size.height; y += 74) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
    for (double x = 34; x < size.width; x += 74) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class GlassPanel extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final double radius;
  final Gradient? gradient;
  final Color borderColor;
  final List<BoxShadow>? shadows;

  const GlassPanel({
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.radius = 24,
    this.gradient,
    this.borderColor = Colors.white24,
    this.shadows,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            gradient: gradient ?? LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Colors.white.withOpacity(.11), AppColors.panel, Colors.white.withOpacity(.04)]),
            borderRadius: BorderRadius.circular(radius),
            border: Border.all(color: borderColor.withOpacity(.52), width: 1.1),
            boxShadow: shadows ?? [BoxShadow(color: Colors.black.withOpacity(.36), blurRadius: 25, offset: const Offset(0, 16))],
          ),
          child: child,
        ),
      ),
    );
  }
}

class NeonButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback onTap;
  final Color color;
  final bool compact;

  const NeonButton({required this.label, required this.icon, required this.onTap, this.color = AppColors.cyan, this.compact = false, super.key});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(22),
      onTap: onTap,
      child: Container(
        height: compact ? 54 : 70,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          gradient: LinearGradient(colors: [color.withOpacity(.96), color.withOpacity(.24)], begin: Alignment.centerRight, end: Alignment.centerLeft),
          border: Border.all(color: color.withOpacity(.9), width: 1.6),
          boxShadow: [BoxShadow(color: color.withOpacity(.42), blurRadius: 26), BoxShadow(color: Colors.black.withOpacity(.34), blurRadius: 18, offset: const Offset(0, 10))],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            PremiumGameIcon(icon: icon, color: color, size: compact ? 34 : 42, iconSize: compact ? 20 : 25, solid: true),
            const SizedBox(width: 12),
            Text(label, style: TextStyle(fontSize: compact ? 17 : 22, color: Colors.white, fontWeight: FontWeight.w900, shadows: [Shadow(color: color.withOpacity(.75), blurRadius: 12)])),
          ],
        ),
      ),
    );
  }
}

class PlayerAvatar extends StatelessWidget {
  final PlayerProfile player;
  final double size;
  const PlayerAvatar({required this.player, this.size = 58, super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: [player.color, AppColors.purple]), boxShadow: [BoxShadow(color: player.color.withOpacity(.52), blurRadius: 20)]),
      padding: const EdgeInsets.all(3),
      child: Container(decoration: const BoxDecoration(shape: BoxShape.circle, color: Color(0xFF101A3C)), child: Icon(player.avatarIcon, size: size * .55, color: Colors.white)),
    );
  }
}

class PremiumGameIcon extends StatelessWidget {
  final IconData icon;
  final Color color;
  final double size;
  final double iconSize;
  final String? badge;
  final bool solid;

  const PremiumGameIcon({
    required this.icon,
    required this.color,
    this.size = 44,
    this.iconSize = 24,
    this.badge,
    this.solid = false,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: Stack(
        clipBehavior: Clip.none,
        alignment: Alignment.center,
        children: [
          Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(size * .32),
                gradient: RadialGradient(
                  center: const Alignment(-.35, -.45),
                  radius: 1.1,
                  colors: solid
                      ? [Colors.white.withOpacity(.34), color.withOpacity(.96), color.withOpacity(.42)]
                      : [Colors.white.withOpacity(.20), color.withOpacity(.24), const Color(0xFF08122F)],
                ),
                border: Border.all(color: color.withOpacity(.82), width: 1.1),
                boxShadow: [
                  BoxShadow(color: color.withOpacity(.35), blurRadius: size * .46, spreadRadius: size * .02),
                  BoxShadow(color: Colors.black.withOpacity(.34), blurRadius: size * .30, offset: Offset(0, size * .18)),
                ],
              ),
            ),
          ),
          Positioned(
            top: size * .13,
            left: size * .16,
            child: Container(width: size * .30, height: size * .10, decoration: BoxDecoration(color: Colors.white.withOpacity(.22), borderRadius: BorderRadius.circular(size))),
          ),
          Icon(icon, color: Colors.white, size: iconSize, shadows: [Shadow(color: color.withOpacity(.8), blurRadius: 14)]),
          if (badge != null)
            Positioned(
              top: -6,
              right: -6,
              child: Container(
                width: size * .42,
                height: size * .42,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const LinearGradient(colors: [Colors.white, AppColors.gold]),
                  border: Border.all(color: Colors.black.withOpacity(.18)),
                  boxShadow: [BoxShadow(color: AppColors.gold.withOpacity(.44), blurRadius: 10)],
                ),
                child: Text(badge!, style: const TextStyle(color: Color(0xFF1A1530), fontSize: 11, fontWeight: FontWeight.w900)),
              ),
            ),
        ],
      ),
    );
  }
}

class ShellScreen extends StatefulWidget {
  const ShellScreen({super.key});

  @override
  State<ShellScreen> createState() => _ShellScreenState();
}

class _ShellScreenState extends State<ShellScreen> {
  int _index = 2;
  late final List<Widget> _pages;

  @override
  void initState() {
    super.initState();
    _pages = const [StoreScreen(), MissionsScreen(), HomeScreen(), FriendsScreen(), ProfileScreen()];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: NeonBackground(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 12, 18, 12),
            child: Column(
              children: [
                Expanded(child: AnimatedSwitcher(duration: const Duration(milliseconds: 250), child: _pages[_index])),
                const SizedBox(height: 8),
                DuelBottomNav(current: _index, onChanged: (value) => setState(() => _index = value)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class DuelBottomNav extends StatelessWidget {
  final int current;
  final ValueChanged<int> onChanged;
  const DuelBottomNav({required this.current, required this.onChanged, super.key});

  @override
  Widget build(BuildContext context) {
    const items = [
      _NavItemData(Icons.storefront_rounded, 'فروشگاه', AppColors.gold),
      _NavItemData(Icons.flag_rounded, 'ماموریت', AppColors.purple),
      _NavItemData(Icons.bolt_rounded, 'خانه', AppColors.cyan),
      _NavItemData(Icons.group_rounded, 'دوستان', AppColors.pink),
      _NavItemData(Icons.person_rounded, 'پروفایل', AppColors.green),
    ];
    return GlassPanel(
      radius: 30,
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 6),
      borderColor: AppColors.cyan.withOpacity(.55),
      gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.white.withOpacity(.13), const Color(0xCC070D26), Colors.white.withOpacity(.045)]),
      shadows: [BoxShadow(color: AppColors.cyan.withOpacity(.16), blurRadius: 34, offset: const Offset(0, -4)), BoxShadow(color: Colors.black.withOpacity(.44), blurRadius: 28, offset: const Offset(0, 18))],
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: List.generate(items.length, (i) => Expanded(child: _DuelNavIcon(item: items[i], selected: i == current, onTap: () => onChanged(i)))),
      ),
    );
  }
}

class _NavItemData {
  final IconData icon;
  final String label;
  final Color color;
  const _NavItemData(this.icon, this.label, this.color);
}

class _DuelNavIcon extends StatelessWidget {
  final _NavItemData item;
  final bool selected;
  final VoidCallback onTap;
  const _DuelNavIcon({required this.item, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(22),
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 260),
        curve: Curves.easeOutCubic,
        margin: const EdgeInsets.symmetric(horizontal: 2),
        padding: EdgeInsets.symmetric(vertical: selected ? 8 : 7, horizontal: 4),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          gradient: selected
              ? LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [item.color.withOpacity(.92), AppColors.blue.withOpacity(.50), Colors.white.withOpacity(.06)])
              : LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.white.withOpacity(.06), Colors.white.withOpacity(.015)]),
          border: Border.all(color: selected ? item.color.withOpacity(.92) : Colors.white.withOpacity(.08), width: selected ? 1.3 : .8),
          boxShadow: selected ? [BoxShadow(color: item.color.withOpacity(.38), blurRadius: 20, offset: const Offset(0, 8)), BoxShadow(color: Colors.black.withOpacity(.25), blurRadius: 16, offset: const Offset(0, 10))] : null,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            PremiumGameIcon(icon: item.icon, color: selected ? item.color : Colors.blueGrey, size: 34, iconSize: 20, solid: selected),
            const SizedBox(height: 4),
            Text(item.label, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: selected ? 10.5 : 9.8, color: selected ? Colors.white : Colors.white.withOpacity(.50), fontWeight: selected ? FontWeight.w900 : FontWeight.w700)),
          ],
        ),
      ),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      key: const ValueKey('home'),
      physics: const BouncingScrollPhysics(),
      child: Column(
        children: [
          ValueListenableBuilder<PlayerProfile>(
            valueListenable: RuntimeState.instance.player,
            builder: (_, player, __) => _HomeHeader(player: player),
          ),
          const SizedBox(height: 20),
          const _GameLogo(),
          const SizedBox(height: 14),
          const _FeaturedHomeCard(),
          const SizedBox(height: 16),
          NeonButton(label: 'شروع رقابت', icon: Icons.flash_on_rounded, onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const MatchmakingScreen(mode: DuelMode.ranked)))),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(child: NeonButton(label: 'تمرین', icon: Icons.school_rounded, compact: true, color: AppColors.green, onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const MatchmakingScreen(mode: DuelMode.practice))))),
              const SizedBox(width: 12),
              Expanded(child: NeonButton(label: 'اتاق خصوصی', icon: Icons.groups_rounded, compact: true, color: AppColors.pink, onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const PrivateRoomScreen())))),
            ],
          ),
          const SizedBox(height: 18),
          const _StatsStrip(),
          const SizedBox(height: 18),
          _ModeCards(),
          const SizedBox(height: 18),
          _LeaderboardPreview(onOpen: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const LeaderboardScreen()))),
          const SizedBox(height: 18),
        ],
      ),
    );
  }
}

class _HomeHeader extends StatelessWidget {
  final PlayerProfile player;
  const _HomeHeader({required this.player});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        PlayerAvatar(player: player, size: 58),
        const SizedBox(width: 10),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(player.name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
            const SizedBox(height: 5),
            Row(children: [const Icon(Icons.diamond_rounded, color: AppColors.purple, size: 17), const SizedBox(width: 5), Text(player.rank, style: TextStyle(color: Colors.white.withOpacity(.72), fontSize: 12))]),
          ]),
        ),
        _CoinPill(amount: player.coins),
        const SizedBox(width: 8),
        _RoundIconButton(icon: Icons.tune_rounded, onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const QuestionBankScreen()))),
      ],
    );
  }
}

class _CoinPill extends StatelessWidget {
  final int amount;
  const _CoinPill({required this.amount});

  @override
  Widget build(BuildContext context) {
    return GlassPanel(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      radius: 16,
      borderColor: AppColors.gold,
      child: Row(children: [const Icon(Icons.monetization_on_rounded, color: AppColors.gold, size: 19), const SizedBox(width: 5), Text(_formatNumber(amount), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 13)), const SizedBox(width: 4), const Icon(Icons.add_box_rounded, color: AppColors.gold, size: 16)]),
    );
  }
}

class _RoundIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _RoundIconButton({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(borderRadius: BorderRadius.circular(16), onTap: onTap, child: GlassPanel(padding: const EdgeInsets.all(9), radius: 16, child: Icon(icon, size: 22)));
  }
}

class _GameLogo extends StatelessWidget {
  const _GameLogo();

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Stack(alignment: Alignment.center, children: [
        Text('دوئل', style: TextStyle(fontSize: 66, fontWeight: FontWeight.w900, letterSpacing: -3, foreground: Paint()..style = PaintingStyle.stroke..strokeWidth = 7..color = AppColors.cyan.withOpacity(.55))),
        ShaderMask(shaderCallback: (rect) => const LinearGradient(colors: [Colors.white, AppColors.cyan, AppColors.pink]).createShader(rect), child: const Text('دوئل', style: TextStyle(fontSize: 66, fontWeight: FontWeight.w900, letterSpacing: -3))),
      ]),
      Transform.translate(offset: const Offset(0, -14), child: Stack(alignment: Alignment.center, children: [
        Text('جواب', style: TextStyle(fontSize: 56, fontWeight: FontWeight.w900, letterSpacing: -3, foreground: Paint()..style = PaintingStyle.stroke..strokeWidth = 6..color = AppColors.pink.withOpacity(.52))),
        ShaderMask(shaderCallback: (rect) => const LinearGradient(colors: [Colors.white, AppColors.pink, AppColors.purple]).createShader(rect), child: const Text('جواب', style: TextStyle(fontSize: 56, fontWeight: FontWeight.w900, letterSpacing: -3))),
      ])),
    ]);
  }
}

class _FeaturedHomeCard extends StatelessWidget {
  const _FeaturedHomeCard();

  @override
  Widget build(BuildContext context) {
    return GlassPanel(
      radius: 28,
      padding: const EdgeInsets.all(14),
      borderColor: AppColors.cyan,
      gradient: LinearGradient(
        begin: Alignment.centerRight,
        end: Alignment.centerLeft,
        colors: [AppColors.cyan.withOpacity(.18), const Color(0xDD080F2E), AppColors.pink.withOpacity(.13)],
      ),
      shadows: [
        BoxShadow(color: AppColors.cyan.withOpacity(.20), blurRadius: 34, offset: const Offset(0, 14)),
        BoxShadow(color: AppColors.pink.withOpacity(.12), blurRadius: 30, offset: const Offset(-8, 12)),
      ],
      child: Row(children: [
        Stack(alignment: Alignment.center, children: [
          Container(width: 92, height: 78, decoration: BoxDecoration(borderRadius: BorderRadius.circular(22), gradient: RadialGradient(colors: [AppColors.gold.withOpacity(.28), AppColors.pink.withOpacity(.10), Colors.transparent]))),
          const PremiumTrophy(size: 64),
        ]),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: const [
            Expanded(child: Text('حالت کلاسیک', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: Colors.white))),
            PremiumGameIcon(icon: Icons.bolt_rounded, color: AppColors.cyan, size: 40, iconSize: 23, solid: true),
          ]),
          const SizedBox(height: 7),
          Text('۱۰ سؤال سریع، تایمر هیجانی، امتیاز بیشتر برای جواب سریع‌تر', style: TextStyle(fontSize: 12, color: Colors.white.withOpacity(.68), height: 1.55, fontWeight: FontWeight.w700)),
          const SizedBox(height: 10),
          Row(children: [
            _FeaturePill(icon: Icons.timer_rounded, text: '۷ ثانیه'),
            const SizedBox(width: 8),
            _FeaturePill(icon: Icons.local_fire_department_rounded, text: 'کمبو'),
          ]),
        ])),
      ]),
    );
  }
}

class _FeaturePill extends StatelessWidget {
  final IconData icon;
  final String text;
  const _FeaturePill({required this.icon, required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(999), color: Colors.white.withOpacity(.07), border: Border.all(color: Colors.white.withOpacity(.12))),
      child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(icon, size: 14, color: AppColors.gold), const SizedBox(width: 5), Text(text, style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.w800))]),
    );
  }
}

class _StatsStrip extends StatelessWidget {
  const _StatsStrip();

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<PlayerProfile>(
      valueListenable: RuntimeState.instance.player,
      builder: (_, player, __) => GlassPanel(
        radius: 26,
        padding: const EdgeInsets.all(14),
        borderColor: AppColors.purple,
        gradient: LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [Colors.white.withOpacity(.12), AppColors.cyan.withOpacity(.08), AppColors.pink.withOpacity(.08), Colors.white.withOpacity(.035)]),
        shadows: [BoxShadow(color: AppColors.purple.withOpacity(.18), blurRadius: 28, offset: const Offset(0, 14))],
        child: Row(children: [
          Expanded(child: _MiniStat(icon: Icons.speed_rounded, label: 'میانگین سرعت', value: '۱.۲ ثانیه', color: AppColors.cyan)),
          Container(width: 1, height: 58, color: Colors.white.withOpacity(.12)),
          Expanded(child: _MiniStat(icon: Icons.local_fire_department_rounded, label: 'برد امروز', value: '${player.streak}', color: AppColors.pink)),
          Container(width: 1, height: 58, color: Colors.white.withOpacity(.12)),
          Expanded(child: _MiniStat(icon: Icons.emoji_events_rounded, label: 'جام', value: '${player.trophy}', color: AppColors.gold)),
        ]),
      ),
    );
  }
}

class _MiniStat extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color color;
  const _MiniStat({required this.icon, required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Column(children: [PremiumGameIcon(icon: icon, color: color, size: 36, iconSize: 21, solid: true), const SizedBox(height: 8), Text(value, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)), Text(label, style: TextStyle(fontSize: 11, color: Colors.white.withOpacity(.62), fontWeight: FontWeight.w700))]);
  }
}

class _ModeCards extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Expanded(child: _ModeCard(mode: DuelMode.daily, icon: Icons.today_rounded, color: AppColors.gold, onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const MatchmakingScreen(mode: DuelMode.daily))))),
      const SizedBox(width: 12),
      Expanded(child: _ModeCard(mode: DuelMode.private, icon: Icons.lock_rounded, color: AppColors.pink, onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const PrivateRoomScreen())))),
    ]);
  }
}

class _ModeCard extends StatelessWidget {
  final DuelMode mode;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  const _ModeCard({required this.mode, required this.icon, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(24),
      onTap: onTap,
      child: GlassPanel(
        radius: 24,
        borderColor: color,
        padding: const EdgeInsets.all(14),
        gradient: LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [color.withOpacity(.20), Colors.white.withOpacity(.06), Colors.black.withOpacity(.08)]),
        shadows: [BoxShadow(color: color.withOpacity(.16), blurRadius: 24, offset: const Offset(0, 12))],
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [PremiumGameIcon(icon: icon, color: color, size: 40, iconSize: 23, solid: true), const Spacer(), Icon(Icons.chevron_left_rounded, color: Colors.white.withOpacity(.45))]),
          const SizedBox(height: 12),
          Text(mode.title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
          const SizedBox(height: 6),
          Text(mode.subtitle, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.white.withOpacity(.65), fontSize: 11, height: 1.5, fontWeight: FontWeight.w600)),
        ]),
      ),
    );
  }
}

class _LeaderboardPreview extends StatelessWidget {
  final VoidCallback onOpen;
  const _LeaderboardPreview({required this.onOpen});

  @override
  Widget build(BuildContext context) {
    return GlassPanel(
      padding: const EdgeInsets.all(14),
      child: Column(children: [
        Row(children: [const Expanded(child: Text('رتبه‌بندی', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900))), TextButton(onPressed: onOpen, child: const Text('مشاهده همه'))]),
        const SizedBox(height: 8),
        ...SampleData.leaderboard.take(3).toList().asMap().entries.map((entry) => _RankRow(index: entry.key + 1, data: entry.value)),
      ]),
    );
  }
}

class _RankRow extends StatelessWidget {
  final int index;
  final Map<String, Object> data;
  const _RankRow({required this.index, required this.data});

  @override
  Widget build(BuildContext context) {
    final color = index == 1 ? AppColors.gold : index == 2 ? Colors.blueGrey.shade100 : Colors.orangeAccent;
    return Container(
      margin: const EdgeInsets.only(bottom: 9),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(16), color: Colors.white.withOpacity(index == 1 ? .12 : .06), border: Border.all(color: color.withOpacity(.35))),
      child: Row(children: [
        Container(width: 30, height: 30, alignment: Alignment.center, decoration: BoxDecoration(shape: BoxShape.circle, color: color.withOpacity(.18), border: Border.all(color: color.withOpacity(.7))), child: Text('$index', style: TextStyle(color: color, fontWeight: FontWeight.w900))),
        const SizedBox(width: 10),
        Expanded(child: Text(data['name'].toString(), style: const TextStyle(fontWeight: FontWeight.w800))),
        Text(data['rank'].toString(), style: TextStyle(fontSize: 11, color: Colors.white.withOpacity(.56))),
        const SizedBox(width: 8),
        Text(_formatNumber(data['score'] as int), style: const TextStyle(color: AppColors.gold, fontWeight: FontWeight.w900)),
      ]),
    );
  }
}

class MatchmakingScreen extends StatefulWidget {
  final DuelMode mode;
  const MatchmakingScreen({required this.mode, super.key});

  @override
  State<MatchmakingScreen> createState() => _MatchmakingScreenState();
}

class _MatchmakingScreenState extends State<MatchmakingScreen> {
  Timer? _timer;
  int _phase = 0;
  int _countdown = 3;
  late final PlayerProfile opponent;

  @override
  void initState() {
    super.initState();
    opponent = SampleData.bots[Random().nextInt(SampleData.bots.length)];
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      setState(() {
        if (_phase < 3) {
          _phase++;
        } else if (_countdown > 1) {
          _countdown--;
        } else {
          _timer?.cancel();
          Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => GameScreen(mode: widget.mode, opponent: opponent)));
        }
      });
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final found = _phase >= 2;
    return Scaffold(
      body: NeonBackground(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(children: [
              _ScreenHeader(title: widget.mode.title, onBack: () => Navigator.of(context).pop()),
              const Spacer(),
              Text(found ? 'حریف پیدا شد!' : widget.mode == DuelMode.practice ? 'در حال آماده‌سازی تمرین...' : 'در حال پیدا کردن حریف...', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
              const SizedBox(height: 30),
              _VersusMatchCard(found: found, opponent: opponent),
              const SizedBox(height: 34),
              Text(found ? 'بازی شروع می‌شود' : 'در حال بررسی بازیکنان آنلاین', style: TextStyle(color: Colors.white.withOpacity(.72))),
              const SizedBox(height: 20),
              Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                _CountdownBox(label: found ? '$_countdown' : '3', active: found && _countdown == 3, color: AppColors.cyan),
                const SizedBox(width: 12),
                _CountdownBox(label: '2', active: found && _countdown == 2, color: AppColors.purple),
                const SizedBox(width: 12),
                _CountdownBox(label: '1', active: found && _countdown == 1, color: AppColors.pink),
              ]),
              const Spacer(),
              GlassPanel(padding: const EdgeInsets.all(13), child: Row(children: [const Icon(Icons.shield_rounded, color: AppColors.cyan), const SizedBox(width: 10), Expanded(child: Text('فعلاً حریف شبیه‌سازی شده است؛ ساختار صفحه برای اتصال نهایی به Socket.IO آماده است.', style: TextStyle(color: Colors.white.withOpacity(.72), fontSize: 12)))])),
            ]),
          ),
        ),
      ),
    );
  }
}

class _VersusMatchCard extends StatelessWidget {
  final bool found;
  final PlayerProfile opponent;
  const _VersusMatchCard({required this.found, required this.opponent});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<PlayerProfile>(
      valueListenable: RuntimeState.instance.player,
      builder: (_, player, __) => SizedBox(
        height: 310,
        child: Stack(alignment: Alignment.center, children: [
          Container(width: 270, height: 270, decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: AppColors.cyan.withOpacity(.25), width: 2), boxShadow: [BoxShadow(color: AppColors.cyan.withOpacity(.18), blurRadius: 55)])),
          Positioned(top: 8, child: _MatchPlayerCard(player: player, color: AppColors.cyan, isUnknown: false)),
          Positioned(bottom: 8, child: _MatchPlayerCard(player: opponent, color: AppColors.pink, isUnknown: !found)),
          ShaderMask(shaderCallback: (rect) => const LinearGradient(colors: [AppColors.cyan, Colors.white, AppColors.pink]).createShader(rect), child: const Text('VS', style: TextStyle(fontSize: 68, fontWeight: FontWeight.w900))),
        ]),
      ),
    );
  }
}

class _MatchPlayerCard extends StatelessWidget {
  final PlayerProfile player;
  final Color color;
  final bool isUnknown;
  const _MatchPlayerCard({required this.player, required this.color, required this.isUnknown});

  @override
  Widget build(BuildContext context) {
    return GlassPanel(
      radius: 24,
      borderColor: color,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      gradient: LinearGradient(colors: [color.withOpacity(.16), Colors.white.withOpacity(.05)]),
      child: SizedBox(width: 246, child: Row(children: [
        isUnknown ? Container(width: 56, height: 56, alignment: Alignment.center, decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withOpacity(.08), border: Border.all(color: color.withOpacity(.5))), child: const Text('؟', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900))) : PlayerAvatar(player: player, size: 56),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
          Text(isUnknown ? 'حریف در حال جستجو' : player.name, style: const TextStyle(fontWeight: FontWeight.w900)),
          const SizedBox(height: 6),
          Text(isUnknown ? 'در حال بررسی...' : '${player.rank}  •  ${player.trophy}', style: TextStyle(fontSize: 12, color: Colors.white.withOpacity(.65))),
        ])),
      ])),
    );
  }
}

class _CountdownBox extends StatelessWidget {
  final String label;
  final bool active;
  final Color color;
  const _CountdownBox({required this.label, required this.active, required this.color});

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(duration: const Duration(milliseconds: 220), width: active ? 68 : 58, height: active ? 68 : 58, alignment: Alignment.center, decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), gradient: LinearGradient(colors: [color.withOpacity(active ? .9 : .28), color.withOpacity(.08)]), border: Border.all(color: color.withOpacity(active ? .95 : .35), width: 1.4), boxShadow: active ? [BoxShadow(color: color.withOpacity(.45), blurRadius: 26)] : null), child: Text(label, style: TextStyle(fontSize: active ? 32 : 25, fontWeight: FontWeight.w900)));
  }
}

class GameScreen extends StatefulWidget {
  final DuelMode mode;
  final PlayerProfile opponent;
  const GameScreen({required this.mode, required this.opponent, super.key});

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> {
  static const int secondsPerQuestion = 7;
  final _random = Random();
  late final List<DuelQuestion> questions;
  Timer? _questionTimer;
  Timer? _opponentTimer;
  DateTime _questionStartedAt = DateTime.now();

  int _questionIndex = 0;
  int _secondsLeft = secondsPerQuestion;
  int _playerScore = 0;
  int _opponentScore = 0;
  int _combo = 0;
  int _maxCombo = 0;
  int _correct = 0;
  int _wrong = 0;
  int _fastestMs = 999999;
  int _extraTime = 1;
  int _shield = 1;
  int _doubleScore = 1;
  bool _shieldActive = false;
  bool _doubleActive = false;
  bool _answered = false;
  bool? _lastWasCorrect;
  String? _feedbackText;
  bool _opponentAnswered = false;

  DuelQuestion get _question => questions[_questionIndex];

  @override
  void initState() {
    super.initState();
    questions = _buildQuestions();
    _startQuestion();
  }

  List<DuelQuestion> _buildQuestions() {
    final list = [...SampleData.questions]..shuffle(_random);
    if (widget.mode == DuelMode.daily) return list.where((q) => q.difficulty <= 2).take(10).toList();
    if (widget.mode == DuelMode.practice) return list.take(8).toList();
    return list.take(10).toList();
  }

  @override
  void dispose() {
    _questionTimer?.cancel();
    _opponentTimer?.cancel();
    super.dispose();
  }

  void _startQuestion() {
    _questionTimer?.cancel();
    _opponentTimer?.cancel();
    setState(() {
      _secondsLeft = secondsPerQuestion;
      _answered = false;
      _lastWasCorrect = null;
      _feedbackText = null;
      _opponentAnswered = false;
      _questionStartedAt = DateTime.now();
    });
    final opponentDelay = Duration(milliseconds: 1200 + _random.nextInt(4300));
    _opponentTimer = Timer(opponentDelay, _simulateOpponentAnswer);
    _questionTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) return;
      if (_secondsLeft <= 1) {
        timer.cancel();
        if (!_answered) {
          setState(() {
            _combo = 0;
            _wrong++;
            _lastWasCorrect = false;
            _feedbackText = 'زمان تمام شد';
          });
        }
        Future.delayed(const Duration(milliseconds: 650), _goNextQuestion);
      } else {
        setState(() => _secondsLeft--);
      }
    });
  }

  void _simulateOpponentAnswer() {
    if (!mounted || _opponentAnswered) return;
    final accuracy = widget.mode == DuelMode.practice ? .55 : .72;
    final isCorrect = _random.nextDouble() < accuracy;
    final speedBonus = max(0, _secondsLeft * 5);
    setState(() {
      _opponentAnswered = true;
      if (isCorrect) _opponentScore += 70 + speedBonus + (widget.mode == DuelMode.ranked ? 12 : 0);
    });
  }

  void _submitAnswer(bool value) {
    if (_answered) return;
    final responseMs = DateTime.now().difference(_questionStartedAt).inMilliseconds;
    final isCorrect = value == _question.answer;
    final speedBonus = max(0, _secondsLeft * 6);
    setState(() {
      _answered = true;
      _lastWasCorrect = isCorrect;
      if (isCorrect) {
        _combo++;
        _correct++;
        _maxCombo = max(_maxCombo, _combo);
        _fastestMs = min(_fastestMs, responseMs);
        final multiplier = _doubleActive ? 2 : 1;
        _playerScore += (100 + speedBonus + (_combo >= 3 ? 50 : 0)) * multiplier;
        _feedbackText = _doubleActive ? 'درست! ضریب دو برابر فعال شد' : 'درست! + امتیاز سرعت';
        _doubleActive = false;
      } else {
        _combo = 0;
        _wrong++;
        if (_shieldActive) {
          _feedbackText = 'سپر خطا مصرف شد؛ جریمه نشدی';
          _shieldActive = false;
        } else {
          _playerScore = max(0, _playerScore - 40);
          _feedbackText = 'غلط! -۴۰ امتیاز';
        }
      }
    });
    Future.delayed(const Duration(milliseconds: 850), _goNextQuestion);
  }

  void _useExtraTime() {
    if (_answered || _extraTime <= 0) return;
    setState(() {
      _extraTime--;
      _secondsLeft = min(12, _secondsLeft + 3);
    });
  }

  void _useShield() {
    if (_answered || _shield <= 0 || _shieldActive) return;
    setState(() {
      _shield--;
      _shieldActive = true;
    });
  }

  void _useDoubleScore() {
    if (_answered || _doubleScore <= 0 || _doubleActive) return;
    setState(() {
      _doubleScore--;
      _doubleActive = true;
    });
  }

  void _goNextQuestion() {
    if (!mounted) return;
    _questionTimer?.cancel();
    _opponentTimer?.cancel();
    if (_questionIndex >= questions.length - 1) {
      final won = _playerScore >= _opponentScore;
      final stats = GameStats(
        playerScore: _playerScore,
        opponentScore: _opponentScore,
        correctAnswers: _correct,
        wrongAnswers: _wrong,
        maxCombo: _maxCombo,
        fastestMs: _fastestMs == 999999 ? 0 : _fastestMs,
        coins: widget.mode == DuelMode.practice ? 0 : (won ? 200 : 60),
        xp: 90 + (_correct * 12),
        trophyChange: widget.mode == DuelMode.practice ? 0 : (won ? 28 : -14),
        mode: widget.mode,
        player: RuntimeState.instance.player.value,
        opponent: widget.opponent,
      );
      RuntimeState.instance.applyMatch(stats);
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => ResultScreen(stats: stats)));
      return;
    }
    setState(() => _questionIndex++);
    _startQuestion();
  }

  @override
  Widget build(BuildContext context) {
    final progress = (_questionIndex + 1) / questions.length;
    return Scaffold(
      body: NeonBackground(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 14),
            child: Column(children: [
              Row(children: [
                Expanded(child: ValueListenableBuilder<PlayerProfile>(valueListenable: RuntimeState.instance.player, builder: (_, player, __) => PlayerScoreCard(player: player, score: _playerScore, alignRight: true))),
                Padding(padding: const EdgeInsets.symmetric(horizontal: 8), child: ShaderMask(shaderCallback: (rect) => const LinearGradient(colors: [AppColors.cyan, Colors.white, AppColors.pink]).createShader(rect), child: const Text('VS', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 20)))),
                Expanded(child: PlayerScoreCard(player: widget.opponent, score: _opponentScore, alignRight: false)),
              ]),
              const SizedBox(height: 14),
              Row(children: [Expanded(child: ClipRRect(borderRadius: BorderRadius.circular(12), child: LinearProgressIndicator(value: progress, minHeight: 9, backgroundColor: Colors.white.withOpacity(.1), valueColor: const AlwaysStoppedAnimation<Color>(AppColors.cyan)))), const SizedBox(width: 10), Text('سوال ${_questionIndex + 1} از ${questions.length}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12))]),
              const SizedBox(height: 14),
              Row(children: [_GameChip(icon: Icons.flash_on_rounded, label: 'کمبو x$_combo', color: AppColors.gold), const SizedBox(width: 8), if (_shieldActive) _GameChip(icon: Icons.shield_rounded, label: 'سپر فعال', color: AppColors.green), if (_doubleActive) ...[const SizedBox(width: 8), _GameChip(icon: Icons.bolt_rounded, label: 'ضریب ۲x', color: AppColors.orange)], const Spacer(), _GameChip(icon: Icons.category_rounded, label: _question.category, color: AppColors.purple)]),
              const SizedBox(height: 12),
              TimerRing(secondsLeft: _secondsLeft, totalSeconds: 12),
              const SizedBox(height: 18),
              Expanded(
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  PremiumQuestionCard(question: _question),
                  const SizedBox(height: 20),
                  Row(children: [Expanded(child: AnswerButton(label: 'بله', color: AppColors.green, onTap: () => _submitAnswer(true), disabled: _answered)), const SizedBox(width: 12), Expanded(child: AnswerButton(label: 'نه', color: AppColors.red, onTap: () => _submitAnswer(false), disabled: _answered))]),
                  const SizedBox(height: 14),
                  AnimatedSwitcher(duration: const Duration(milliseconds: 220), child: _lastWasCorrect == null ? const SizedBox(height: 62) : FeedbackPanel(isCorrect: _lastWasCorrect!, text: _feedbackText ?? '')),
                ]),
              ),
              Row(children: [
                Expanded(child: PowerUpTile(icon: Icons.timer_rounded, title: 'زمان بیشتر', count: _extraTime, active: _extraTime > 0, onTap: _useExtraTime)),
                const SizedBox(width: 10),
                Expanded(child: PowerUpTile(icon: Icons.shield_rounded, title: 'سپر خطا', count: _shield, active: _shield > 0 || _shieldActive, onTap: _useShield)),
                const SizedBox(width: 10),
                Expanded(child: PowerUpTile(icon: Icons.bolt_rounded, title: 'ضریب ۲x', count: _doubleScore, active: _doubleScore > 0 || _doubleActive, onTap: _useDoubleScore)),
              ]),
            ]),
          ),
        ),
      ),
    );
  }
}

class PlayerScoreCard extends StatelessWidget {
  final PlayerProfile player;
  final int score;
  final bool alignRight;
  const PlayerScoreCard({required this.player, required this.score, required this.alignRight, super.key});

  @override
  Widget build(BuildContext context) {
    return GlassPanel(
      radius: 22,
      padding: const EdgeInsets.all(10),
      borderColor: player.color,
      gradient: LinearGradient(colors: [player.color.withOpacity(.20), Colors.white.withOpacity(.04)]),
      child: Row(textDirection: alignRight ? TextDirection.rtl : TextDirection.ltr, children: [
        PlayerAvatar(player: player, size: 44),
        const SizedBox(width: 8),
        Expanded(child: Column(crossAxisAlignment: alignRight ? CrossAxisAlignment.start : CrossAxisAlignment.end, mainAxisSize: MainAxisSize.min, children: [
          Text(player.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          Text('$score', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: player.color)),
        ])),
      ]),
    );
  }
}

class _GameChip extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  const _GameChip({required this.icon, required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return GlassPanel(radius: 18, padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6), borderColor: color, gradient: LinearGradient(colors: [color.withOpacity(.14), Colors.white.withOpacity(.04)]), child: Row(mainAxisSize: MainAxisSize.min, children: [PremiumGameIcon(icon: icon, color: color, size: 26, iconSize: 15, solid: true), const SizedBox(width: 6), Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w900))]));
  }
}

class TimerRing extends StatelessWidget {
  final int secondsLeft;
  final int totalSeconds;
  const TimerRing({required this.secondsLeft, required this.totalSeconds, super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(width: 122, height: 122, child: Stack(alignment: Alignment.center, children: [
      CustomPaint(size: const Size(122, 122), painter: _TimerRingPainter(progress: secondsLeft / totalSeconds)),
      Column(mainAxisSize: MainAxisSize.min, children: [Text('$secondsLeft'.padLeft(2, '0'), style: const TextStyle(fontSize: 35, fontWeight: FontWeight.w900)), Text('ثانیه', style: TextStyle(fontSize: 12, color: Colors.white.withOpacity(.62)))]),
    ]));
  }
}

class _TimerRingPainter extends CustomPainter {
  final double progress;
  const _TimerRingPainter({required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    final center = size.center(Offset.zero);
    final rect = Rect.fromCircle(center: center, radius: size.width / 2 - 8);
    final base = Paint()..style = PaintingStyle.stroke..strokeWidth = 10..strokeCap = StrokeCap.round..color = Colors.white.withOpacity(.10);
    canvas.drawArc(rect, -pi / 2, pi * 2, false, base);
    final paint = Paint()..style = PaintingStyle.stroke..strokeWidth = 10..strokeCap = StrokeCap.round..shader = const SweepGradient(colors: [AppColors.cyan, AppColors.purple, AppColors.pink, AppColors.cyan]).createShader(rect);
    canvas.drawArc(rect, -pi / 2, pi * 2 * progress.clamp(0, 1), false, paint);
  }

  @override
  bool shouldRepaint(covariant _TimerRingPainter oldDelegate) => oldDelegate.progress != progress;
}


class PremiumQuestionCard extends StatelessWidget {
  final DuelQuestion question;
  const PremiumQuestionCard({required this.question, super.key});

  @override
  Widget build(BuildContext context) {
    return Stack(
      clipBehavior: Clip.none,
      alignment: Alignment.center,
      children: [
        GlassPanel(
          radius: 30,
          borderColor: AppColors.cyan,
          padding: const EdgeInsets.fromLTRB(18, 28, 18, 30),
          gradient: LinearGradient(
            begin: Alignment.topRight,
            end: Alignment.bottomLeft,
            colors: [AppColors.cyan.withOpacity(.18), const Color(0xE6081232), AppColors.pink.withOpacity(.13)],
          ),
          shadows: [
            BoxShadow(color: AppColors.cyan.withOpacity(.26), blurRadius: 34, offset: const Offset(0, 14)),
            BoxShadow(color: AppColors.pink.withOpacity(.18), blurRadius: 28, offset: const Offset(-10, 12)),
          ],
          child: Column(children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(999),
                color: Colors.white.withOpacity(.06),
                border: Border.all(color: Colors.white.withOpacity(.16)),
              ),
              child: Text(question.type, style: TextStyle(color: Colors.white.withOpacity(.78), fontWeight: FontWeight.w900, fontSize: 12)),
            ),
            const SizedBox(height: 18),
            Text(question.text, textAlign: TextAlign.center, style: const TextStyle(fontSize: 29, height: 1.55, fontWeight: FontWeight.w900, shadows: [Shadow(color: AppColors.cyan, blurRadius: 10)])),
            const SizedBox(height: 14),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              PremiumGameIcon(icon: Icons.category_rounded, color: AppColors.purple, size: 30, iconSize: 17, solid: true),
              const SizedBox(width: 7),
              Text(question.category, style: TextStyle(color: Colors.white.withOpacity(.58), fontSize: 12, fontWeight: FontWeight.w800)),
            ]),
          ]),
        ),
        Positioned(
          bottom: -9,
          child: Transform.rotate(
            angle: pi / 4,
            child: Container(
              width: 22,
              height: 22,
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [AppColors.pink, AppColors.cyan]),
                borderRadius: BorderRadius.circular(6),
                boxShadow: [BoxShadow(color: AppColors.cyan.withOpacity(.42), blurRadius: 16)],
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class AnswerButton extends StatelessWidget {
  final String label;
  final Color color;
  final VoidCallback onTap;
  final bool disabled;
  const AnswerButton({required this.label, required this.color, required this.onTap, this.disabled = false, super.key});

  @override
  Widget build(BuildContext context) {
    return InkWell(borderRadius: BorderRadius.circular(24), onTap: disabled ? null : onTap, child: AnimatedOpacity(duration: const Duration(milliseconds: 160), opacity: disabled ? .65 : 1, child: Container(height: 72, alignment: Alignment.center, decoration: BoxDecoration(borderRadius: BorderRadius.circular(24), gradient: LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [Colors.white.withOpacity(.18), color.withOpacity(.98), color.withOpacity(.52)]), border: Border.all(color: Colors.white.withOpacity(.38), width: 1.5), boxShadow: [BoxShadow(color: color.withOpacity(.48), blurRadius: 28, offset: const Offset(0, 12)), BoxShadow(color: Colors.black.withOpacity(.28), blurRadius: 18, offset: const Offset(0, 10))]), child: Text(label, style: TextStyle(fontSize: 25, color: Colors.white, fontWeight: FontWeight.w900, shadows: [Shadow(color: color.withOpacity(.8), blurRadius: 10)])))));
  }
}

class FeedbackPanel extends StatelessWidget {
  final bool isCorrect;
  final String text;
  const FeedbackPanel({required this.isCorrect, required this.text, super.key});

  @override
  Widget build(BuildContext context) {
    final color = isCorrect ? AppColors.green : AppColors.red;
    return GlassPanel(key: ValueKey('$isCorrect$text'), radius: 20, borderColor: color, padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10), gradient: LinearGradient(colors: [color.withOpacity(.18), Colors.white.withOpacity(.04)]), child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
      PremiumGameIcon(icon: isCorrect ? Icons.check_rounded : Icons.close_rounded, color: color, size: 34, iconSize: 20, solid: true),
      const SizedBox(width: 10),
      Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [Text(isCorrect ? 'درست!' : 'غلط!', style: TextStyle(fontWeight: FontWeight.w900, color: color, fontSize: 18)), Text(text, style: TextStyle(fontSize: 12, color: Colors.white.withOpacity(.65)))]),
    ]));
  }
}

class PowerUpTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final int count;
  final bool active;
  final VoidCallback onTap;
  const PowerUpTile({required this.icon, required this.title, required this.count, required this.active, required this.onTap, super.key});

  @override
  Widget build(BuildContext context) {
    final color = active ? AppColors.cyan : Colors.blueGrey;
    return InkWell(
      borderRadius: BorderRadius.circular(20),
      onTap: active ? onTap : null,
      child: AnimatedOpacity(
        duration: const Duration(milliseconds: 180),
        opacity: active ? 1 : .45,
        child: GlassPanel(radius: 22, padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8), borderColor: color, gradient: LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [color.withOpacity(.16), Colors.white.withOpacity(.055), Colors.black.withOpacity(.08)]), shadows: [BoxShadow(color: color.withOpacity(active ? .16 : .04), blurRadius: 20, offset: const Offset(0, 10))], child: Column(children: [
          PremiumGameIcon(icon: icon, color: color, size: 42, iconSize: 24, badge: '$count', solid: active),
          const SizedBox(height: 8),
          Text(title, textAlign: TextAlign.center, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w900)),
        ])),
      ),
    );
  }
}

class PremiumTrophy extends StatelessWidget {
  final double size;
  final bool winner;
  const PremiumTrophy({this.size = 86, this.winner = true, super.key});

  @override
  Widget build(BuildContext context) {
    final trophyColor = winner ? AppColors.gold : AppColors.pink;
    return SizedBox(width: size * 1.28, height: size * 1.08, child: Stack(alignment: Alignment.center, children: [
      Positioned.fill(child: DecoratedBox(decoration: BoxDecoration(shape: BoxShape.circle, boxShadow: [BoxShadow(color: trophyColor.withOpacity(.48), blurRadius: size * .46, spreadRadius: size * .04), BoxShadow(color: AppColors.cyan.withOpacity(.18), blurRadius: size * .34, spreadRadius: size * .02)]))),
      CustomPaint(size: Size(size * 1.10, size), painter: _PremiumTrophyPainter(color: trophyColor, winner: winner)),
      Positioned(top: size * .04, right: size * .23, child: _Spark(size: size * .12, color: Colors.white.withOpacity(.95))),
      Positioned(top: size * .21, left: size * .16, child: _Spark(size: size * .09, color: trophyColor.withOpacity(.95))),
    ]));
  }
}

class _Spark extends StatelessWidget {
  final double size;
  final Color color;
  const _Spark({required this.size, required this.color});

  @override
  Widget build(BuildContext context) {
    return Transform.rotate(angle: pi / 4, child: Container(width: size, height: size, decoration: BoxDecoration(gradient: RadialGradient(colors: [color, color.withOpacity(.08)]), borderRadius: BorderRadius.circular(3))));
  }
}

class _PremiumTrophyPainter extends CustomPainter {
  final Color color;
  final bool winner;
  const _PremiumTrophyPainter({required this.color, required this.winner});

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final center = Offset(w / 2, h / 2);
    final shadow = Paint()..color = Colors.black.withOpacity(.35)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10);
    final rimRect = Rect.fromCenter(center: Offset(center.dx, h * .20), width: w * .48, height: h * .12);
    final cupPath = Path()..moveTo(w * .25, h * .22)..cubicTo(w * .28, h * .48, w * .36, h * .61, w * .50, h * .63)..cubicTo(w * .64, h * .61, w * .72, h * .48, w * .75, h * .22)..close();
    final bodyGradient = LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: winner ? const [Color(0xFFFFF3A0), Color(0xFFFFC857), Color(0xFFC87400), Color(0xFFFFDF73)] : const [Color(0xFFFFB0DC), Color(0xFFFF3FA4), Color(0xFF9F185D), Color(0xFFFF8FCC)], stops: const [.02, .38, .72, 1]);
    canvas.drawPath(cupPath.shift(const Offset(0, 6)), shadow);
    canvas.drawPath(cupPath, Paint()..shader = bodyGradient.createShader(Rect.fromLTWH(0, 0, w, h)));
    canvas.drawOval(rimRect, Paint()..shader = bodyGradient.createShader(rimRect));
    canvas.drawOval(rimRect.deflate(1), Paint()..style = PaintingStyle.stroke..strokeWidth = 2.2..color = Colors.white.withOpacity(.55));
    final handlePaint = Paint()..style = PaintingStyle.stroke..strokeWidth = w * .055..strokeCap = StrokeCap.round..shader = bodyGradient.createShader(Rect.fromLTWH(0, h * .18, w, h * .34));
    canvas.drawPath(Path()..moveTo(w * .27, h * .29)..cubicTo(w * .08, h * .28, w * .11, h * .55, w * .33, h * .50), handlePaint);
    canvas.drawPath(Path()..moveTo(w * .73, h * .29)..cubicTo(w * .92, h * .28, w * .89, h * .55, w * .67, h * .50), handlePaint);
    final stemRect = RRect.fromRectAndRadius(Rect.fromCenter(center: Offset(center.dx, h * .72), width: w * .20, height: h * .20), Radius.circular(w * .05));
    canvas.drawRRect(stemRect, Paint()..shader = bodyGradient.createShader(stemRect.outerRect));
    final baseRect = RRect.fromRectAndRadius(Rect.fromCenter(center: Offset(center.dx, h * .86), width: w * .55, height: h * .15), Radius.circular(w * .07));
    canvas.drawRRect(baseRect.shift(const Offset(0, 5)), shadow);
    canvas.drawRRect(baseRect, Paint()..shader = const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF30225E), Color(0xFF0A102B), Color(0xFF6A4BFF)]).createShader(baseRect.outerRect));
    canvas.drawRRect(baseRect, Paint()..style = PaintingStyle.stroke..strokeWidth = 1.4..color = color.withOpacity(.72));
    final plateRect = RRect.fromRectAndRadius(Rect.fromCenter(center: Offset(center.dx, h * .86), width: w * .30, height: h * .062), Radius.circular(w * .03));
    canvas.drawRRect(plateRect, Paint()..color = color.withOpacity(.92));
    final shinePaint = Paint()..style = PaintingStyle.stroke..strokeCap = StrokeCap.round..strokeWidth = 2.3..color = Colors.white.withOpacity(.58);
    canvas.drawLine(Offset(w * .39, h * .27), Offset(w * .34, h * .50), shinePaint);
    canvas.drawLine(Offset(w * .49, h * .21), Offset(w * .61, h * .21), Paint()..style = PaintingStyle.stroke..strokeCap = StrokeCap.round..strokeWidth = 1.6..color = Colors.white.withOpacity(.58));
  }

  @override
  bool shouldRepaint(covariant _PremiumTrophyPainter oldDelegate) => oldDelegate.color != color || oldDelegate.winner != winner;
}

class ResultScreen extends StatelessWidget {
  final GameStats stats;
  const ResultScreen({required this.stats, super.key});

  @override
  Widget build(BuildContext context) {
    final title = stats.isWinner ? 'شما برنده شدید!' : 'باختی، ولی نزدیک بود!';
    final color = stats.isWinner ? AppColors.gold : AppColors.pink;
    return Scaffold(
      body: NeonBackground(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(children: [
              const SizedBox(height: 16),
              PremiumTrophy(size: 92, winner: stats.isWinner),
              const SizedBox(height: 10),
              Text(title, textAlign: TextAlign.center, style: TextStyle(fontSize: 31, fontWeight: FontWeight.w900, color: color)),
              const SizedBox(height: 10),
              Text(stats.mode.title, style: TextStyle(color: Colors.white.withOpacity(.65))),
              const SizedBox(height: 22),
              GlassPanel(radius: 30, padding: const EdgeInsets.all(18), borderColor: color, child: Column(children: [
                Row(children: [
                  Expanded(child: _ResultPlayer(player: stats.player, score: stats.playerScore, color: AppColors.cyan)),
                  Column(children: [const PremiumTrophy(size: 56), Text('VS', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: Colors.white.withOpacity(.9)))]),
                  Expanded(child: _ResultPlayer(player: stats.opponent, score: stats.opponentScore, color: AppColors.pink)),
                ]),
                const SizedBox(height: 18),
                Row(children: [
                  Expanded(child: _RewardTile(icon: Icons.monetization_on_rounded, value: '+${stats.coins}', label: 'سکه', color: AppColors.gold)),
                  const SizedBox(width: 10),
                  Expanded(child: _RewardTile(icon: Icons.hexagon_rounded, value: '+${stats.xp}', label: 'XP', color: AppColors.cyan)),
                  const SizedBox(width: 10),
                  Expanded(child: _RewardTile(icon: stats.trophyChange >= 0 ? Icons.trending_up_rounded : Icons.trending_down_rounded, value: '${stats.trophyChange}', label: 'جام', color: stats.trophyChange >= 0 ? AppColors.green : AppColors.red)),
                ]),
              ])),
              const SizedBox(height: 14),
              GlassPanel(padding: const EdgeInsets.all(14), radius: 24, child: Row(children: [
                Expanded(child: _MiniStat(icon: Icons.check_circle_rounded, label: 'درست', value: '${stats.correctAnswers}', color: AppColors.green)),
                Container(width: 1, height: 44, color: Colors.white.withOpacity(.12)),
                Expanded(child: _MiniStat(icon: Icons.flash_on_rounded, label: 'بهترین کمبو', value: '${stats.maxCombo}', color: AppColors.gold)),
                Container(width: 1, height: 44, color: Colors.white.withOpacity(.12)),
                Expanded(child: _MiniStat(icon: Icons.speed_rounded, label: 'سریع‌ترین', value: stats.fastestMs == 0 ? '-' : '${(stats.fastestMs / 1000).toStringAsFixed(1)}ث', color: AppColors.cyan)),
              ])),
              const Spacer(),
              NeonButton(label: 'بازی دوباره', icon: Icons.restart_alt_rounded, onTap: () => Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => MatchmakingScreen(mode: stats.mode)))),
              const SizedBox(height: 12),
              NeonButton(label: 'بازگشت به خانه', icon: Icons.home_rounded, color: Colors.blueGrey, compact: true, onTap: () => Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const ShellScreen()), (_) => false)),
            ]),
          ),
        ),
      ),
    );
  }
}

class _ResultPlayer extends StatelessWidget {
  final PlayerProfile player;
  final int score;
  final Color color;
  const _ResultPlayer({required this.player, required this.score, required this.color});

  @override
  Widget build(BuildContext context) {
    return Column(children: [PlayerAvatar(player: player, size: 68), const SizedBox(height: 10), Text(player.name, textAlign: TextAlign.center, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w900)), const SizedBox(height: 7), Text('$score', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: color))]);
  }
}

class _RewardTile extends StatelessWidget {
  final IconData icon;
  final String value;
  final String label;
  final Color color;
  const _RewardTile({required this.icon, required this.value, required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8), decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), color: Colors.white.withOpacity(.06), border: Border.all(color: color.withOpacity(.35))), child: Column(children: [Icon(icon, color: color, size: 30), const SizedBox(height: 8), Text(value, style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18, color: color)), Text(label, style: TextStyle(fontSize: 11, color: Colors.white.withOpacity(.63)))]));
  }
}

class StoreScreen extends StatelessWidget {
  const StoreScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(key: const ValueKey('store'), physics: const BouncingScrollPhysics(), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const _SectionHeader(title: 'فروشگاه', subtitle: 'پاورآپ و آیتم‌های ویژه'),
      const SizedBox(height: 16),
      ValueListenableBuilder<PlayerProfile>(valueListenable: RuntimeState.instance.player, builder: (_, player, __) => GlassPanel(borderColor: AppColors.gold, child: Row(children: [const Icon(Icons.monetization_on_rounded, color: AppColors.gold, size: 42), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('موجودی سکه', style: TextStyle(fontWeight: FontWeight.w900)), Text('${_formatNumber(player.coins)} سکه برای خرید آیتم داری', style: TextStyle(color: Colors.white.withOpacity(.62), fontSize: 12))])), Text(_formatNumber(player.coins), style: const TextStyle(color: AppColors.gold, fontWeight: FontWeight.w900, fontSize: 20))]))),
      const SizedBox(height: 14),
      ...SampleData.store.map((item) => Padding(padding: const EdgeInsets.only(bottom: 12), child: _StoreItemCard(item: item))),
    ]));
  }
}

class _StoreItemCard extends StatelessWidget {
  final StoreItem item;
  const _StoreItemCard({required this.item});

  @override
  Widget build(BuildContext context) {
    return GlassPanel(radius: 24, borderColor: item.color, gradient: LinearGradient(colors: [item.color.withOpacity(.13), Colors.white.withOpacity(.04)]), child: Row(children: [
      Container(width: 54, height: 54, decoration: BoxDecoration(shape: BoxShape.circle, color: item.color.withOpacity(.15), border: Border.all(color: item.color.withOpacity(.45))), child: Icon(item.icon, color: item.color, size: 30)),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(item.title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)), const SizedBox(height: 5), Text(item.description, style: TextStyle(color: Colors.white.withOpacity(.62), fontSize: 12))])),
      Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9), decoration: BoxDecoration(borderRadius: BorderRadius.circular(15), color: item.color.withOpacity(.16), border: Border.all(color: item.color.withOpacity(.4))), child: Row(children: [const Icon(Icons.monetization_on_rounded, color: AppColors.gold, size: 16), const SizedBox(width: 4), Text('${item.price}', style: const TextStyle(fontWeight: FontWeight.w900))])),
    ]));
  }
}

class MissionsScreen extends StatelessWidget {
  const MissionsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(key: const ValueKey('missions'), physics: const BouncingScrollPhysics(), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const _SectionHeader(title: 'ماموریت‌ها', subtitle: 'چالش‌های روزانه برای افزایش سکه و XP'),
      const SizedBox(height: 16),
      ...SampleData.missions.map((m) => Padding(padding: const EdgeInsets.only(bottom: 12), child: _MissionCard(mission: m))),
    ]));
  }
}

class _MissionCard extends StatelessWidget {
  final Mission mission;
  const _MissionCard({required this.mission});

  @override
  Widget build(BuildContext context) {
    final progress = mission.progress / mission.target;
    return GlassPanel(radius: 24, borderColor: mission.color, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [Icon(mission.icon, color: mission.color, size: 34), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(mission.title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)), Text(mission.description, style: TextStyle(color: Colors.white.withOpacity(.62), fontSize: 12))])), Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7), decoration: BoxDecoration(borderRadius: BorderRadius.circular(14), color: AppColors.gold.withOpacity(.13)), child: Text('+${mission.reward}', style: const TextStyle(color: AppColors.gold, fontWeight: FontWeight.w900)))]),
      const SizedBox(height: 14),
      ClipRRect(borderRadius: BorderRadius.circular(20), child: LinearProgressIndicator(value: progress, minHeight: 10, backgroundColor: Colors.white.withOpacity(.10), valueColor: AlwaysStoppedAnimation<Color>(mission.color))),
      const SizedBox(height: 8),
      Text('${mission.progress} از ${mission.target}', style: TextStyle(color: Colors.white.withOpacity(.55), fontSize: 12)),
    ]));
  }
}

class FriendsScreen extends StatelessWidget {
  const FriendsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(key: const ValueKey('friends'), physics: const BouncingScrollPhysics(), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const _SectionHeader(title: 'دوستان', subtitle: 'دعوت، رقابت خصوصی و وضعیت آنلاین'),
      const SizedBox(height: 16),
      NeonButton(label: 'دعوت با لینک', icon: Icons.link_rounded, compact: true, color: AppColors.pink, onTap: () {}),
      const SizedBox(height: 14),
      ...SampleData.bots.map((bot) => Padding(padding: const EdgeInsets.only(bottom: 12), child: _FriendCard(player: bot))),
    ]));
  }
}

class _FriendCard extends StatelessWidget {
  final PlayerProfile player;
  const _FriendCard({required this.player});

  @override
  Widget build(BuildContext context) {
    return GlassPanel(radius: 24, borderColor: player.color, child: Row(children: [
      PlayerAvatar(player: player, size: 54),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(player.name, style: const TextStyle(fontWeight: FontWeight.w900)), const SizedBox(height: 5), Text('${player.rank} • ${player.trophy} جام', style: TextStyle(color: Colors.white.withOpacity(.62), fontSize: 12))])),
      IconButton(onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => GameScreen(mode: DuelMode.private, opponent: player))), icon: const Icon(Icons.sports_esports_rounded, color: AppColors.cyan)),
    ]));
  }
}

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<PlayerProfile>(valueListenable: RuntimeState.instance.player, builder: (_, player, __) {
      final total = player.wins + player.losses;
      final winRate = total == 0 ? 0 : ((player.wins / total) * 100).round();
      return SingleChildScrollView(key: const ValueKey('profile'), physics: const BouncingScrollPhysics(), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const _SectionHeader(title: 'پروفایل', subtitle: 'آمار رقابتی و پیشرفت کاربر'),
        const SizedBox(height: 16),
        GlassPanel(radius: 30, borderColor: player.color, child: Column(children: [
          PlayerAvatar(player: player, size: 86),
          const SizedBox(height: 12),
          Text(player.name, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900)),
          const SizedBox(height: 6),
          Text(player.rank, style: TextStyle(color: Colors.white.withOpacity(.62))),
          const SizedBox(height: 18),
          Row(children: [Expanded(child: _MiniStat(icon: Icons.emoji_events_rounded, label: 'جام', value: '${player.trophy}', color: AppColors.gold)), Expanded(child: _MiniStat(icon: Icons.workspace_premium_rounded, label: 'برد', value: '${player.wins}', color: AppColors.green)), Expanded(child: _MiniStat(icon: Icons.percent_rounded, label: 'برد٪', value: '$winRate٪', color: AppColors.cyan))]),
        ])),
        const SizedBox(height: 14),
        const Text('آخرین مسابقات', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
        const SizedBox(height: 10),
        ValueListenableBuilder<List<GameStats>>(valueListenable: RuntimeState.instance.history, builder: (_, history, __) {
          if (history.isEmpty) return GlassPanel(child: Text('هنوز مسابقه‌ای انجام ندادی.', style: TextStyle(color: Colors.white.withOpacity(.65))));
          return Column(children: history.take(5).map((s) => Padding(padding: const EdgeInsets.only(bottom: 10), child: _HistoryRow(stats: s))).toList());
        }),
      ]));
    });
  }
}

class _HistoryRow extends StatelessWidget {
  final GameStats stats;
  const _HistoryRow({required this.stats});

  @override
  Widget build(BuildContext context) {
    final color = stats.isWinner ? AppColors.green : AppColors.red;
    return GlassPanel(radius: 20, padding: const EdgeInsets.all(12), borderColor: color, child: Row(children: [Icon(stats.isWinner ? Icons.check_circle_rounded : Icons.cancel_rounded, color: color), const SizedBox(width: 10), Expanded(child: Text('${stats.mode.title} مقابل ${stats.opponent.name}', style: const TextStyle(fontWeight: FontWeight.w800))), Text('${stats.playerScore} - ${stats.opponentScore}', style: TextStyle(color: color, fontWeight: FontWeight.w900))]));
  }
}

class PrivateRoomScreen extends StatelessWidget {
  const PrivateRoomScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: NeonBackground(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(children: [
              _ScreenHeader(title: 'اتاق خصوصی', onBack: () => Navigator.of(context).pop()),
              const SizedBox(height: 40),
              GlassPanel(radius: 30, padding: const EdgeInsets.all(22), borderColor: AppColors.pink, child: Column(children: [
                const Icon(Icons.groups_rounded, color: AppColors.pink, size: 64),
                const SizedBox(height: 16),
                const Text('ساخت اتاق دوستانه', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
                const SizedBox(height: 12),
                Text('در نسخه سروردار، این بخش کد کوتاه واقعی می‌سازد. فعلاً با شبیه‌ساز داخلی اجرا می‌شود.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white.withOpacity(.7))),
                const SizedBox(height: 22),
                Container(padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16), decoration: BoxDecoration(borderRadius: BorderRadius.circular(22), color: Colors.white.withOpacity(.08), border: Border.all(color: AppColors.cyan.withOpacity(.35))), child: const Text('کد اتاق: DJ-4821', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900, letterSpacing: 1))),
                const SizedBox(height: 20),
                NeonButton(label: 'شروع اتاق خصوصی', icon: Icons.play_arrow_rounded, compact: true, onTap: () => Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => MatchmakingScreen(mode: DuelMode.private)))),
              ])),
            ]),
          ),
        ),
      ),
    );
  }
}

class LeaderboardScreen extends StatelessWidget {
  const LeaderboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: NeonBackground(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(children: [
              _ScreenHeader(title: 'رتبه‌بندی', onBack: () => Navigator.of(context).pop()),
              const SizedBox(height: 20),
              GlassPanel(radius: 26, padding: const EdgeInsets.all(12), child: Row(children: const [Expanded(child: _LeagueTab(label: 'روزانه', selected: true)), Expanded(child: _LeagueTab(label: 'هفتگی', selected: false)), Expanded(child: _LeagueTab(label: 'ماهانه', selected: false))])),
              const SizedBox(height: 18),
              Expanded(child: GlassPanel(radius: 28, padding: const EdgeInsets.all(14), child: ListView.builder(physics: const BouncingScrollPhysics(), itemCount: SampleData.leaderboard.length, itemBuilder: (context, index) => _RankRow(index: index + 1, data: SampleData.leaderboard[index])))),
            ]),
          ),
        ),
      ),
    );
  }
}

class QuestionBankScreen extends StatelessWidget {
  const QuestionBankScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final cats = SampleData.questions.map((q) => q.category).toSet().toList();
    return Scaffold(
      body: NeonBackground(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(children: [
              _ScreenHeader(title: 'بانک سوالات', onBack: () => Navigator.of(context).pop()),
              const SizedBox(height: 16),
              GlassPanel(radius: 24, borderColor: AppColors.cyan, child: Row(children: [const Icon(Icons.quiz_rounded, color: AppColors.cyan, size: 42), const SizedBox(width: 12), Expanded(child: Text('${SampleData.questions.length} سوال آماده در ${cats.length} دسته‌بندی', style: const TextStyle(fontWeight: FontWeight.w900))), const Icon(Icons.cloud_upload_rounded, color: AppColors.pink)])),
              const SizedBox(height: 14),
              Expanded(child: GlassPanel(radius: 26, padding: const EdgeInsets.all(12), child: ListView.builder(physics: const BouncingScrollPhysics(), itemCount: SampleData.questions.length, itemBuilder: (_, i) {
                final q = SampleData.questions[i];
                return Container(margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.all(12), decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), color: Colors.white.withOpacity(.06), border: Border.all(color: Colors.white.withOpacity(.09))), child: Row(children: [Container(width: 32, height: 32, alignment: Alignment.center, decoration: BoxDecoration(shape: BoxShape.circle, color: (q.answer ? AppColors.green : AppColors.red).withOpacity(.18)), child: Text(q.answer ? 'ب' : 'ن', style: TextStyle(color: q.answer ? AppColors.green : AppColors.red, fontWeight: FontWeight.w900))), const SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(q.text, style: const TextStyle(fontWeight: FontWeight.w800)), const SizedBox(height: 4), Text('${q.category} • سختی ${q.difficulty}', style: TextStyle(color: Colors.white.withOpacity(.55), fontSize: 11))]))]));
              }))),
            ]),
          ),
        ),
      ),
    );
  }
}

class _LeagueTab extends StatelessWidget {
  final String label;
  final bool selected;
  const _LeagueTab({required this.label, required this.selected});

  @override
  Widget build(BuildContext context) {
    return Container(margin: const EdgeInsets.symmetric(horizontal: 4), padding: const EdgeInsets.symmetric(vertical: 12), alignment: Alignment.center, decoration: BoxDecoration(borderRadius: BorderRadius.circular(17), gradient: selected ? const LinearGradient(colors: [AppColors.blue, AppColors.cyan]) : null, color: selected ? null : Colors.white.withOpacity(.05)), child: Text(label, style: const TextStyle(fontWeight: FontWeight.w900)));
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  final String subtitle;
  const _SectionHeader({required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w900)), const SizedBox(height: 5), Text(subtitle, style: TextStyle(color: Colors.white.withOpacity(.62), fontSize: 12))])),
      const PremiumTrophy(size: 48),
    ]);
  }
}

class _ScreenHeader extends StatelessWidget {
  final String title;
  final VoidCallback onBack;
  const _ScreenHeader({required this.title, required this.onBack});

  @override
  Widget build(BuildContext context) {
    return Row(children: [_RoundIconButton(icon: Icons.arrow_back_rounded, onTap: onBack), Expanded(child: Center(child: Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)))), const SizedBox(width: 48)]);
  }
}

String _formatNumber(int value) {
  final s = value.toString();
  final buffer = StringBuffer();
  for (int i = 0; i < s.length; i++) {
    final reverseIndex = s.length - i;
    buffer.write(s[i]);
    if (reverseIndex > 1 && reverseIndex % 3 == 1) buffer.write(',');
  }
  return buffer.toString();
}
