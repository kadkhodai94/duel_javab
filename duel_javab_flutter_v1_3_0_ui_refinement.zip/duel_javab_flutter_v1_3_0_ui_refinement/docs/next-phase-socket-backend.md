# مرحله بعد: Backend اختصاصی Socket.IO

این نسخه عمداً بدون Firebase ساخته شده است. برای آنلاین واقعی بازی، Backend اختصاصی لازم است.

## معماری پیشنهادی

```text
Flutter App
  ↕ Socket.IO Client
Node.js Server
  ↕ MySQL/MariaDB
Admin Panel
```

## رویدادهای اصلی Socket.IO

```text
quick_match:join
private_room:create
private_room:join
match:countdown
match:start
answer:submit
score:update
question:next
match:finish
player:left
player:reconnect
```

## قوانین ضدتقلب

- زمان شروع هر سوال باید سمت سرور ثبت شود.
- جواب کاربر فقط شامل `questionId`, `answer` و `clientElapsedMs` باشد.
- امتیاز نهایی باید سمت سرور محاسبه شود.
- کلاینت نباید بتواند امتیاز را مستقیم ارسال کند.
- برای قطع اتصال، بازیکن تا چند ثانیه فرصت Reconnect داشته باشد.

## دیتابیس پیشنهادی

```text
users
questions
matches
match_players
answers
leaderboards
shop_items
missions
```

## مرحله پیاده‌سازی

1. ساخت Node.js API و Socket.IO Server
2. اتصال Flutter به `socket_io_client`
3. جایگزینی `LocalSimulatedMatchGateway` با `SocketMatchGateway`
4. ساخت پنل مدیریت سوالات
5. ذخیره امتیاز و رتبه‌بندی در MySQL
