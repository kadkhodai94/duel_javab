#!/usr/bin/env bash
set -euo pipefail
flutter create --platforms=android --project-name=duel_javab --org=com.pars.duel .
flutter pub get
