# دوئل جواب - نسخه Flutter v1.0.0

این پروژه یک نسخه Flutter آماده از بازی رقابتی «دوئل جواب» است.

## امکانات نسخه فعلی

- طراحی RTL فارسی
- صفحه اصلی با UI نئونی و رقابتی
- جستجوی حریف با شمارش معکوس
- صفحه مسابقه با تایمر ۷ ثانیه‌ای
- سوالات فقط بله/نه و درست/غلط
- امتیازدهی بر اساس سرعت و جواب درست
- کمبو، پاورآپ، بازخورد درست/غلط
- صفحه نتیجه، جایزه، XP و بازی دوباره
- رتبه‌بندی نمونه
- اتاق خصوصی نمونه
- ساختار آماده برای اتصال آنلاین واقعی

## اجرای پروژه

اگر فقط پوشه lib و pubspec را دارید، اول پلتفرم اندروید را بسازید:

```bash
flutter create --platforms=android .
flutter pub get
flutter run
```

برای خروجی APK:

```bash
flutter build apk --release --no-shrink --build-name=1.0.0 --build-number=1
```

## آنلاین واقعی

در نسخه فعلی، حریف به‌صورت شبیه‌سازی‌شده جواب می‌دهد تا UI و منطق بازی قابل تست باشد. برای آنلاین واقعی باید یکی از این دو مسیر اضافه شود:

1. Firebase Realtime Database / Firestore برای MVP سریع
2. Node.js + Socket.IO برای کنترل کامل‌تر، ضدتقلب قوی‌تر و مچ‌میکینگ حرفه‌ای‌تر

## ساختار پیشنهادی دیتابیس آنلاین

```text
rooms/{roomId}
  status: waiting | playing | finished
  player1: uid
  player2: uid
  currentQuestionIndex: number
  startedAt: serverTimestamp
  scores:
    player1: number
    player2: number
  answers:
    questionId:
      playerUid:
        answer: true | false
        answeredAt: serverTimestamp
```

## نکته مهم

محاسبه نهایی امتیاز در نسخه آنلاین نباید داخل موبایل انجام شود. اپ فقط جواب را ارسال می‌کند؛ سرور باید زمان جواب و امتیاز نهایی را ثبت کند.
